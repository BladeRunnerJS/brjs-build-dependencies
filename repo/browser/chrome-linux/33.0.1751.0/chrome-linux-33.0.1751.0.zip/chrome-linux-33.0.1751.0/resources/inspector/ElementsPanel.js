WebInspector.CSSNamedFlowCollectionsView=function()
{WebInspector.SidebarView.call(this,WebInspector.SidebarView.SidebarPosition.Start);this.registerRequiredCSS("cssNamedFlows.css");this._namedFlows={};this._contentNodes={};this._regionNodes={};this.element.classList.add("css-named-flow-collections-view");this.element.classList.add("fill");this._statusElement=document.createElement("span");this._statusElement.textContent=WebInspector.UIString("CSS Named Flows");var sidebarHeader=this.firstElement().createChild("div","tabbed-pane-header selected sidebar-header");var tab=sidebarHeader.createChild("div","tabbed-pane-header-tab");tab.createChild("span","tabbed-pane-header-tab-title").textContent=WebInspector.UIString("CSS Named Flows");this._sidebarContentElement=this.firstElement().createChild("div","sidebar-content outline-disclosure");this._flowListElement=this._sidebarContentElement.createChild("ol");this._flowTree=new TreeOutline(this._flowListElement);this._emptyElement=document.createElement("div");this._emptyElement.classList.add("info");this._emptyElement.textContent=WebInspector.UIString("No CSS Named Flows");this._tabbedPane=new WebInspector.TabbedPane();this._tabbedPane.closeableTabs=true;this._tabbedPane.show(this.secondElement());}
WebInspector.CSSNamedFlowCollectionsView.prototype={showInDrawer:function()
{WebInspector.inspectorView.showCloseableViewInDrawer("css-flows",WebInspector.UIString("CSS Flows"),this);},reset:function()
{if(!this._document)
return;WebInspector.cssModel.getNamedFlowCollectionAsync(this._document.id,this._resetNamedFlows.bind(this));},_setDocument:function(document)
{this._document=document;this.reset();},_documentUpdated:function(event)
{var document=(event.data);this._setDocument(document);},_setSidebarHasContent:function(hasContent)
{if(hasContent){if(!this._emptyElement.parentNode)
return;this._sidebarContentElement.removeChild(this._emptyElement);this._sidebarContentElement.appendChild(this._flowListElement);}else{if(!this._flowListElement.parentNode)
return;this._sidebarContentElement.removeChild(this._flowListElement);this._sidebarContentElement.appendChild(this._emptyElement);}},_appendNamedFlow:function(flow)
{var flowHash=this._hashNamedFlow(flow.documentNodeId,flow.name);var flowContainer={flow:flow,flowHash:flowHash};for(var i=0;i<flow.content.length;++i)
this._contentNodes[flow.content[i]]=flowHash;for(var i=0;i<flow.regions.length;++i)
this._regionNodes[flow.regions[i].nodeId]=flowHash;var flowTreeItem=new WebInspector.FlowTreeElement(flowContainer);flowTreeItem.onselect=this._selectNamedFlowTab.bind(this,flowHash);flowContainer.flowTreeItem=flowTreeItem;this._namedFlows[flowHash]=flowContainer;if(!this._flowTree.children.length)
this._setSidebarHasContent(true);this._flowTree.appendChild(flowTreeItem);},_removeNamedFlow:function(flowHash)
{var flowContainer=this._namedFlows[flowHash];if(this._tabbedPane._tabsById[flowHash])
this._tabbedPane.closeTab(flowHash);this._flowTree.removeChild(flowContainer.flowTreeItem);var flow=flowContainer.flow;for(var i=0;i<flow.content.length;++i)
delete this._contentNodes[flow.content[i]];for(var i=0;i<flow.regions.length;++i)
delete this._regionNodes[flow.regions[i].nodeId];delete this._namedFlows[flowHash];if(!this._flowTree.children.length)
this._setSidebarHasContent(false);},_updateNamedFlow:function(flow)
{var flowHash=this._hashNamedFlow(flow.documentNodeId,flow.name);var flowContainer=this._namedFlows[flowHash];if(!flowContainer)
return;var oldFlow=flowContainer.flow;flowContainer.flow=flow;for(var i=0;i<oldFlow.content.length;++i)
delete this._contentNodes[oldFlow.content[i]];for(var i=0;i<oldFlow.regions.length;++i)
delete this._regionNodes[oldFlow.regions[i].nodeId];for(var i=0;i<flow.content.length;++i)
this._contentNodes[flow.content[i]]=flowHash;for(var i=0;i<flow.regions.length;++i)
this._regionNodes[flow.regions[i].nodeId]=flowHash;flowContainer.flowTreeItem.setOverset(flow.overset);if(flowContainer.flowView)
flowContainer.flowView.flow=flow;},_resetNamedFlows:function(namedFlowCollection)
{for(var flowHash in this._namedFlows)
this._removeNamedFlow(flowHash);var namedFlows=namedFlowCollection?namedFlowCollection.namedFlowMap:{};for(var flowName in namedFlows)
this._appendNamedFlow(namedFlows[flowName]);if(!this._flowTree.children.length)
this._setSidebarHasContent(false);else
this._showNamedFlowForNode(WebInspector.panel("elements").treeOutline.selectedDOMNode());},_namedFlowCreated:function(event)
{if(event.data.documentNodeId!==this._document.id)
return;var flow=(event.data);this._appendNamedFlow(flow);},_namedFlowRemoved:function(event)
{if(event.data.documentNodeId!==this._document.id)
return;this._removeNamedFlow(this._hashNamedFlow(event.data.documentNodeId,event.data.flowName));},_regionLayoutUpdated:function(event)
{if(event.data.documentNodeId!==this._document.id)
return;var flow=(event.data);this._updateNamedFlow(flow);},_regionOversetChanged:function(event)
{if(event.data.documentNodeId!==this._document.id)
return;var flow=(event.data);this._updateNamedFlow(flow);},_hashNamedFlow:function(documentNodeId,flowName)
{return documentNodeId+"|"+flowName;},_showNamedFlow:function(flowHash)
{this._selectNamedFlowInSidebar(flowHash);this._selectNamedFlowTab(flowHash);},_selectNamedFlowInSidebar:function(flowHash)
{this._namedFlows[flowHash].flowTreeItem.select(true);},_selectNamedFlowTab:function(flowHash)
{var flowContainer=this._namedFlows[flowHash];if(this._tabbedPane.selectedTabId===flowHash)
return false;if(!this._tabbedPane.selectTab(flowHash)){if(!flowContainer.flowView)
flowContainer.flowView=new WebInspector.CSSNamedFlowView(flowContainer.flow);this._tabbedPane.appendTab(flowHash,flowContainer.flow.name,flowContainer.flowView);this._tabbedPane.selectTab(flowHash);}
return false;},_selectedNodeChanged:function(event)
{var node=(event.data);this._showNamedFlowForNode(node);},_tabSelected:function(event)
{this._selectNamedFlowInSidebar(event.data.tabId);},_tabClosed:function(event)
{this._namedFlows[event.data.tabId].flowTreeItem.deselect();},_showNamedFlowForNode:function(node)
{if(!node)
return;if(this._regionNodes[node.id]){this._showNamedFlow(this._regionNodes[node.id]);return;}
while(node){if(this._contentNodes[node.id]){this._showNamedFlow(this._contentNodes[node.id]);return;}
node=node.parentNode;}},wasShown:function()
{WebInspector.SidebarView.prototype.wasShown.call(this);WebInspector.domAgent.requestDocument(this._setDocument.bind(this));WebInspector.domAgent.addEventListener(WebInspector.DOMAgent.Events.DocumentUpdated,this._documentUpdated,this);WebInspector.cssModel.addEventListener(WebInspector.CSSStyleModel.Events.NamedFlowCreated,this._namedFlowCreated,this);WebInspector.cssModel.addEventListener(WebInspector.CSSStyleModel.Events.NamedFlowRemoved,this._namedFlowRemoved,this);WebInspector.cssModel.addEventListener(WebInspector.CSSStyleModel.Events.RegionLayoutUpdated,this._regionLayoutUpdated,this);WebInspector.cssModel.addEventListener(WebInspector.CSSStyleModel.Events.RegionOversetChanged,this._regionOversetChanged,this);WebInspector.panel("elements").treeOutline.addEventListener(WebInspector.ElementsTreeOutline.Events.SelectedNodeChanged,this._selectedNodeChanged,this);this._tabbedPane.addEventListener(WebInspector.TabbedPane.EventTypes.TabSelected,this._tabSelected,this);this._tabbedPane.addEventListener(WebInspector.TabbedPane.EventTypes.TabClosed,this._tabClosed,this);},willHide:function()
{WebInspector.domAgent.removeEventListener(WebInspector.DOMAgent.Events.DocumentUpdated,this._documentUpdated,this);WebInspector.cssModel.removeEventListener(WebInspector.CSSStyleModel.Events.NamedFlowCreated,this._namedFlowCreated,this);WebInspector.cssModel.removeEventListener(WebInspector.CSSStyleModel.Events.NamedFlowRemoved,this._namedFlowRemoved,this);WebInspector.cssModel.removeEventListener(WebInspector.CSSStyleModel.Events.RegionLayoutUpdated,this._regionLayoutUpdated,this);WebInspector.cssModel.removeEventListener(WebInspector.CSSStyleModel.Events.RegionOversetChanged,this._regionOversetChanged,this);WebInspector.panel("elements").treeOutline.removeEventListener(WebInspector.ElementsTreeOutline.Events.SelectedNodeChanged,this._selectedNodeChanged,this);this._tabbedPane.removeEventListener(WebInspector.TabbedPane.EventTypes.TabSelected,this._tabSelected,this);this._tabbedPane.removeEventListener(WebInspector.TabbedPane.EventTypes.TabClosed,this._tabClosed,this);},__proto__:WebInspector.SidebarView.prototype}
WebInspector.FlowTreeElement=function(flowContainer)
{var container=document.createElement("div");container.createChild("div","selection");container.createChild("span","title").createChild("span").textContent=flowContainer.flow.name;TreeElement.call(this,container,flowContainer,false);this._overset=false;this.setOverset(flowContainer.flow.overset);}
WebInspector.FlowTreeElement.prototype={setOverset:function(newOverset)
{if(this._overset===newOverset)
return;if(newOverset){this.title.classList.add("named-flow-overflow");this.tooltip=WebInspector.UIString("Overflows.");}else{this.title.classList.remove("named-flow-overflow");this.tooltip="";}
this._overset=newOverset;},__proto__:TreeElement.prototype};WebInspector.CSSNamedFlowView=function(flow)
{WebInspector.View.call(this);this.element.classList.add("css-named-flow");this.element.classList.add("outline-disclosure");this._treeOutline=new TreeOutline(this.element.createChild("ol"),true);this._contentTreeItem=new TreeElement(WebInspector.UIString("content"),null,true);this._treeOutline.appendChild(this._contentTreeItem);this._regionsTreeItem=new TreeElement(WebInspector.UIString("region chain"),null,true);this._regionsTreeItem.expand();this._treeOutline.appendChild(this._regionsTreeItem);this._flow=flow;var content=flow.content;for(var i=0;i<content.length;++i)
this._insertContentNode(content[i]);var regions=flow.regions;for(var i=0;i<regions.length;++i)
this._insertRegion(regions[i]);}
WebInspector.CSSNamedFlowView.OversetTypeMessageMap={empty:"empty",fit:"fit",overset:"overset"}
WebInspector.CSSNamedFlowView.prototype={_createFlowTreeOutline:function(rootDOMNode)
{if(!rootDOMNode)
return null;var treeOutline=new WebInspector.ElementsTreeOutline(false,false);treeOutline.element.classList.add("named-flow-element");treeOutline.setVisible(true);treeOutline.rootDOMNode=rootDOMNode;treeOutline.wireToDomAgent();WebInspector.domAgent.removeEventListener(WebInspector.DOMAgent.Events.DocumentUpdated,treeOutline._elementsTreeUpdater._documentUpdated,treeOutline._elementsTreeUpdater);return treeOutline;},_insertContentNode:function(contentNodeId,index)
{var treeOutline=this._createFlowTreeOutline(WebInspector.domAgent.nodeForId(contentNodeId));var treeItem=new TreeElement(treeOutline.element,treeOutline);if(index===undefined){this._contentTreeItem.appendChild(treeItem);return;}
this._contentTreeItem.insertChild(treeItem,index);},_insertRegion:function(region,index)
{var treeOutline=this._createFlowTreeOutline(WebInspector.domAgent.nodeForId(region.nodeId));treeOutline.element.classList.add("region-"+region.regionOverset);var treeItem=new TreeElement(treeOutline.element,treeOutline);var oversetText=WebInspector.UIString(WebInspector.CSSNamedFlowView.OversetTypeMessageMap[region.regionOverset]);treeItem.tooltip=WebInspector.UIString("Region is %s.",oversetText);if(index===undefined){this._regionsTreeItem.appendChild(treeItem);return;}
this._regionsTreeItem.insertChild(treeItem,index);},get flow()
{return this._flow;},set flow(newFlow)
{this._update(newFlow);},_updateRegionOverset:function(regionTreeItem,newRegionOverset,oldRegionOverset)
{var element=regionTreeItem.representedObject.element;element.classList.remove("region-"+oldRegionOverset);element.classList.add("region-"+newRegionOverset);var oversetText=WebInspector.UIString(WebInspector.CSSNamedFlowView.OversetTypeMessageMap[newRegionOverset]);regionTreeItem.tooltip=WebInspector.UIString("Region is %s.",oversetText);},_mergeContentNodes:function(oldContent,newContent)
{var nodeIdSet={};for(var i=0;i<newContent.length;++i)
nodeIdSet[newContent[i]]=true;var oldContentIndex=0;var newContentIndex=0;var contentTreeChildIndex=0;while(oldContentIndex<oldContent.length||newContentIndex<newContent.length){if(oldContentIndex===oldContent.length){this._insertContentNode(newContent[newContentIndex]);++newContentIndex;continue;}
if(newContentIndex===newContent.length){this._contentTreeItem.removeChildAtIndex(contentTreeChildIndex);++oldContentIndex;continue;}
if(oldContent[oldContentIndex]===newContent[newContentIndex]){++oldContentIndex;++newContentIndex;++contentTreeChildIndex;continue;}
if(nodeIdSet[oldContent[oldContentIndex]]){this._insertContentNode(newContent[newContentIndex],contentTreeChildIndex);++newContentIndex;++contentTreeChildIndex;continue;}
this._contentTreeItem.removeChildAtIndex(contentTreeChildIndex);++oldContentIndex;}},_mergeRegions:function(oldRegions,newRegions)
{var nodeIdSet={};for(var i=0;i<newRegions.length;++i)
nodeIdSet[newRegions[i].nodeId]=true;var oldRegionsIndex=0;var newRegionsIndex=0;var regionsTreeChildIndex=0;while(oldRegionsIndex<oldRegions.length||newRegionsIndex<newRegions.length){if(oldRegionsIndex===oldRegions.length){this._insertRegion(newRegions[newRegionsIndex]);++newRegionsIndex;continue;}
if(newRegionsIndex===newRegions.length){this._regionsTreeItem.removeChildAtIndex(regionsTreeChildIndex);++oldRegionsIndex;continue;}
if(oldRegions[oldRegionsIndex].nodeId===newRegions[newRegionsIndex].nodeId){if(oldRegions[oldRegionsIndex].regionOverset!==newRegions[newRegionsIndex].regionOverset)
this._updateRegionOverset(this._regionsTreeItem.children[regionsTreeChildIndex],newRegions[newRegionsIndex].regionOverset,oldRegions[oldRegionsIndex].regionOverset);++oldRegionsIndex;++newRegionsIndex;++regionsTreeChildIndex;continue;}
if(nodeIdSet[oldRegions[oldRegionsIndex].nodeId]){this._insertRegion(newRegions[newRegionsIndex],regionsTreeChildIndex);++newRegionsIndex;++regionsTreeChildIndex;continue;}
this._regionsTreeItem.removeChildAtIndex(regionsTreeChildIndex);++oldRegionsIndex;}},_update:function(newFlow)
{this._mergeContentNodes(this._flow.content,newFlow.content);this._mergeRegions(this._flow.regions,newFlow.regions);this._flow=newFlow;},__proto__:WebInspector.View.prototype};WebInspector.EventListenersSidebarPane=function()
{WebInspector.SidebarPane.call(this,WebInspector.UIString("Event Listeners"));this.bodyElement.classList.add("events-pane");this.sections=[];this.settingsSelectElement=document.createElement("select");this.settingsSelectElement.className="select-filter";var option=document.createElement("option");option.value="all";option.label=WebInspector.UIString("All Nodes");this.settingsSelectElement.appendChild(option);option=document.createElement("option");option.value="selected";option.label=WebInspector.UIString("Selected Node Only");this.settingsSelectElement.appendChild(option);var filter=WebInspector.settings.eventListenersFilter.get();if(filter==="all")
this.settingsSelectElement[0].selected=true;else if(filter==="selected")
this.settingsSelectElement[1].selected=true;this.settingsSelectElement.addEventListener("click",function(event){event.consume()},false);this.settingsSelectElement.addEventListener("change",this._changeSetting.bind(this),false);this.titleElement.appendChild(this.settingsSelectElement);this._linkifier=new WebInspector.Linkifier();}
WebInspector.EventListenersSidebarPane._objectGroupName="event-listeners-sidebar-pane";WebInspector.EventListenersSidebarPane.prototype={update:function(node)
{RuntimeAgent.releaseObjectGroup(WebInspector.EventListenersSidebarPane._objectGroupName);this._linkifier.reset();var body=this.bodyElement;body.removeChildren();this.sections=[];var self=this;function callback(error,eventListeners){if(error)
return;var selectedNodeOnly="selected"===WebInspector.settings.eventListenersFilter.get();var sectionNames=[];var sectionMap={};for(var i=0;i<eventListeners.length;++i){var eventListener=eventListeners[i];if(selectedNodeOnly&&(node.id!==eventListener.nodeId))
continue;eventListener.node=WebInspector.domAgent.nodeForId(eventListener.nodeId);delete eventListener.nodeId;if(/^function _inspectorCommandLineAPI_logEvent\(/.test(eventListener.handlerBody.toString()))
continue;var type=eventListener.type;var section=sectionMap[type];if(!section){section=new WebInspector.EventListenersSection(type,node.id,self._linkifier);sectionMap[type]=section;sectionNames.push(type);self.sections.push(section);}
section.addListener(eventListener);}
if(sectionNames.length===0){var div=document.createElement("div");div.className="info";div.textContent=WebInspector.UIString("No Event Listeners");body.appendChild(div);return;}
sectionNames.sort();for(var i=0;i<sectionNames.length;++i){var section=sectionMap[sectionNames[i]];body.appendChild(section.element);}}
if(node)
node.eventListeners(WebInspector.EventListenersSidebarPane._objectGroupName,callback);this._selectedNode=node;},willHide:function()
{delete this._selectedNode;},_changeSetting:function()
{var selectedOption=this.settingsSelectElement[this.settingsSelectElement.selectedIndex];WebInspector.settings.eventListenersFilter.set(selectedOption.value);this.update(this._selectedNode);},__proto__:WebInspector.SidebarPane.prototype}
WebInspector.EventListenersSection=function(title,nodeId,linkifier)
{this.eventListeners=[];this._nodeId=nodeId;this._linkifier=linkifier;WebInspector.PropertiesSection.call(this,title);this.propertiesElement.remove();delete this.propertiesElement;delete this.propertiesTreeOutline;this._eventBars=document.createElement("div");this._eventBars.className="event-bars";this.element.appendChild(this._eventBars);}
WebInspector.EventListenersSection.prototype={addListener:function(eventListener)
{var eventListenerBar=new WebInspector.EventListenerBar(eventListener,this._nodeId,this._linkifier);this._eventBars.appendChild(eventListenerBar.element);},__proto__:WebInspector.PropertiesSection.prototype}
WebInspector.EventListenerBar=function(eventListener,nodeId,linkifier)
{WebInspector.ObjectPropertiesSection.call(this,WebInspector.RemoteObject.fromPrimitiveValue(""));this.eventListener=eventListener;this._nodeId=nodeId;this._setNodeTitle();this._setFunctionSubtitle(linkifier);this.editable=false;this.element.className="event-bar";this.headerElement.classList.add("source-code");this.propertiesElement.className="event-properties properties-tree source-code";}
WebInspector.EventListenerBar.prototype={update:function()
{function updateWithNodeObject(nodeObject)
{var properties=[];if(this.eventListener.type)
properties.push(WebInspector.RemoteObjectProperty.fromPrimitiveValue("type",this.eventListener.type));if(typeof this.eventListener.useCapture!=="undefined")
properties.push(WebInspector.RemoteObjectProperty.fromPrimitiveValue("useCapture",this.eventListener.useCapture));if(typeof this.eventListener.isAttribute!=="undefined")
properties.push(WebInspector.RemoteObjectProperty.fromPrimitiveValue("isAttribute",this.eventListener.isAttribute));if(nodeObject)
properties.push(new WebInspector.RemoteObjectProperty("node",nodeObject));if(typeof this.eventListener.handler!=="undefined"){var remoteObject=WebInspector.RemoteObject.fromPayload(this.eventListener.handler);properties.push(new WebInspector.RemoteObjectProperty("handler",remoteObject));}
if(typeof this.eventListener.handlerBody!=="undefined")
properties.push(WebInspector.RemoteObjectProperty.fromPrimitiveValue("listenerBody",this.eventListener.handlerBody));if(this.eventListener.sourceName)
properties.push(WebInspector.RemoteObjectProperty.fromPrimitiveValue("sourceName",this.eventListener.sourceName));if(this.eventListener.location)
properties.push(WebInspector.RemoteObjectProperty.fromPrimitiveValue("lineNumber",this.eventListener.location.lineNumber+1));this.updateProperties(properties);}
WebInspector.RemoteObject.resolveNode(this.eventListener.node,WebInspector.EventListenersSidebarPane._objectGroupName,updateWithNodeObject.bind(this));},_setNodeTitle:function()
{var node=this.eventListener.node;if(!node)
return;if(node.nodeType()===Node.DOCUMENT_NODE){this.titleElement.textContent="document";return;}
if(node.id===this._nodeId){this.titleElement.textContent=WebInspector.DOMPresentationUtils.appropriateSelectorFor(node);return;}
this.titleElement.removeChildren();this.titleElement.appendChild(WebInspector.DOMPresentationUtils.linkifyNodeReference(this.eventListener.node));},_setFunctionSubtitle:function(linkifier)
{if(this.eventListener.location){this.subtitleElement.removeChildren();var urlElement;if(this.eventListener.location.scriptId)
urlElement=linkifier.linkifyRawLocation(this.eventListener.location);if(!urlElement){var url=this.eventListener.sourceName;var lineNumber=this.eventListener.location.lineNumber;var columnNumber=0;urlElement=linkifier.linkifyLocation(url,lineNumber,columnNumber);}
this.subtitleElement.appendChild(urlElement);}else{var match=this.eventListener.handlerBody.match(/function ([^\(]+?)\(/);if(match)
this.subtitleElement.textContent=match[1];else
this.subtitleElement.textContent=WebInspector.UIString("(anonymous function)");}},__proto__:WebInspector.ObjectPropertiesSection.prototype};WebInspector.MetricsSidebarPane=function()
{WebInspector.SidebarPane.call(this,WebInspector.UIString("Metrics"));WebInspector.cssModel.addEventListener(WebInspector.CSSStyleModel.Events.StyleSheetChanged,this._styleSheetOrMediaQueryResultChanged,this);WebInspector.cssModel.addEventListener(WebInspector.CSSStyleModel.Events.MediaQueryResultChanged,this._styleSheetOrMediaQueryResultChanged,this);WebInspector.domAgent.addEventListener(WebInspector.DOMAgent.Events.AttrModified,this._attributesUpdated,this);WebInspector.domAgent.addEventListener(WebInspector.DOMAgent.Events.AttrRemoved,this._attributesUpdated,this);WebInspector.resourceTreeModel.addEventListener(WebInspector.ResourceTreeModel.EventTypes.FrameResized,this._frameResized,this);}
WebInspector.MetricsSidebarPane.prototype={update:function(node)
{if(node)
this.node=node;this._innerUpdate();},_innerUpdate:function()
{if(this._isEditingMetrics)
return;var node=this.node;if(!node||node.nodeType()!==Node.ELEMENT_NODE){this.bodyElement.removeChildren();return;}
function callback(style)
{if(!style||this.node!==node)
return;this._updateMetrics(style);}
WebInspector.cssModel.getComputedStyleAsync(node.id,callback.bind(this));function inlineStyleCallback(style)
{if(!style||this.node!==node)
return;this.inlineStyle=style;}
WebInspector.cssModel.getInlineStylesAsync(node.id,inlineStyleCallback.bind(this));},_styleSheetOrMediaQueryResultChanged:function()
{this._innerUpdate();},_frameResized:function()
{function refreshContents()
{this._innerUpdate();delete this._activeTimer;}
if(this._activeTimer)
clearTimeout(this._activeTimer);this._activeTimer=setTimeout(refreshContents.bind(this),100);},_attributesUpdated:function(event)
{if(this.node!==event.data.node)
return;this._innerUpdate();},_getPropertyValueAsPx:function(style,propertyName)
{return Number(style.getPropertyValue(propertyName).replace(/px$/,"")||0);},_getBox:function(computedStyle,componentName)
{var suffix=componentName==="border"?"-width":"";var left=this._getPropertyValueAsPx(computedStyle,componentName+"-left"+suffix);var top=this._getPropertyValueAsPx(computedStyle,componentName+"-top"+suffix);var right=this._getPropertyValueAsPx(computedStyle,componentName+"-right"+suffix);var bottom=this._getPropertyValueAsPx(computedStyle,componentName+"-bottom"+suffix);return{left:left,top:top,right:right,bottom:bottom};},_highlightDOMNode:function(showHighlight,mode,event)
{event.consume();var nodeId=showHighlight&&this.node?this.node.id:0;if(nodeId){if(this._highlightMode===mode)
return;this._highlightMode=mode;WebInspector.domAgent.highlightDOMNode(nodeId,mode);}else{delete this._highlightMode;WebInspector.domAgent.hideDOMNodeHighlight();}
for(var i=0;this._boxElements&&i<this._boxElements.length;++i){var element=this._boxElements[i];if(!nodeId||mode==="all"||element._name===mode)
element.style.backgroundColor=element._backgroundColor;else
element.style.backgroundColor="";}},_updateMetrics:function(style)
{var metricsElement=document.createElement("div");metricsElement.className="metrics";var self=this;function createBoxPartElement(style,name,side,suffix)
{var propertyName=(name!=="position"?name+"-":"")+side+suffix;var value=style.getPropertyValue(propertyName);if(value===""||(name!=="position"&&value==="0px"))
value="\u2012";else if(name==="position"&&value==="auto")
value="\u2012";value=value.replace(/px$/,"");value=Number.toFixedIfFloating(value);var element=document.createElement("div");element.className=side;element.textContent=value;element.addEventListener("dblclick",this.startEditing.bind(this,element,name,propertyName,style),false);return element;}
function getContentAreaWidthPx(style)
{var width=style.getPropertyValue("width").replace(/px$/,"");if(!isNaN(width)&&style.getPropertyValue("box-sizing")==="border-box"){var borderBox=self._getBox(style,"border");var paddingBox=self._getBox(style,"padding");width=width-borderBox.left-borderBox.right-paddingBox.left-paddingBox.right;}
return Number.toFixedIfFloating(width);}
function getContentAreaHeightPx(style)
{var height=style.getPropertyValue("height").replace(/px$/,"");if(!isNaN(height)&&style.getPropertyValue("box-sizing")==="border-box"){var borderBox=self._getBox(style,"border");var paddingBox=self._getBox(style,"padding");height=height-borderBox.top-borderBox.bottom-paddingBox.top-paddingBox.bottom;}
return Number.toFixedIfFloating(height);}
var noMarginDisplayType={"table-cell":true,"table-column":true,"table-column-group":true,"table-footer-group":true,"table-header-group":true,"table-row":true,"table-row-group":true};var noPaddingDisplayType={"table-column":true,"table-column-group":true,"table-footer-group":true,"table-header-group":true,"table-row":true,"table-row-group":true};var noPositionType={"static":true};var boxes=["content","padding","border","margin","position"];var boxColors=[WebInspector.Color.PageHighlight.Content,WebInspector.Color.PageHighlight.Padding,WebInspector.Color.PageHighlight.Border,WebInspector.Color.PageHighlight.Margin,WebInspector.Color.fromRGBA([0,0,0,0])];var boxLabels=[WebInspector.UIString("content"),WebInspector.UIString("padding"),WebInspector.UIString("border"),WebInspector.UIString("margin"),WebInspector.UIString("position")];var previousBox=null;this._boxElements=[];for(var i=0;i<boxes.length;++i){var name=boxes[i];if(name==="margin"&&noMarginDisplayType[style.getPropertyValue("display")])
continue;if(name==="padding"&&noPaddingDisplayType[style.getPropertyValue("display")])
continue;if(name==="position"&&noPositionType[style.getPropertyValue("position")])
continue;var boxElement=document.createElement("div");boxElement.className=name;boxElement._backgroundColor=boxColors[i].toString(WebInspector.Color.Format.RGBA);boxElement._name=name;boxElement.style.backgroundColor=boxElement._backgroundColor;boxElement.addEventListener("mouseover",this._highlightDOMNode.bind(this,true,name==="position"?"all":name),false);this._boxElements.push(boxElement);if(name==="content"){var widthElement=document.createElement("span");widthElement.textContent=getContentAreaWidthPx(style);widthElement.addEventListener("dblclick",this.startEditing.bind(this,widthElement,"width","width",style),false);var heightElement=document.createElement("span");heightElement.textContent=getContentAreaHeightPx(style);heightElement.addEventListener("dblclick",this.startEditing.bind(this,heightElement,"height","height",style),false);boxElement.appendChild(widthElement);boxElement.appendChild(document.createTextNode(" \u00D7 "));boxElement.appendChild(heightElement);}else{var suffix=(name==="border"?"-width":"");var labelElement=document.createElement("div");labelElement.className="label";labelElement.textContent=boxLabels[i];boxElement.appendChild(labelElement);boxElement.appendChild(createBoxPartElement.call(this,style,name,"top",suffix));boxElement.appendChild(document.createElement("br"));boxElement.appendChild(createBoxPartElement.call(this,style,name,"left",suffix));if(previousBox)
boxElement.appendChild(previousBox);boxElement.appendChild(createBoxPartElement.call(this,style,name,"right",suffix));boxElement.appendChild(document.createElement("br"));boxElement.appendChild(createBoxPartElement.call(this,style,name,"bottom",suffix));}
previousBox=boxElement;}
metricsElement.appendChild(previousBox);metricsElement.addEventListener("mouseover",this._highlightDOMNode.bind(this,false,""),false);this.bodyElement.removeChildren();this.bodyElement.appendChild(metricsElement);},startEditing:function(targetElement,box,styleProperty,computedStyle)
{if(WebInspector.isBeingEdited(targetElement))
return;var context={box:box,styleProperty:styleProperty,computedStyle:computedStyle};var boundKeyDown=this._handleKeyDown.bind(this,context,styleProperty);context.keyDownHandler=boundKeyDown;targetElement.addEventListener("keydown",boundKeyDown,false);this._isEditingMetrics=true;var config=new WebInspector.EditingConfig(this.editingCommitted.bind(this),this.editingCancelled.bind(this),context);WebInspector.startEditing(targetElement,config);window.getSelection().setBaseAndExtent(targetElement,0,targetElement,1);},_handleKeyDown:function(context,styleProperty,event)
{var element=event.currentTarget;function finishHandler(originalValue,replacementString)
{this._applyUserInput(element,replacementString,originalValue,context,false);}
function customNumberHandler(number)
{if(styleProperty!=="margin"&&number<0)
number=0;return number;}
WebInspector.handleElementValueModifications(event,element,finishHandler.bind(this),undefined,customNumberHandler);},editingEnded:function(element,context)
{delete this.originalPropertyData;delete this.previousPropertyDataCandidate;element.removeEventListener("keydown",context.keyDownHandler,false);delete this._isEditingMetrics;},editingCancelled:function(element,context)
{if("originalPropertyData"in this&&this.inlineStyle){if(!this.originalPropertyData){var pastLastSourcePropertyIndex=this.inlineStyle.pastLastSourcePropertyIndex();if(pastLastSourcePropertyIndex)
this.inlineStyle.allProperties[pastLastSourcePropertyIndex-1].setText("",false);}else
this.inlineStyle.allProperties[this.originalPropertyData.index].setText(this.originalPropertyData.propertyText,false);}
this.editingEnded(element,context);this.update();},_applyUserInput:function(element,userInput,previousContent,context,commitEditor)
{if(!this.inlineStyle){return this.editingCancelled(element,context);}
if(commitEditor&&userInput===previousContent)
return this.editingCancelled(element,context);if(context.box!=="position"&&(!userInput||userInput==="\u2012"))
userInput="0px";else if(context.box==="position"&&(!userInput||userInput==="\u2012"))
userInput="auto";userInput=userInput.toLowerCase();if(/^\d+$/.test(userInput))
userInput+="px";var styleProperty=context.styleProperty;var computedStyle=context.computedStyle;if(computedStyle.getPropertyValue("box-sizing")==="border-box"&&(styleProperty==="width"||styleProperty==="height")){if(!userInput.match(/px$/)){WebInspector.log("For elements with box-sizing: border-box, only absolute content area dimensions can be applied",WebInspector.ConsoleMessage.MessageLevel.Error,true);return;}
var borderBox=this._getBox(computedStyle,"border");var paddingBox=this._getBox(computedStyle,"padding");var userValuePx=Number(userInput.replace(/px$/,""));if(isNaN(userValuePx))
return;if(styleProperty==="width")
userValuePx+=borderBox.left+borderBox.right+paddingBox.left+paddingBox.right;else
userValuePx+=borderBox.top+borderBox.bottom+paddingBox.top+paddingBox.bottom;userInput=userValuePx+"px";}
this.previousPropertyDataCandidate=null;var self=this;var callback=function(style){if(!style)
return;self.inlineStyle=style;if(!("originalPropertyData"in self))
self.originalPropertyData=self.previousPropertyDataCandidate;if(typeof self._highlightMode!=="undefined"){WebInspector.domAgent.highlightDOMNode(self.node.id,self._highlightMode);}
if(commitEditor){self.dispatchEventToListeners("metrics edited");self.update();}};var allProperties=this.inlineStyle.allProperties;for(var i=0;i<allProperties.length;++i){var property=allProperties[i];if(property.name!==context.styleProperty||property.inactive)
continue;this.previousPropertyDataCandidate=property;property.setValue(userInput,commitEditor,true,callback);return;}
this.inlineStyle.appendProperty(context.styleProperty,userInput,callback);},editingCommitted:function(element,userInput,previousContent,context)
{this.editingEnded(element,context);this._applyUserInput(element,userInput,previousContent,context,true);},__proto__:WebInspector.SidebarPane.prototype};WebInspector.OverridesView=function()
{WebInspector.View.call(this);this.registerRequiredCSS("overrides.css");this.registerRequiredCSS("helpScreen.css");this.element.classList.add("overrides-view","fill","vbox");this._tabbedPane=new WebInspector.TabbedPane();this._tabbedPane.shrinkableTabs=false;this._tabbedPane.verticalTabLayout=true;new WebInspector.OverridesView.DeviceTab().appendAsTab(this._tabbedPane);new WebInspector.OverridesView.ViewportTab().appendAsTab(this._tabbedPane);new WebInspector.OverridesView.UserAgentTab().appendAsTab(this._tabbedPane);new WebInspector.OverridesView.SensorsTab().appendAsTab(this._tabbedPane);this._lastSelectedTabSetting=WebInspector.settings.createSetting("lastSelectedEmulateTab","device");this._tabbedPane.selectTab(this._lastSelectedTabSetting.get());this._tabbedPane.addEventListener(WebInspector.TabbedPane.EventTypes.TabSelected,this._tabSelected,this);this._tabbedPane.show(this.element);this._warningFooter=this.element.createChild("div","overrides-footer");this._overridesWarningUpdated();WebInspector.overridesSupport.addEventListener(WebInspector.OverridesSupport.Events.OverridesWarningUpdated,this._overridesWarningUpdated,this);}
WebInspector.OverridesView.prototype={_tabSelected:function(event)
{this._lastSelectedTabSetting.set(this._tabbedPane.selectedTabId);},_overridesWarningUpdated:function()
{var message=WebInspector.overridesSupport.warningMessage();this._warningFooter.enableStyleClass("hidden",!message);this._warningFooter.textContent=message;},__proto__:WebInspector.View.prototype}
WebInspector.OverridesView.Tab=function(id,name,settings)
{WebInspector.View.call(this);this._id=id;this._name=name;this._settings=settings;for(var i=0;i<settings.length;++i)
settings[i].addChangeListener(this._updateActiveState,this);}
WebInspector.OverridesView.Tab.prototype={appendAsTab:function(tabbedPane)
{this._tabbedPane=tabbedPane;tabbedPane.appendTab(this._id,this._name,this);this._updateActiveState();},_updateActiveState:function()
{var active=false;for(var i=0;!active&&i<this._settings.length;++i)
active=this._settings[i].get();this._tabbedPane.element.enableStyleClass("overrides-activate-"+this._id,active);this._tabbedPane.changeTabTitle(this._id,active?this._name+" \u2713":this._name);},_createInput:function(parentElement,id,defaultText,eventListener,numeric)
{var element=parentElement.createChild("input");element.id=id;element.type="text";element.maxLength=12;element.style.width="80px";element.value=defaultText;element.align="right";if(numeric)
element.className="numeric";element.addEventListener("input",eventListener,false);element.addEventListener("keydown",keyDownListener,false);function keyDownListener(event)
{if(isEnterKey(event))
eventListener(event);}
return element;},_createNonPersistedCheckbox:function(title,callback)
{var labelElement=document.createElement("label");var checkboxElement=labelElement.createChild("input");checkboxElement.type="checkbox";checkboxElement.checked=false;checkboxElement.addEventListener("click",onclick,false);labelElement.appendChild(document.createTextNode(title));return labelElement;function onclick()
{callback(checkboxElement.checked);}},_createSettingCheckbox:function(name,setting,callback)
{var checkbox=WebInspector.SettingsTab.createCheckbox(name,setting.get.bind(setting),listener,true);function listener(value)
{if(setting.get()===value)
return;setting.set(value);if(callback)
callback(value);}
setting.addChangeListener(changeListener);function changeListener()
{if(checkbox.firstChild.checked!==setting.get())
checkbox.firstChild.checked=setting.get();}
return checkbox;}}
WebInspector.OverridesView.Tab.prototype.__proto__=WebInspector.View.prototype;WebInspector.OverridesView.DeviceTab=function()
{WebInspector.OverridesView.Tab.call(this,"device",WebInspector.UIString("Device"),[]);this.element.classList.add("overrides-device");this._emulatedDeviceSetting=WebInspector.settings.createSetting("emulatedDevice","Google Nexus 4");this._emulateDeviceViewportSetting=WebInspector.settings.overrideDeviceMetrics;this._emulateDeviceUserAgentSetting=WebInspector.settings.overrideUserAgent;this._deviceSelectElement=this.element.createChild("select");var devices=WebInspector.OverridesView.DeviceTab._phones.concat(WebInspector.OverridesView.DeviceTab._tablets);devices.sort();var selectionRestored=false;for(var i=0;i<devices.length;++i){var device=devices[i];var option=new Option(device[0],device[0]);option._userAgent=device[1];option._metrics=device[2];this._deviceSelectElement.add(option);if(this._emulatedDeviceSetting.get()===device[0]){this._deviceSelectElement.selectedIndex=i;selectionRestored=true;}}
if(!selectionRestored)
this._deviceSelectElement.selectedIndex=devices.length-1;this._deviceSelectElement.addEventListener("change",this._deviceSelected.bind(this),false);this._deviceSelectElement.addEventListener("dblclick",this._emulateButtonClicked.bind(this),false);this._deviceSelectElement.addEventListener("keypress",this._keyPressed.bind(this),false);this._deviceSelectElement.disabled=WebInspector.isInspectingDevice();var buttonsBar=this.element.createChild("div");var emulateButton=buttonsBar.createChild("button","settings-tab-text-button");emulateButton.textContent=WebInspector.UIString("Emulate");emulateButton.addEventListener("click",this._emulateButtonClicked.bind(this),false);emulateButton.disabled=WebInspector.isInspectingDevice();this._emulateButton=emulateButton;var resetButton=buttonsBar.createChild("button","settings-tab-text-button");resetButton.textContent=WebInspector.UIString("Reset");resetButton.addEventListener("click",this._resetButtonClicked.bind(this),false);this._viewportValueLabel=this.element.createChild("div","overrides-device-value-label");this._viewportValueLabel.textContent=WebInspector.UIString("Viewport:");this._viewportValueElement=this._viewportValueLabel.createChild("span","overrides-device-value");this._userAgentLabel=this.element.createChild("div","overrides-device-value-label");this._userAgentLabel.textContent=WebInspector.UIString("User agent:");this._userAgentValueElement=this._userAgentLabel.createChild("span","overrides-device-value");this._updateValueLabels();}
WebInspector.OverridesView.DeviceTab._phones=[["Apple iPhone 3GS","Mozilla/5.0 (iPhone; U; CPU iPhone OS 4_2_1 like Mac OS X; en-us) AppleWebKit/533.17.9 (KHTML, like Gecko) Version/5.0.2 Mobile/8C148 Safari/6533.18.5","320x480x1"],["Apple iPhone 4","Mozilla/5.0 (iPhone; U; CPU iPhone OS 4_2_1 like Mac OS X; en-us) AppleWebKit/533.17.9 (KHTML, like Gecko) Version/5.0.2 Mobile/8C148 Safari/6533.18.5","640x960x2"],["Apple iPhone 5","Mozilla/5.0 (iPhone; CPU iPhone OS 7_0 like Mac OS X; en-us) AppleWebKit/537.51.1 (KHTML, like Gecko) Version/7.0 Mobile/11A465 Safari/9537.53","640x1136x2"],["BlackBerry Z10","Mozilla/5.0 (BB10; Touch) AppleWebKit/537.10+ (KHTML, like Gecko) Version/10.0.9.2372 Mobile Safari/537.10+","768x1280x2"],["BlackBerry Z30","Mozilla/5.0 (BB10; Touch) AppleWebKit/537.10+ (KHTML, like Gecko) Version/10.0.9.2372 Mobile Safari/537.10+","720x1280x2"],["Google Nexus 4","Mozilla/5.0 (Linux; Android 4.2.1; en-us; Nexus 4 Build/JOP40D) AppleWebKit/535.19 (KHTML, like Gecko) Chrome/18.0.1025.166 Mobile Safari/535.19","768x1280x2"],["Google Nexus 5","Mozilla/5.0 (Linux; Android 4.2.1; en-us; Nexus 5 Build/JOP40D) AppleWebKit/535.19 (KHTML, like Gecko) Chrome/18.0.1025.166 Mobile Safari/535.19","1080x1920x3"],["Google Nexus S","Mozilla/5.0 (Linux; U; Android 2.3.4; en-us; Nexus S Build/GRJ22) AppleWebKit/533.1 (KHTML, like Gecko) Version/4.0 Mobile Safari/533.1","480x800x1.5"],["HTC Evo, Touch HD, Desire HD, Desire","Mozilla/5.0 (Linux; U; Android 2.2; en-us; Sprint APA9292KT Build/FRF91) AppleWebKit/533.1 (KHTML, like Gecko) Version/4.0 Mobile Safari/533.1","480x800x1.5"],["HTC One X, EVO LTE","Mozilla/5.0 (Linux; Android 4.0.3; HTC One X Build/IML74K) AppleWebKit/535.19 (KHTML, like Gecko) Chrome/18.0.1025.133 Mobile Safari/535.19","720x1280x2"],["HTC Sensation, Evo 3D","Mozilla/5.0 (Linux; U; Android 4.0.3; en-us; HTC Sensation Build/IML74K) AppleWebKit/534.30 (KHTML, like Gecko) Version/4.0 Mobile Safari/534.30","540x960x1.5"],["LG Optimus 2X, Optimus 3D, Optimus Black","Mozilla/5.0 (Linux; U; Android 2.2; en-us; LG-P990/V08c Build/FRG83) AppleWebKit/533.1 (KHTML, like Gecko) Version/4.0 Mobile Safari/533.1 MMS/LG-Android-MMS-V1.0/1.2","480x800x1.5"],["LG Optimus G","Mozilla/5.0 (Linux; Android 4.0; LG-E975 Build/IMM76L) AppleWebKit/535.19 (KHTML, like Gecko) Chrome/18.0.1025.166 Mobile Safari/535.19","768x1280x2"],["LG Optimus LTE, Optimus 4X HD","Mozilla/5.0 (Linux; U; Android 2.3; en-us; LG-P930 Build/GRJ90) AppleWebKit/533.1 (KHTML, like Gecko) Version/4.0 Mobile Safari/533.1","720x1280x1.7"],["LG Optimus One","Mozilla/5.0 (Linux; U; Android 2.2.1; en-us; LG-MS690 Build/FRG83) AppleWebKit/533.1 (KHTML, like Gecko) Version/4.0 Mobile Safari/533.1","320x480x1.5"],["Motorola Defy, Droid, Droid X, Milestone","Mozilla/5.0 (Linux; U; Android 2.0; en-us; Milestone Build/ SHOLS_U2_01.03.1) AppleWebKit/530.17 (KHTML, like Gecko) Version/4.0 Mobile Safari/530.17","480x854x1.5"],["Motorola Droid 3, Droid 4, Droid Razr, Atrix 4G, Atrix 2","Mozilla/5.0 (Linux; U; Android 2.2; en-us; Droid Build/FRG22D) AppleWebKit/533.1 (KHTML, like Gecko) Version/4.0 Mobile Safari/533.1","540x960x1"],["Motorola Droid Razr HD","Mozilla/5.0 (Linux; U; Android 2.3; en-us; DROID RAZR 4G Build/6.5.1-73_DHD-11_M1-29) AppleWebKit/533.1 (KHTML, like Gecko) Version/4.0 Mobile Safari/533.1","720x1280x1"],["Nokia C5, C6, C7, N97, N8, X7","NokiaN97/21.1.107 (SymbianOS/9.4; Series60/5.0 Mozilla/5.0; Profile/MIDP-2.1 Configuration/CLDC-1.1) AppleWebkit/525 (KHTML, like Gecko) BrowserNG/7.1.4","360x640x1"],["Nokia Lumia 7X0, Lumia 8XX, Lumia 900, N800, N810, N900","Mozilla/5.0 (compatible; MSIE 10.0; Windows Phone 8.0; Trident/6.0; IEMobile/10.0; ARM; Touch; NOKIA; Lumia 820)","480x800x1.5"],["Samsung Galaxy Note 3","Mozilla/5.0 (Linux; U; Android 4.3; en-us; SM-N900T Build/JSS15J) AppleWebKit/534.30 (KHTML, like Gecko) Version/4.0 Mobile Safari/534.30","1080x1920x2"],["Samsung Galaxy Note II","Mozilla/5.0 (Linux; U; Android 4.1; en-us; GT-N7100 Build/JRO03C) AppleWebKit/534.30 (KHTML, like Gecko) Version/4.0 Mobile Safari/534.30","720x1280x2"],["Samsung Galaxy Note","Mozilla/5.0 (Linux; U; Android 2.3; en-us; SAMSUNG-SGH-I717 Build/GINGERBREAD) AppleWebKit/533.1 (KHTML, like Gecko) Version/4.0 Mobile Safari/533.1","800x1280x2"],["Samsung Galaxy S III, Galaxy Nexus","Mozilla/5.0 (Linux; U; Android 4.0; en-us; GT-I9300 Build/IMM76D) AppleWebKit/534.30 (KHTML, like Gecko) Version/4.0 Mobile Safari/534.30","720x1280x2"],["Samsung Galaxy S, S II, W","Mozilla/5.0 (Linux; U; Android 2.1; en-us; GT-I9000 Build/ECLAIR) AppleWebKit/525.10+ (KHTML, like Gecko) Version/3.0.4 Mobile Safari/523.12.2","480x800x1.5"],["Samsung Galaxy S4","Mozilla/5.0 (Linux; U; Android 2.1; en-us; GT-I9000 Build/ECLAIR) AppleWebKit/525.10+ (KHTML, like Gecko) Version/3.0.4 Mobile Safari/523.12.2","1080x1920x3"],["Sony Xperia S, Ion","Mozilla/5.0 (Linux; U; Android 4.0; en-us; LT28at Build/6.1.C.1.111) AppleWebKit/534.30 (KHTML, like Gecko) Version/4.0 Mobile Safari/534.30","720x1280x2"],["Sony Xperia Sola, U","Mozilla/5.0 (Linux; U; Android 2.3; en-us; SonyEricssonST25i Build/6.0.B.1.564) AppleWebKit/533.1 (KHTML, like Gecko) Version/4.0 Mobile Safari/533.1","480x854x1"],["Sony Xperia Z, Z1","Mozilla/5.0 (Linux; U; Android 4.2; en-us; SonyC6903 Build/14.1.G.1.518) AppleWebKit/534.30 (KHTML, like Gecko) Version/4.0 Mobile Safari/534.30","1080x1920x3"],];WebInspector.OverridesView.DeviceTab._tablets=[["Amazon Amazon Kindle Fire HD 7\"","Mozilla/5.0 (Linux; U; Android 2.3.4; en-us; Kindle Fire HD Build/GINGERBREAD) AppleWebKit/533.1 (KHTML, like Gecko) Version/4.0 Mobile Safari/533.1","1280x800x1.5"],["Amazon Amazon Kindle Fire HD 8.9\"","Mozilla/5.0 (Linux; U; Android 2.3.4; en-us; Kindle Fire HD Build/GINGERBREAD) AppleWebKit/533.1 (KHTML, like Gecko) Version/4.0 Mobile Safari/533.1","1920x1200x1.5"],["Amazon Amazon Kindle Fire","Mozilla/5.0 (Linux; U; Android 2.3.4; en-us; Kindle Fire Build/GINGERBREAD) AppleWebKit/533.1 (KHTML, like Gecko) Version/4.0 Mobile Safari/533.1","1024x600x1"],["Apple iPad 1 / 2 / iPad Mini","Mozilla/5.0 (iPad; CPU OS 4_3_5 like Mac OS X; en-us) AppleWebKit/533.17.9 (KHTML, like Gecko) Version/5.0.2 Mobile/8L1 Safari/6533.18.5","1024x768x1"],["Apple iPad 3 / 4","Mozilla/5.0 (iPad; CPU OS 7_0 like Mac OS X) AppleWebKit/537.51.1 (KHTML, like Gecko) Version/7.0 Mobile/11A465 Safari/9537.53","2048x1536x2"],["BlackBerry PlayBook","Mozilla/5.0 (PlayBook; U; RIM Tablet OS 2.1.0; en-US) AppleWebKit/536.2+ (KHTML like Gecko) Version/7.2.1.0 Safari/536.2+","1024x600x1"],["Google Nexus 10","Mozilla/5.0 (Linux; Android 4.3; Nexus 10 Build/JSS15Q) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/29.0.1547.72 Safari/537.36","2560x1600x2"],["Google Nexus 7 2","Mozilla/5.0 (Linux; Android 4.3; Nexus 7 Build/JSS15Q) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/29.0.1547.72 Safari/537.36","1920x1200x2"],["Google Nexus 7","Mozilla/5.0 (Linux; Android 4.3; Nexus 7 Build/JSS15Q) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/29.0.1547.72 Safari/537.36","1280x800x1.325"],["Motorola Xoom, Xyboard","Mozilla/5.0 (Linux; U; Android 3.0; en-us; Xoom Build/HRI39) AppleWebKit/525.10 (KHTML, like Gecko) Version/3.0.4 Mobile Safari/523.12.2","1280x800x1"],["Samsung Galaxy Tab 7.7, 8.9, 10.1","Mozilla/5.0 (Linux; U; Android 2.2; en-us; SCH-I800 Build/FROYO) AppleWebKit/533.1 (KHTML, like Gecko) Version/4.0 Mobile Safari/533.1","1280x800x1"],["Samsung Galaxy Tab","Mozilla/5.0 (Linux; U; Android 2.2; en-us; SCH-I800 Build/FROYO) AppleWebKit/533.1 (KHTML, like Gecko) Version/4.0 Mobile Safari/533.1","1024x600x1"],];WebInspector.OverridesView.DeviceTab.prototype={_keyPressed:function(e)
{if(e.keyCode===WebInspector.KeyboardShortcut.Keys.Enter.code)
this._emulateButtonClicked();},_emulateButtonClicked:function()
{var option=this._deviceSelectElement.options[this._deviceSelectElement.selectedIndex];WebInspector.overridesSupport.emulateDevice(option._metrics,option._userAgent);},_resetButtonClicked:function()
{WebInspector.overridesSupport.reset();},_deviceSelected:function()
{var option=this._deviceSelectElement.options[this._deviceSelectElement.selectedIndex];this._emulatedDeviceSetting.set(option.value);this._updateValueLabels();},_updateValueLabels:function()
{var option=this._deviceSelectElement.options[this._deviceSelectElement.selectedIndex];var metrics;if(option._metrics&&(metrics=WebInspector.OverridesSupport.DeviceMetrics.parseSetting(option._metrics)))
this._viewportValueElement.textContent=WebInspector.UIString("%s \u00D7 %s, devicePixelRatio = %s",metrics.width,metrics.height,metrics.deviceScaleFactor);else
this._viewportValueElement.textContent="";this._userAgentValueElement.textContent=option._userAgent||"";}}
WebInspector.OverridesView.DeviceTab.prototype.__proto__=WebInspector.OverridesView.Tab.prototype;WebInspector.OverridesView.ViewportTab=function()
{WebInspector.OverridesView.Tab.call(this,"viewport",WebInspector.UIString("Screen"),[WebInspector.settings.overrideDeviceMetrics,WebInspector.settings.overrideCSSMedia]);this.element.classList.add("overrides-viewport");const metricsSetting=WebInspector.settings.deviceMetrics.get();var metrics=WebInspector.OverridesSupport.DeviceMetrics.parseSetting(metricsSetting);var checkbox=this._createSettingCheckbox(WebInspector.UIString("Emulate screen"),WebInspector.settings.overrideDeviceMetrics,this._onMetricsCheckboxClicked.bind(this));checkbox.firstChild.disabled=WebInspector.isInspectingDevice();WebInspector.settings.deviceMetrics.addChangeListener(this._updateDeviceMetricsElement,this);this.element.appendChild(checkbox);this.element.appendChild(this._createDeviceMetricsElement(metrics));this.element.appendChild(this._createMediaEmulationElement());var footnote=this.element.createChild("p","help-footnote");var footnoteLink=footnote.createChild("a");footnoteLink.href="https://developers.google.com/chrome-developer-tools/docs/mobile-emulation";footnoteLink.target="_blank";footnoteLink.createTextChild(WebInspector.UIString("More information about screen emulation"));this._onMetricsCheckboxClicked(WebInspector.settings.overrideDeviceMetrics.get());}
WebInspector.OverridesView.ViewportTab.prototype={_onMetricsCheckboxClicked:function(enabled)
{if(enabled&&!this._widthOverrideElement.value)
this._widthOverrideElement.focus();},_applyDeviceMetricsUserInput:function()
{this._muteRangeListener=true;this._widthRangeInput.value=this._widthOverrideElement.value;delete this._muteRangeListener;if(this._applyDeviceMetricsTimer)
clearTimeout(this._applyDeviceMetricsTimer);this._applyDeviceMetricsTimer=setTimeout(this._doApplyDeviceMetricsUserInput.bind(this),50);},_doApplyDeviceMetricsUserInput:function()
{delete this._applyDeviceMetricsTimer;this._setDeviceMetricsOverride(WebInspector.OverridesSupport.DeviceMetrics.parseUserInput(this._widthOverrideElement.value.trim(),this._heightOverrideElement.value.trim(),this._deviceScaleFactorOverrideElement.value.trim(),this._textAutosizingOverrideCheckbox.checked),true);},_setDeviceMetricsOverride:function(metrics,userInputModified)
{function setValid(condition,element)
{if(condition)
element.classList.remove("error-input");else
element.classList.add("error-input");}
setValid(metrics&&metrics.isWidthValid(),this._widthOverrideElement);setValid(metrics&&metrics.isHeightValid(),this._heightOverrideElement);setValid(metrics&&metrics.isDeviceScaleFactorValid(),this._deviceScaleFactorOverrideElement);if(!metrics)
return;if(!userInputModified){this._widthOverrideElement.value=metrics.widthToInput();this._heightOverrideElement.value=metrics.heightToInput();this._deviceScaleFactorOverrideElement.value=metrics.deviceScaleFactorToInput();this._textAutosizingOverrideCheckbox.checked=metrics.textAutosizing;}
if(metrics.isValid()){var value=metrics.toSetting();if(value!==WebInspector.settings.deviceMetrics.get())
WebInspector.settings.deviceMetrics.set(value);}},_createDeviceMetricsElement:function(metrics)
{var fieldsetElement=WebInspector.SettingsTab.createSettingFieldset(WebInspector.settings.overrideDeviceMetrics);fieldsetElement.disabled=WebInspector.isInspectingDevice();fieldsetElement.id="metrics-override-section";function swapDimensionsClicked()
{var widthValue=this._widthOverrideElement.value;this._widthOverrideElement.value=this._heightOverrideElement.value;this._heightOverrideElement.value=widthValue;this._applyDeviceMetricsUserInput();}
var tableElement=fieldsetElement.createChild("table","nowrap");var rowElement=tableElement.createChild("tr");var cellElement=rowElement.createChild("td");cellElement.appendChild(document.createTextNode(WebInspector.UIString("Resolution:")));cellElement=rowElement.createChild("td");this._widthOverrideElement=this._createInput(cellElement,"metrics-override-width",String(metrics.width||screen.width),this._applyDeviceMetricsUserInput.bind(this),true);this._swapDimensionsElement=cellElement.createChild("button","overrides-swap");this._swapDimensionsElement.appendChild(document.createTextNode(" \u21C4 "));this._swapDimensionsElement.title=WebInspector.UIString("Swap dimensions");this._swapDimensionsElement.addEventListener("click",swapDimensionsClicked.bind(this),false);this._swapDimensionsElement.tabIndex=-1;this._heightOverrideElement=this._createInput(cellElement,"metrics-override-height",String(metrics.height||screen.height),this._applyDeviceMetricsUserInput.bind(this),true);rowElement=tableElement.createChild("tr");cellElement=rowElement.createChild("td");cellElement.colSpan=4;this._widthRangeInput=cellElement.createChild("input");this._widthRangeInput.type="range";this._widthRangeInput.min=100;this._widthRangeInput.max=2000;this._widthRangeInput.addEventListener("change",this._rangeValueChanged.bind(this),false);this._widthRangeInput.value=this._widthOverrideElement.value;rowElement=tableElement.createChild("tr");rowElement.title=WebInspector.UIString("Ratio between a device's physical pixels and device-independent pixels.");cellElement=rowElement.createChild("td");cellElement.appendChild(document.createTextNode(WebInspector.UIString("Device pixel ratio:")));cellElement=rowElement.createChild("td");this._deviceScaleFactorOverrideElement=this._createInput(cellElement,"metrics-override-device-scale",String(metrics.deviceScaleFactor||1),this._applyDeviceMetricsUserInput.bind(this),true);var textAutosizingOverrideElement=this._createNonPersistedCheckbox(WebInspector.UIString("Enable text autosizing "),this._applyDeviceMetricsUserInput.bind(this));textAutosizingOverrideElement.title=WebInspector.UIString("Text autosizing is the feature that boosts font sizes on mobile devices.");this._textAutosizingOverrideCheckbox=textAutosizingOverrideElement.firstChild;this._textAutosizingOverrideCheckbox.checked=metrics.textAutosizing;fieldsetElement.appendChild(textAutosizingOverrideElement);var checkbox=this._createSettingCheckbox(WebInspector.UIString("Emulate viewport"),WebInspector.settings.emulateViewport);fieldsetElement.appendChild(checkbox);checkbox=this._createSettingCheckbox(WebInspector.UIString("Shrink to fit"),WebInspector.settings.deviceFitWindow);fieldsetElement.appendChild(checkbox);return fieldsetElement;},_updateDeviceMetricsElement:function()
{const metricsSetting=WebInspector.settings.deviceMetrics.get();var metrics=WebInspector.OverridesSupport.DeviceMetrics.parseSetting(metricsSetting);if(this._widthOverrideElement.value!==metrics.width)
this._widthOverrideElement.value=metrics.width||screen.width;this._muteRangeListener=true;if(this._widthRangeInput.value!=metrics.width)
this._widthRangeInput.value=metrics.width||screen.width;delete this._muteRangeListener;if(this._heightOverrideElement.value!==metrics.height)
this._heightOverrideElement.value=metrics.height||screen.height;if(this._deviceScaleFactorOverrideElement.value!==metrics.deviceScaleFactor)
this._deviceScaleFactorOverrideElement.value=metrics.deviceScaleFactor||1;if(this._textAutosizingOverrideCheckbox.checked!==metrics.textAutosizing)
this._textAutosizingOverrideCheckbox.checked=metrics.textAutosizing||false;},_createMediaEmulationElement:function()
{var checkbox=WebInspector.SettingsTab.createSettingCheckbox(WebInspector.UIString("CSS media"),WebInspector.settings.overrideCSSMedia,true);var fieldsetElement=WebInspector.SettingsTab.createSettingFieldset(WebInspector.settings.overrideCSSMedia);fieldsetElement.disabled=WebInspector.isInspectingDevice();checkbox.appendChild(fieldsetElement);var mediaSelectElement=fieldsetElement.createChild("select");var mediaTypes=WebInspector.CSSStyleModel.MediaTypes;var defaultMedia=WebInspector.settings.emulatedCSSMedia.get();for(var i=0;i<mediaTypes.length;++i){var mediaType=mediaTypes[i];if(mediaType==="all"){continue;}
var option=document.createElement("option");option.text=mediaType;option.value=mediaType;mediaSelectElement.add(option);if(mediaType===defaultMedia)
mediaSelectElement.selectedIndex=mediaSelectElement.options.length-1;}
mediaSelectElement.addEventListener("change",this._emulateMediaChanged.bind(this,mediaSelectElement),false);return checkbox;},_emulateMediaChanged:function(select)
{var media=select.options[select.selectedIndex].value;WebInspector.settings.emulatedCSSMedia.set(media);},_rangeValueChanged:function()
{if(this._muteRangeListener)
return;this._widthOverrideElement.value=this._widthRangeInput.value;this._applyDeviceMetricsUserInput();}}
WebInspector.OverridesView.ViewportTab.prototype.__proto__=WebInspector.OverridesView.Tab.prototype;WebInspector.OverridesView.UserAgentTab=function()
{WebInspector.OverridesView.Tab.call(this,"user-agent",WebInspector.UIString("User Agent"),[WebInspector.settings.overrideUserAgent]);this.element.classList.add("overrides-user-agent");var checkbox=this._createSettingCheckbox(WebInspector.UIString("Spoof user agent"),WebInspector.settings.overrideUserAgent);checkbox.firstChild.disabled=WebInspector.isInspectingDevice();this.element.appendChild(checkbox);this.element.appendChild(this._createUserAgentSelectRowElement());}
WebInspector.OverridesView.UserAgentTab._userAgents=[["Internet Explorer 10","Mozilla/5.0 (compatible; MSIE 10.0; Windows NT 6.2; Trident/6.0)"],["Internet Explorer 9","Mozilla/5.0 (compatible; MSIE 9.0; Windows NT 6.1; Trident/5.0)"],["Internet Explorer 8","Mozilla/4.0 (compatible; MSIE 8.0; Windows NT 6.0; Trident/4.0)"],["Internet Explorer 7","Mozilla/4.0 (compatible; MSIE 7.0; Windows NT 6.0)"],["Firefox 7 \u2014 Windows","Mozilla/5.0 (Windows NT 6.1; Intel Mac OS X 10.6; rv:7.0.1) Gecko/20100101 Firefox/7.0.1"],["Firefox 7 \u2014 Mac","Mozilla/5.0 (Macintosh; Intel Mac OS X 10.6; rv:7.0.1) Gecko/20100101 Firefox/7.0.1"],["Firefox 4 \u2014 Windows","Mozilla/5.0 (Windows NT 6.1; rv:2.0.1) Gecko/20100101 Firefox/4.0.1"],["Firefox 4 \u2014 Mac","Mozilla/5.0 (Macintosh; Intel Mac OS X 10.6; rv:2.0.1) Gecko/20100101 Firefox/4.0.1"],["Firefox 14 \u2014 Android Mobile","Mozilla/5.0 (Android; Mobile; rv:14.0) Gecko/14.0 Firefox/14.0"],["Firefox 14 \u2014 Android Tablet","Mozilla/5.0 (Android; Tablet; rv:14.0) Gecko/14.0 Firefox/14.0"],["Chrome \u2014 Android Mobile","Mozilla/5.0 (Linux; Android 4.0.4; Galaxy Nexus Build/IMM76B) AppleWebKit/535.19 (KHTML, like Gecko) Chrome/18.0.1025.133 Mobile Safari/535.19"],["Chrome \u2014 Android Tablet","Mozilla/5.0 (Linux; Android 4.1.2; Nexus 7 Build/JZ054K) AppleWebKit/535.19 (KHTML, like Gecko) Chrome/18.0.1025.166 Safari/535.19"],["iPhone \u2014 iOS 7","Mozilla/5.0 (iPhone; CPU iPhone OS 7_0_2 like Mac OS X) AppleWebKit/537.51.1 (KHTML, like Gecko) Version/7.0 Mobile/11A4449d Safari/9537.53"],["iPhone \u2014 iOS 6","Mozilla/5.0 (iPhone; CPU iPhone OS 6_0 like Mac OS X) AppleWebKit/536.26 (KHTML, like Gecko) Version/6.0 Mobile/10A5376e Safari/8536.25"],["iPad \u2014 iOS 7","Mozilla/5.0 (iPad; CPU OS 7_0_2 like Mac OS X) AppleWebKit/537.51.1 (KHTML, like Gecko) Version/7.0 Mobile/11A501 Safari/9537.53"],["iPad \u2014 iOS 6","Mozilla/5.0 (iPad; CPU OS 6_0 like Mac OS X) AppleWebKit/536.26 (KHTML, like Gecko) Version/6.0 Mobile/10A5376e Safari/8536.25"],["Android 2.3 \u2014 Nexus S","Mozilla/5.0 (Linux; U; Android 2.3.6; en-us; Nexus S Build/GRK39F) AppleWebKit/533.1 (KHTML, like Gecko) Version/4.0 Mobile Safari/533.1"],["Android 4.0.2 \u2014 Galaxy Nexus","Mozilla/5.0 (Linux; U; Android 4.0.2; en-us; Galaxy Nexus Build/ICL53F) AppleWebKit/534.30 (KHTML, like Gecko) Version/4.0 Mobile Safari/534.30"],["BlackBerry \u2014 PlayBook 2.1","Mozilla/5.0 (PlayBook; U; RIM Tablet OS 2.1.0; en-US) AppleWebKit/536.2+ (KHTML, like Gecko) Version/7.2.1.0 Safari/536.2+"],["BlackBerry \u2014 9900","Mozilla/5.0 (BlackBerry; U; BlackBerry 9900; en-US) AppleWebKit/534.11+ (KHTML, like Gecko) Version/7.0.0.187 Mobile Safari/534.11+"],["BlackBerry \u2014 BB10","Mozilla/5.0 (BB10; Touch) AppleWebKit/537.1+ (KHTML, like Gecko) Version/10.0.0.1337 Mobile Safari/537.1+"],["MeeGo \u2014 Nokia N9","Mozilla/5.0 (MeeGo; NokiaN9) AppleWebKit/534.13 (KHTML, like Gecko) NokiaBrowser/8.5.0 Mobile Safari/534.13"],];WebInspector.OverridesView.UserAgentTab.prototype={_createUserAgentSelectRowElement:function()
{var userAgent=WebInspector.settings.userAgent.get();var userAgents=WebInspector.OverridesView.UserAgentTab._userAgents.concat([[WebInspector.UIString("Other"),"Other"]]);var fieldsetElement=WebInspector.SettingsTab.createSettingFieldset(WebInspector.settings.overrideUserAgent);fieldsetElement.disabled=WebInspector.isInspectingDevice();this._selectElement=fieldsetElement.createChild("select");fieldsetElement.createChild("br");this._otherUserAgentElement=fieldsetElement.createChild("input");this._otherUserAgentElement.type="text";this._otherUserAgentElement.value=userAgent;this._otherUserAgentElement.title=userAgent;var selectionRestored=false;for(var i=0;i<userAgents.length;++i){var agent=userAgents[i];var option=new Option(agent[0],agent[1]);option._metrics=agent[2]?agent[2]:"";this._selectElement.add(option);if(userAgent===agent[1]){this._selectElement.selectedIndex=i;selectionRestored=true;}}
if(!selectionRestored){if(!userAgent)
this._selectElement.selectedIndex=0;else
this._selectElement.selectedIndex=userAgents.length-1;}
this._selectElement.addEventListener("change",this._userAgentChanged.bind(this,true),false);WebInspector.settings.userAgent.addChangeListener(this._userAgentSettingChanged,this);fieldsetElement.addEventListener("dblclick",textDoubleClicked.bind(this),false);this._otherUserAgentElement.addEventListener("blur",textChanged.bind(this),false);function textDoubleClicked()
{this._selectElement.selectedIndex=userAgents.length-1;this._userAgentChanged();}
function textChanged()
{if(WebInspector.settings.userAgent.get()!==this._otherUserAgentElement.value)
WebInspector.settings.userAgent.set(this._otherUserAgentElement.value);}
return fieldsetElement;},_userAgentChanged:function(isUserGesture)
{var value=this._selectElement.options[this._selectElement.selectedIndex].value;if(value!=="Other"){WebInspector.settings.userAgent.set(value);this._otherUserAgentElement.value=value;this._otherUserAgentElement.title=value;this._otherUserAgentElement.disabled=true;}else{this._otherUserAgentElement.disabled=false;this._otherUserAgentElement.focus();}},_userAgentSettingChanged:function()
{var value=WebInspector.settings.userAgent.get();var options=this._selectElement.options;var foundMatch=false;for(var i=0;i<options.length;++i){if(options[i].value===value){if(this._selectElement.selectedIndex!==i)
this._selectElement.selectedIndex=i;foundMatch=true;break;}}
this._otherUserAgentElement.disabled=foundMatch;if(!foundMatch)
this._selectElement.selectedIndex=options.length-1;if(this._otherUserAgentElement.value!==value){this._otherUserAgentElement.value=value;this._otherUserAgentElement.title=value;}}}
WebInspector.OverridesView.UserAgentTab.prototype.__proto__=WebInspector.OverridesView.Tab.prototype;WebInspector.OverridesView.SensorsTab=function()
{WebInspector.OverridesView.Tab.call(this,"sensors",WebInspector.UIString("Sensors"),[WebInspector.settings.emulateTouchEvents,WebInspector.settings.overrideGeolocation,WebInspector.settings.overrideDeviceOrientation]);this.element.classList.add("overrides-sensors");this.registerRequiredCSS("accelerometer.css");if(!WebInspector.isInspectingDevice())
this.element.appendChild(this._createSettingCheckbox(WebInspector.UIString("Emulate touch screen"),WebInspector.settings.emulateTouchEvents));this._appendGeolocationOverrideControl();if(!WebInspector.isInspectingDevice())
this._apendDeviceOrientationOverrideControl();}
WebInspector.OverridesView.SensorsTab.prototype={_appendGeolocationOverrideControl:function()
{const geolocationSetting=WebInspector.settings.geolocationOverride.get();var geolocation=WebInspector.OverridesSupport.GeolocationPosition.parseSetting(geolocationSetting);this.element.appendChild(this._createSettingCheckbox(WebInspector.UIString("Emulate geolocation coordinates"),WebInspector.settings.overrideGeolocation,this._geolocationOverrideCheckboxClicked.bind(this)));this.element.appendChild(this._createGeolocationOverrideElement(geolocation));this._geolocationOverrideCheckboxClicked(WebInspector.settings.overrideGeolocation.get());},_geolocationOverrideCheckboxClicked:function(enabled)
{if(enabled&&!this._latitudeElement.value)
this._latitudeElement.focus();},_applyGeolocationUserInput:function()
{this._setGeolocationPosition(WebInspector.OverridesSupport.GeolocationPosition.parseUserInput(this._latitudeElement.value.trim(),this._longitudeElement.value.trim(),this._geolocationErrorElement.checked),true);},_setGeolocationPosition:function(geolocation,userInputModified)
{if(!geolocation)
return;if(!userInputModified){this._latitudeElement.value=geolocation.latitude;this._longitudeElement.value=geolocation.longitude;}
var value=geolocation.toSetting();WebInspector.settings.geolocationOverride.set(value);},_createGeolocationOverrideElement:function(geolocation)
{var fieldsetElement=WebInspector.SettingsTab.createSettingFieldset(WebInspector.settings.overrideGeolocation);fieldsetElement.id="geolocation-override-section";var tableElement=fieldsetElement.createChild("table");var rowElement=tableElement.createChild("tr");var cellElement=rowElement.createChild("td");cellElement=rowElement.createChild("td");cellElement.appendChild(document.createTextNode(WebInspector.UIString("Lat = ")));this._latitudeElement=this._createInput(cellElement,"geolocation-override-latitude",String(geolocation.latitude),this._applyGeolocationUserInput.bind(this),true);cellElement.appendChild(document.createTextNode(" , "));cellElement.appendChild(document.createTextNode(WebInspector.UIString("Lon = ")));this._longitudeElement=this._createInput(cellElement,"geolocation-override-longitude",String(geolocation.longitude),this._applyGeolocationUserInput.bind(this),true);rowElement=tableElement.createChild("tr");cellElement=rowElement.createChild("td");cellElement.colSpan=2;var geolocationErrorLabelElement=document.createElement("label");var geolocationErrorCheckboxElement=geolocationErrorLabelElement.createChild("input");geolocationErrorCheckboxElement.id="geolocation-error";geolocationErrorCheckboxElement.type="checkbox";geolocationErrorCheckboxElement.checked=!geolocation||geolocation.error;geolocationErrorCheckboxElement.addEventListener("click",this._applyGeolocationUserInput.bind(this),false);geolocationErrorLabelElement.appendChild(document.createTextNode(WebInspector.UIString("Emulate position unavailable")));this._geolocationErrorElement=geolocationErrorCheckboxElement;cellElement.appendChild(geolocationErrorLabelElement);return fieldsetElement;},_apendDeviceOrientationOverrideControl:function()
{const deviceOrientationSetting=WebInspector.settings.deviceOrientationOverride.get();var deviceOrientation=WebInspector.OverridesSupport.DeviceOrientation.parseSetting(deviceOrientationSetting);this.element.appendChild(this._createSettingCheckbox(WebInspector.UIString("Accelerometer"),WebInspector.settings.overrideDeviceOrientation,this._deviceOrientationOverrideCheckboxClicked.bind(this)));this.element.appendChild(this._createDeviceOrientationOverrideElement(deviceOrientation));this._deviceOrientationOverrideCheckboxClicked(WebInspector.settings.overrideDeviceOrientation.get());},_deviceOrientationOverrideCheckboxClicked:function(enabled)
{if(enabled&&!this._alphaElement.value)
this._alphaElement.focus();},_applyDeviceOrientationUserInput:function()
{this._setDeviceOrientation(WebInspector.OverridesSupport.DeviceOrientation.parseUserInput(this._alphaElement.value.trim(),this._betaElement.value.trim(),this._gammaElement.value.trim()),WebInspector.OverridesView.SensorsTab.DeviceOrientationModificationSource.UserInput);},_resetDeviceOrientation:function()
{this._setDeviceOrientation(new WebInspector.OverridesSupport.DeviceOrientation(0,0,0),WebInspector.OverridesView.SensorsTab.DeviceOrientationModificationSource.ResetButton);},_setDeviceOrientation:function(deviceOrientation,modificationSource)
{if(!deviceOrientation)
return;if(modificationSource!=WebInspector.OverridesView.SensorsTab.DeviceOrientationModificationSource.UserInput){this._alphaElement.value=deviceOrientation.alpha;this._betaElement.value=deviceOrientation.beta;this._gammaElement.value=deviceOrientation.gamma;}
if(modificationSource!=WebInspector.OverridesView.SensorsTab.DeviceOrientationModificationSource.UserDrag)
this._setBoxOrientation(deviceOrientation);var value=deviceOrientation.toSetting();WebInspector.settings.deviceOrientationOverride.set(value);},_createAxisInput:function(parentElement,id,label,defaultText)
{var div=parentElement.createChild("div","accelerometer-axis-input-container");div.appendChild(document.createTextNode(label));return this._createInput(div,id,defaultText,this._applyDeviceOrientationUserInput.bind(this),true);},_createDeviceOrientationOverrideElement:function(deviceOrientation)
{var fieldsetElement=WebInspector.SettingsTab.createSettingFieldset(WebInspector.settings.overrideDeviceOrientation);fieldsetElement.id="device-orientation-override-section";var tableElement=fieldsetElement.createChild("table");var rowElement=tableElement.createChild("tr");var cellElement=rowElement.createChild("td","accelerometer-inputs-cell");this._alphaElement=this._createAxisInput(cellElement,"device-orientation-override-alpha","\u03B1: ",String(deviceOrientation.alpha));this._betaElement=this._createAxisInput(cellElement,"device-orientation-override-beta","\u03B2: ",String(deviceOrientation.beta));this._gammaElement=this._createAxisInput(cellElement,"device-orientation-override-gamma","\u03B3: ",String(deviceOrientation.gamma));var resetButton=cellElement.createChild("button","settings-tab-text-button accelerometer-reset-button");resetButton.textContent=WebInspector.UIString("Reset");resetButton.addEventListener("click",this._resetDeviceOrientation.bind(this),false);this._stageElement=rowElement.createChild("td","accelerometer-stage");this._boxElement=this._stageElement.createChild("section","accelerometer-box");this._boxElement.createChild("section","front");this._boxElement.createChild("section","top");this._boxElement.createChild("section","back");this._boxElement.createChild("section","left");this._boxElement.createChild("section","right");this._boxElement.createChild("section","bottom");WebInspector.installDragHandle(this._stageElement,this._onBoxDragStart.bind(this),this._onBoxDrag.bind(this),this._onBoxDragEnd.bind(this),"move");this._setBoxOrientation(deviceOrientation);return fieldsetElement;},_setBoxOrientation:function(deviceOrientation)
{var matrix=new WebKitCSSMatrix();this._boxMatrix=matrix.rotate(deviceOrientation.beta,deviceOrientation.gamma,deviceOrientation.alpha);this._boxElement.style.webkitTransform=this._boxMatrix.toString();},_onBoxDrag:function(event)
{var mouseMoveVector=this._calculateRadiusVector(event.x,event.y);if(!mouseMoveVector)
return true;event.consume(true);var axis=WebInspector.Geometry.crossProduct(this._mouseDownVector,mouseMoveVector);axis.normalize();var angle=WebInspector.Geometry.calculateAngle(this._mouseDownVector,mouseMoveVector);var matrix=new WebKitCSSMatrix();var rotationMatrix=matrix.rotateAxisAngle(axis.x,axis.y,axis.z,angle);this._currentMatrix=rotationMatrix.multiply(this._boxMatrix)
this._boxElement.style.webkitTransform=this._currentMatrix;var eulerAngles=WebInspector.Geometry.EulerAngles.fromRotationMatrix(this._currentMatrix);var newOrientation=new WebInspector.OverridesSupport.DeviceOrientation(eulerAngles.alpha,eulerAngles.beta,eulerAngles.gamma);this._setDeviceOrientation(newOrientation,WebInspector.OverridesView.SensorsTab.DeviceOrientationModificationSource.UserDrag);return false;},_onBoxDragStart:function(event)
{if(!WebInspector.settings.overrideDeviceOrientation.get())
return false;this._mouseDownVector=this._calculateRadiusVector(event.x,event.y);if(!this._mouseDownVector)
return false;event.consume(true);return true;},_onBoxDragEnd:function()
{this._boxMatrix=this._currentMatrix;},_calculateRadiusVector:function(x,y)
{var rect=this._stageElement.getBoundingClientRect();var radius=Math.max(rect.width,rect.height)/2;var sphereX=(x-rect.left-rect.width/2)/radius;var sphereY=(y-rect.top-rect.height/2)/radius;var sqrSum=sphereX*sphereX+sphereY*sphereY;if(sqrSum>0.5)
return new WebInspector.Geometry.Vector(sphereX,sphereY,0.5/Math.sqrt(sqrSum));return new WebInspector.Geometry.Vector(sphereX,sphereY,Math.sqrt(1-sqrSum));},__proto__:WebInspector.OverridesView.Tab.prototype}
WebInspector.OverridesView.SensorsTab.DeviceOrientationModificationSource={UserInput:"userInput",UserDrag:"userDrag",ResetButton:"resetButton"};WebInspector.PlatformFontsSidebarPane=function()
{WebInspector.SidebarPane.call(this,WebInspector.UIString("Fonts"));this.element.classList.add("platform-fonts");WebInspector.domAgent.addEventListener(WebInspector.DOMAgent.Events.AttrModified,this._onNodeChange.bind(this));WebInspector.domAgent.addEventListener(WebInspector.DOMAgent.Events.AttrRemoved,this._onNodeChange.bind(this));WebInspector.domAgent.addEventListener(WebInspector.DOMAgent.Events.CharacterDataModified,this._onNodeChange.bind(this));this._sectionTitle=document.createElementWithClass("div","sidebar-separator");this.element.insertBefore(this._sectionTitle,this.bodyElement);this._sectionTitle.textContent=WebInspector.UIString("Rendered Fonts");this._fontStatsSection=this.bodyElement.createChild("div","stats-section");}
WebInspector.PlatformFontsSidebarPane.prototype={_onNodeChange:function()
{if(this._innerUpdateTimeout)
return;this._innerUpdateTimeout=setTimeout(this._innerUpdate.bind(this),100);},update:function(node)
{if(!node){delete this._node;return;}
this._node=node;this._innerUpdate();},_innerUpdate:function()
{if(this._innerUpdateTimeout){clearTimeout(this._innerUpdateTimeout);delete this._innerUpdateTimeout;}
if(!this._node)
return;WebInspector.cssModel.getPlatformFontsForNode(this._node.id,this._refreshUI.bind(this,this._node));},_refreshUI:function(node,cssFamilyName,platformFonts)
{if(this._node!==node)
return;this._fontStatsSection.removeChildren();var isEmptySection=!platformFonts||!platformFonts.length;this._sectionTitle.enableStyleClass("hidden",isEmptySection);if(isEmptySection)
return;platformFonts.sort(function(a,b){return b.glyphCount-a.glyphCount;});for(var i=0;i<platformFonts.length;++i){var fontStatElement=this._fontStatsSection.createChild("div","font-stats-item");var fontNameElement=fontStatElement.createChild("span","font-name");fontNameElement.textContent=platformFonts[i].familyName;var fontDelimeterElement=fontStatElement.createChild("span","delimeter");fontDelimeterElement.textContent="\u2014";var fontUsageElement=fontStatElement.createChild("span","font-usage");var usage=platformFonts[i].glyphCount;fontUsageElement.textContent=usage===1?WebInspector.UIString("%d glyph",usage):WebInspector.UIString("%d glyphs",usage);}},__proto__:WebInspector.SidebarPane.prototype};WebInspector.PropertiesSidebarPane=function()
{WebInspector.SidebarPane.call(this,WebInspector.UIString("Properties"));}
WebInspector.PropertiesSidebarPane._objectGroupName="properties-sidebar-pane";WebInspector.PropertiesSidebarPane.prototype={update:function(node)
{var body=this.bodyElement;if(!node){body.removeChildren();this.sections=[];return;}
WebInspector.RemoteObject.resolveNode(node,WebInspector.PropertiesSidebarPane._objectGroupName,nodeResolved.bind(this));function nodeResolved(object)
{if(!object)
return;function protoList()
{var proto=this;var result={};var counter=1;while(proto){result[counter++]=proto;proto=proto.__proto__;}
return result;}
object.callFunction(protoList,undefined,nodePrototypesReady.bind(this));object.release();}
function nodePrototypesReady(object,wasThrown)
{if(!object||wasThrown)
return;object.getOwnProperties(fillSection.bind(this));}
function fillSection(prototypes)
{if(!prototypes)
return;var body=this.bodyElement;body.removeChildren();this.sections=[];for(var i=0;i<prototypes.length;++i){if(!parseInt(prototypes[i].name,10))
continue;var prototype=prototypes[i].value;var title=prototype.description;if(title.match(/Prototype$/))
title=title.replace(/Prototype$/,"");var section=new WebInspector.ObjectPropertiesSection(prototype,title);this.sections.push(section);body.appendChild(section.element);}}},__proto__:WebInspector.SidebarPane.prototype};WebInspector.RenderingOptionsView=function()
{WebInspector.View.call(this);this.registerRequiredCSS("helpScreen.css");this.element.classList.add("help-indent-labels");var div=this.element.createChild("div","settings-tab help-content help-container");div.appendChild(WebInspector.SettingsTab.createSettingCheckbox(WebInspector.UIString("Show paint rectangles"),WebInspector.settings.showPaintRects));div.appendChild(WebInspector.SettingsTab.createSettingCheckbox(WebInspector.UIString("Show composited layer borders"),WebInspector.settings.showDebugBorders));div.appendChild(WebInspector.SettingsTab.createSettingCheckbox(WebInspector.UIString("Show FPS meter"),WebInspector.settings.showFPSCounter));div.appendChild(WebInspector.SettingsTab.createSettingCheckbox(WebInspector.UIString("Enable continuous page repainting"),WebInspector.settings.continuousPainting));var child=WebInspector.SettingsTab.createSettingCheckbox(WebInspector.UIString("Show potential scroll bottlenecks"),WebInspector.settings.showScrollBottleneckRects);child.title=WebInspector.UIString("Shows areas of the page that slow down scrolling:\nTouch and mousewheel event listeners can delay scrolling.\nSome areas need to repaint their content when scrolled.");div.appendChild(child);}
WebInspector.RenderingOptionsView.prototype={__proto__:WebInspector.View.prototype};WebInspector.StylesSidebarPane=function(computedStylePane,setPseudoClassCallback)
{WebInspector.SidebarPane.call(this,WebInspector.UIString("Styles"));this.settingsSelectElement=document.createElement("select");this.settingsSelectElement.className="select-settings";var option=document.createElement("option");option.value=WebInspector.Color.Format.Original;option.label=WebInspector.UIString(WebInspector.useLowerCaseMenuTitles()?"As authored":"As Authored");this.settingsSelectElement.appendChild(option);option=document.createElement("option");option.value=WebInspector.Color.Format.HEX;option.label=WebInspector.UIString("Hex Colors");this.settingsSelectElement.appendChild(option);option=document.createElement("option");option.value=WebInspector.Color.Format.RGB;option.label=WebInspector.UIString("RGB Colors");this.settingsSelectElement.appendChild(option);option=document.createElement("option");option.value=WebInspector.Color.Format.HSL;option.label=WebInspector.UIString("HSL Colors");this.settingsSelectElement.appendChild(option);var muteEventListener=function(event){event.consume(true);};this.settingsSelectElement.addEventListener("click",muteEventListener,true);this.settingsSelectElement.addEventListener("change",this._changeSetting.bind(this),false);this._updateColorFormatFilter();this.titleElement.appendChild(this.settingsSelectElement);this._elementStateButton=document.createElement("button");this._elementStateButton.className="pane-title-button element-state";this._elementStateButton.title=WebInspector.UIString("Toggle Element State");this._elementStateButton.addEventListener("click",this._toggleElementStatePane.bind(this),false);this.titleElement.appendChild(this._elementStateButton);var addButton=document.createElement("button");addButton.className="pane-title-button add";addButton.id="add-style-button-test-id";addButton.title=WebInspector.UIString("New Style Rule");addButton.addEventListener("click",this._createNewRule.bind(this),false);this.titleElement.appendChild(addButton);this._computedStylePane=computedStylePane;computedStylePane._stylesSidebarPane=this;this._setPseudoClassCallback=setPseudoClassCallback;this.element.addEventListener("contextmenu",this._contextMenuEventFired.bind(this),true);WebInspector.settings.colorFormat.addChangeListener(this._colorFormatSettingChanged.bind(this));this._createElementStatePane();this.bodyElement.appendChild(this._elementStatePane);this._sectionsContainer=document.createElement("div");this.bodyElement.appendChild(this._sectionsContainer);this._spectrumHelper=new WebInspector.SpectrumPopupHelper();this._linkifier=new WebInspector.Linkifier(new WebInspector.Linkifier.DefaultCSSFormatter());WebInspector.cssModel.addEventListener(WebInspector.CSSStyleModel.Events.StyleSheetAdded,this._styleSheetOrMediaQueryResultChanged,this);WebInspector.cssModel.addEventListener(WebInspector.CSSStyleModel.Events.StyleSheetRemoved,this._styleSheetOrMediaQueryResultChanged,this);WebInspector.cssModel.addEventListener(WebInspector.CSSStyleModel.Events.StyleSheetChanged,this._styleSheetOrMediaQueryResultChanged,this);WebInspector.cssModel.addEventListener(WebInspector.CSSStyleModel.Events.MediaQueryResultChanged,this._styleSheetOrMediaQueryResultChanged,this);WebInspector.domAgent.addEventListener(WebInspector.DOMAgent.Events.AttrModified,this._attributeChanged,this);WebInspector.domAgent.addEventListener(WebInspector.DOMAgent.Events.AttrRemoved,this._attributeChanged,this);WebInspector.domAgent.addEventListener(WebInspector.DOMAgent.Events.PseudoStateChanged,this._pseudoStateChanged,this);WebInspector.settings.showUserAgentStyles.addChangeListener(this._showUserAgentStylesSettingChanged.bind(this));WebInspector.resourceTreeModel.addEventListener(WebInspector.ResourceTreeModel.EventTypes.FrameResized,this._frameResized,this);this.element.classList.add("styles-pane");this.element.enableStyleClass("show-user-styles",WebInspector.settings.showUserAgentStyles.get());this.element.addEventListener("mousemove",this._mouseMovedOverElement.bind(this),false);document.body.addEventListener("keydown",this._keyDown.bind(this),false);document.body.addEventListener("keyup",this._keyUp.bind(this),false);}
WebInspector.StylesSidebarPane.PseudoIdNames=["","first-line","first-letter","before","after","selection","","-webkit-scrollbar","-webkit-file-upload-button","-webkit-input-placeholder","-webkit-slider-thumb","-webkit-search-cancel-button","-webkit-search-decoration","-webkit-search-results-decoration","-webkit-search-results-button","-webkit-media-controls-panel","-webkit-media-controls-play-button","-webkit-media-controls-mute-button","-webkit-media-controls-timeline","-webkit-media-controls-timeline-container","-webkit-media-controls-volume-slider","-webkit-media-controls-volume-slider-container","-webkit-media-controls-current-time-display","-webkit-media-controls-time-remaining-display","-webkit-media-controls-seek-back-button","-webkit-media-controls-seek-forward-button","-webkit-media-controls-fullscreen-button","-webkit-media-controls-rewind-button","-webkit-media-controls-return-to-realtime-button","-webkit-media-controls-toggle-closed-captions-button","-webkit-media-controls-status-display","-webkit-scrollbar-thumb","-webkit-scrollbar-button","-webkit-scrollbar-track","-webkit-scrollbar-track-piece","-webkit-scrollbar-corner","-webkit-resizer","-webkit-inner-spin-button","-webkit-outer-spin-button"];WebInspector.StylesSidebarPane._colorRegex=/((?:rgb|hsl)a?\([^)]+\)|#[0-9a-fA-F]{6}|#[0-9a-fA-F]{3}|\b\w+\b(?!-))/g;WebInspector.StylesSidebarPane.createExclamationMark=function(property)
{var exclamationElement=document.createElement("div");exclamationElement.className="exclamation-mark"+(WebInspector.StylesSidebarPane._ignoreErrorsForProperty(property)?"":" warning-icon-small");exclamationElement.title=WebInspector.CSSMetadata.cssPropertiesMetainfo.keySet()[property.name.toLowerCase()]?WebInspector.UIString("Invalid property value."):WebInspector.UIString("Unknown property name.");return exclamationElement;}
WebInspector.StylesSidebarPane._colorFormat=function(color)
{const cf=WebInspector.Color.Format;var format;var formatSetting=WebInspector.settings.colorFormat.get();if(formatSetting===cf.Original)
format=cf.Original;else if(formatSetting===cf.RGB)
format=(color.hasAlpha()?cf.RGBA:cf.RGB);else if(formatSetting===cf.HSL)
format=(color.hasAlpha()?cf.HSLA:cf.HSL);else if(!color.hasAlpha())
format=(color.canBeShortHex()?cf.ShortHEX:cf.HEX);else
format=cf.RGBA;return format;}
WebInspector.StylesSidebarPane._ignoreErrorsForProperty=function(property){function hasUnknownVendorPrefix(string)
{return!string.startsWith("-webkit-")&&/^[-_][\w\d]+-\w/.test(string);}
var name=property.name.toLowerCase();if(name.charAt(0)==="_")
return true;if(name==="filter")
return true;if(name.startsWith("scrollbar-"))
return true;if(hasUnknownVendorPrefix(name))
return true;var value=property.value.toLowerCase();if(value.endsWith("\9"))
return true;if(hasUnknownVendorPrefix(value))
return true;return false;}
WebInspector.StylesSidebarPane.prototype={_contextMenuEventFired:function(event)
{var contextMenu=new WebInspector.ContextMenu(event);contextMenu.appendApplicableItems((event.target));contextMenu.show();},get _forcedPseudoClasses()
{return this.node?(this.node.getUserProperty("pseudoState")||undefined):undefined;},_updateForcedPseudoStateInputs:function()
{if(!this.node)
return;var hasPseudoType=!!this.node.pseudoType();this._elementStateButton.enableStyleClass("hidden",hasPseudoType);this._elementStatePane.enableStyleClass("expanded",!hasPseudoType&&this._elementStateButton.classList.contains("toggled"));var nodePseudoState=this._forcedPseudoClasses;if(!nodePseudoState)
nodePseudoState=[];var inputs=this._elementStatePane.inputs;for(var i=0;i<inputs.length;++i)
inputs[i].checked=nodePseudoState.indexOf(inputs[i].state)>=0;},update:function(node,forceUpdate)
{this._spectrumHelper.hide();this._discardElementUnderMouse();var refresh=false;if(forceUpdate)
delete this.node;if(!forceUpdate&&(node===this.node))
refresh=true;if(node&&node.nodeType()===Node.TEXT_NODE&&node.parentNode)
node=node.parentNode;if(node&&node.nodeType()!==Node.ELEMENT_NODE)
node=null;if(node)
this.node=node;else
node=this.node;this._updateForcedPseudoStateInputs();if(refresh)
this._refreshUpdate();else
this._rebuildUpdate();},_refreshUpdate:function(editedSection,forceFetchComputedStyle,userCallback)
{if(this._refreshUpdateInProgress){this._lastNodeForInnerRefresh=this.node;return;}
var node=this._validateNode(userCallback);if(!node)
return;function computedStyleCallback(computedStyle)
{delete this._refreshUpdateInProgress;if(this._lastNodeForInnerRefresh){delete this._lastNodeForInnerRefresh;this._refreshUpdate(editedSection,forceFetchComputedStyle,userCallback);return;}
if(this.node===node&&computedStyle)
this._innerRefreshUpdate(node,computedStyle,editedSection);if(userCallback)
userCallback();}
if(this._computedStylePane.isShowing()||forceFetchComputedStyle){this._refreshUpdateInProgress=true;WebInspector.cssModel.getComputedStyleAsync(node.id,computedStyleCallback.bind(this));}else{this._innerRefreshUpdate(node,null,editedSection);if(userCallback)
userCallback();}},_rebuildUpdate:function()
{if(this._rebuildUpdateInProgress){this._lastNodeForInnerRebuild=this.node;return;}
var node=this._validateNode();if(!node)
return;this._rebuildUpdateInProgress=true;var resultStyles={};function stylesCallback(matchedResult)
{delete this._rebuildUpdateInProgress;var lastNodeForRebuild=this._lastNodeForInnerRebuild;if(lastNodeForRebuild){delete this._lastNodeForInnerRebuild;if(lastNodeForRebuild!==this.node){this._rebuildUpdate();return;}}
if(matchedResult&&this.node===node){resultStyles.matchedCSSRules=matchedResult.matchedCSSRules;resultStyles.pseudoElements=matchedResult.pseudoElements;resultStyles.inherited=matchedResult.inherited;this._innerRebuildUpdate(node,resultStyles);}
if(lastNodeForRebuild){this._rebuildUpdate();return;}}
function inlineCallback(inlineStyle,attributesStyle)
{resultStyles.inlineStyle=inlineStyle;resultStyles.attributesStyle=attributesStyle;}
function computedCallback(computedStyle)
{resultStyles.computedStyle=computedStyle;}
if(this._computedStylePane.isShowing())
WebInspector.cssModel.getComputedStyleAsync(node.id,computedCallback.bind(this));WebInspector.cssModel.getInlineStylesAsync(node.id,inlineCallback.bind(this));WebInspector.cssModel.getMatchedStylesAsync(node.id,true,true,stylesCallback.bind(this));},_validateNode:function(userCallback)
{if(!this.node){this._sectionsContainer.removeChildren();this._computedStylePane.bodyElement.removeChildren();this.sections={};if(userCallback)
userCallback();return null;}
return this.node;},_styleSheetOrMediaQueryResultChanged:function()
{if(this._userOperation||this._isEditingStyle)
return;this._rebuildUpdate();},_frameResized:function()
{function refreshContents()
{this._rebuildUpdate();delete this._activeTimer;}
if(this._activeTimer)
clearTimeout(this._activeTimer);this._activeTimer=setTimeout(refreshContents.bind(this),100);},_attributeChanged:function(event)
{if(this._isEditingStyle||this._userOperation)
return;if(!this._canAffectCurrentStyles(event.data.node))
return;this._rebuildUpdate();},_pseudoStateChanged:function(event)
{if(this._isEditingStyle||this._userOperation)
return;if(!this._canAffectCurrentStyles(event.data))
return;this._rebuildUpdate();},_canAffectCurrentStyles:function(node)
{return this.node&&(this.node===node||node.parentNode===this.node.parentNode||node.isAncestor(this.node));},_innerRefreshUpdate:function(node,computedStyle,editedSection)
{for(var pseudoId in this.sections){var styleRules=this._refreshStyleRules(this.sections[pseudoId],computedStyle);var usedProperties={};this._markUsedProperties(styleRules,usedProperties);this._refreshSectionsForStyleRules(styleRules,usedProperties,editedSection);}
if(computedStyle)
this.sections[0][0].rebuildComputedTrace(this.sections[0]);this._nodeStylesUpdatedForTest(node,false);},_innerRebuildUpdate:function(node,styles)
{this._sectionsContainer.removeChildren();this._computedStylePane.bodyElement.removeChildren();this._linkifier.reset();var styleRules=this._rebuildStyleRules(node,styles);var usedProperties={};this._markUsedProperties(styleRules,usedProperties);this.sections[0]=this._rebuildSectionsForStyleRules(styleRules,usedProperties,null);var anchorElement=this.sections[0].inheritedPropertiesSeparatorElement;if(styles.computedStyle)
this.sections[0][0].rebuildComputedTrace(this.sections[0]);for(var i=0;i<styles.pseudoElements.length;++i){var pseudoElementCSSRules=styles.pseudoElements[i];styleRules=[];var pseudoId=pseudoElementCSSRules.pseudoId;var entry={isStyleSeparator:true,pseudoId:pseudoId};styleRules.push(entry);for(var j=pseudoElementCSSRules.rules.length-1;j>=0;--j){var rule=pseudoElementCSSRules.rules[j];styleRules.push({style:rule.style,selectorText:rule.selectorText,media:rule.media,sourceURL:rule.resourceURL(),rule:rule,editable:!!(rule.style&&rule.style.id)});}
usedProperties={};this._markUsedProperties(styleRules,usedProperties);this.sections[pseudoId]=this._rebuildSectionsForStyleRules(styleRules,usedProperties,anchorElement);}
this._nodeStylesUpdatedForTest(node,true);},_nodeStylesUpdatedForTest:function(node,rebuild)
{},_refreshStyleRules:function(sections,computedStyle)
{var nodeComputedStyle=computedStyle;var styleRules=[];for(var i=0;sections&&i<sections.length;++i){var section=sections[i];if(section.isBlank)
continue;if(section.computedStyle)
section.styleRule.style=nodeComputedStyle;var styleRule={section:section,style:section.styleRule.style,computedStyle:section.computedStyle,rule:section.rule,editable:!!(section.styleRule.style&&section.styleRule.style.id),isAttribute:section.styleRule.isAttribute,isInherited:section.styleRule.isInherited,parentNode:section.styleRule.parentNode};styleRules.push(styleRule);}
return styleRules;},_rebuildStyleRules:function(node,styles)
{var nodeComputedStyle=styles.computedStyle;this.sections={};var styleRules=[];function addAttributesStyle()
{if(!styles.attributesStyle)
return;var attrStyle={style:styles.attributesStyle,editable:false};attrStyle.selectorText=node.nodeNameInCorrectCase()+"["+WebInspector.UIString("Attributes Style")+"]";styleRules.push(attrStyle);}
styleRules.push({computedStyle:true,selectorText:"",style:nodeComputedStyle,editable:false});if(!!node.pseudoType())
styleRules.push({isStyleSeparator:true,isPlaceholder:true});if(styles.inlineStyle&&node.nodeType()===Node.ELEMENT_NODE){var inlineStyle={selectorText:"element.style",style:styles.inlineStyle,isAttribute:true};styleRules.push(inlineStyle);}
var addedAttributesStyle;for(var i=styles.matchedCSSRules.length-1;i>=0;--i){var rule=styles.matchedCSSRules[i];if((rule.isUser||rule.isUserAgent)&&!addedAttributesStyle){addedAttributesStyle=true;addAttributesStyle();}
styleRules.push({style:rule.style,selectorText:rule.selectorText,media:rule.media,sourceURL:rule.resourceURL(),rule:rule,editable:!!(rule.style&&rule.style.id)});}
if(!addedAttributesStyle)
addAttributesStyle();var parentNode=node.parentNode;function insertInheritedNodeSeparator(node)
{var entry={};entry.isStyleSeparator=true;entry.node=node;styleRules.push(entry);}
for(var parentOrdinal=0;parentOrdinal<styles.inherited.length;++parentOrdinal){var parentStyles=styles.inherited[parentOrdinal];var separatorInserted=false;if(parentStyles.inlineStyle){if(this._containsInherited(parentStyles.inlineStyle)){var inlineStyle={selectorText:WebInspector.UIString("Style Attribute"),style:parentStyles.inlineStyle,isAttribute:true,isInherited:true,parentNode:parentNode};if(!separatorInserted){insertInheritedNodeSeparator(parentNode);separatorInserted=true;}
styleRules.push(inlineStyle);}}
for(var i=parentStyles.matchedCSSRules.length-1;i>=0;--i){var rulePayload=parentStyles.matchedCSSRules[i];if(!this._containsInherited(rulePayload.style))
continue;var rule=rulePayload;if(!separatorInserted){insertInheritedNodeSeparator(parentNode);separatorInserted=true;}
styleRules.push({style:rule.style,selectorText:rule.selectorText,media:rule.media,sourceURL:rule.resourceURL(),rule:rule,isInherited:true,parentNode:parentNode,editable:!!(rule.style&&rule.style.id)});}
parentNode=parentNode.parentNode;}
return styleRules;},_markUsedProperties:function(styleRules,usedProperties)
{var foundImportantProperties={};var propertyToEffectiveRule={};var inheritedPropertyToNode={};for(var i=0;i<styleRules.length;++i){var styleRule=styleRules[i];if(styleRule.computedStyle||styleRule.isStyleSeparator)
continue;if(styleRule.section&&styleRule.section.noAffect)
continue;styleRule.usedProperties={};var style=styleRule.style;var allProperties=style.allProperties;for(var j=0;j<allProperties.length;++j){var property=allProperties[j];if(!property.isLive||!property.parsedOk)
continue;if(styleRule.isInherited&&!WebInspector.CSSMetadata.isPropertyInherited(property.name))
continue;var canonicalName=WebInspector.CSSMetadata.canonicalPropertyName(property.name);if(foundImportantProperties.hasOwnProperty(canonicalName))
continue;var isImportant=property.priority.length;if(!isImportant&&usedProperties.hasOwnProperty(canonicalName))
continue;var isKnownProperty=propertyToEffectiveRule.hasOwnProperty(canonicalName);if(!isKnownProperty&&styleRule.isInherited&&!inheritedPropertyToNode[canonicalName])
inheritedPropertyToNode[canonicalName]=styleRule.parentNode;if(isImportant){if(styleRule.isInherited&&isKnownProperty&&styleRule.parentNode!==inheritedPropertyToNode[canonicalName])
continue;foundImportantProperties[canonicalName]=true;if(isKnownProperty)
delete propertyToEffectiveRule[canonicalName].usedProperties[canonicalName];}
styleRule.usedProperties[canonicalName]=true;usedProperties[canonicalName]=true;propertyToEffectiveRule[canonicalName]=styleRule;}}},_refreshSectionsForStyleRules:function(styleRules,usedProperties,editedSection)
{for(var i=0;i<styleRules.length;++i){var styleRule=styleRules[i];var section=styleRule.section;if(styleRule.computedStyle){section._usedProperties=usedProperties;section.update();}else{section._usedProperties=styleRule.usedProperties;section.update(section===editedSection);}}},_rebuildSectionsForStyleRules:function(styleRules,usedProperties,anchorElement)
{var sections=[];for(var i=0;i<styleRules.length;++i){var styleRule=styleRules[i];if(styleRule.isStyleSeparator){var separatorElement=document.createElement("div");if(styleRule.isPlaceholder){separatorElement.className="styles-sidebar-placeholder";this._sectionsContainer.insertBefore(separatorElement,anchorElement);continue;}
separatorElement.className="sidebar-separator";if(styleRule.node){var link=WebInspector.DOMPresentationUtils.linkifyNodeReference(styleRule.node);separatorElement.appendChild(document.createTextNode(WebInspector.UIString("Inherited from")+" "));separatorElement.appendChild(link);if(!sections.inheritedPropertiesSeparatorElement)
sections.inheritedPropertiesSeparatorElement=separatorElement;}else if("pseudoId"in styleRule){var pseudoName=WebInspector.StylesSidebarPane.PseudoIdNames[styleRule.pseudoId];if(pseudoName)
separatorElement.textContent=WebInspector.UIString("Pseudo ::%s element",pseudoName);else
separatorElement.textContent=WebInspector.UIString("Pseudo element");}else
separatorElement.textContent=styleRule.text;this._sectionsContainer.insertBefore(separatorElement,anchorElement);continue;}
var computedStyle=styleRule.computedStyle;var editable=styleRule.editable;if(typeof editable==="undefined")
editable=true;if(computedStyle)
var section=new WebInspector.ComputedStylePropertiesSection(this,styleRule,usedProperties);else{var section=new WebInspector.StylePropertiesSection(this,styleRule,editable,styleRule.isInherited);section._markSelectorMatches();}
section.expanded=true;if(computedStyle)
this._computedStylePane.bodyElement.appendChild(section.element);else
this._sectionsContainer.insertBefore(section.element,anchorElement);sections.push(section);}
return sections;},_containsInherited:function(style)
{var properties=style.allProperties;for(var i=0;i<properties.length;++i){var property=properties[i];if(property.isLive&&WebInspector.CSSMetadata.isPropertyInherited(property.name))
return true;}
return false;},_colorFormatSettingChanged:function(event)
{this._updateColorFormatFilter();for(var pseudoId in this.sections){var sections=this.sections[pseudoId];for(var i=0;i<sections.length;++i)
sections[i].update(true);}},_updateColorFormatFilter:function()
{var selectedIndex=0;var value=WebInspector.settings.colorFormat.get();var options=this.settingsSelectElement.options;for(var i=0;i<options.length;++i){if(options[i].value===value){selectedIndex=i;break;}}
this.settingsSelectElement.selectedIndex=selectedIndex;},_changeSetting:function(event)
{var options=this.settingsSelectElement.options;var selectedOption=options[this.settingsSelectElement.selectedIndex];WebInspector.settings.colorFormat.set(selectedOption.value);},_createNewRule:function(event)
{event.consume();this.expand();this.addBlankSection().startEditingSelector();},addBlankSection:function()
{var blankSection=new WebInspector.BlankStylePropertiesSection(this,this.node?WebInspector.DOMPresentationUtils.appropriateSelectorFor(this.node,true):"");var elementStyleSection=this.sections[0][1];this._sectionsContainer.insertBefore(blankSection.element,elementStyleSection.element.nextSibling);this.sections[0].splice(2,0,blankSection);return blankSection;},removeSection:function(section)
{for(var pseudoId in this.sections){var sections=this.sections[pseudoId];var index=sections.indexOf(section);if(index===-1)
continue;sections.splice(index,1);section.element.remove();}},_toggleElementStatePane:function(event)
{event.consume();var buttonToggled=!this._elementStateButton.classList.contains("toggled");if(buttonToggled)
this.expand();this._elementStateButton.enableStyleClass("toggled",buttonToggled);this._elementStatePane.enableStyleClass("expanded",buttonToggled);},_createElementStatePane:function()
{this._elementStatePane=document.createElement("div");this._elementStatePane.className="styles-element-state-pane source-code";var table=document.createElement("table");var inputs=[];this._elementStatePane.inputs=inputs;function clickListener(event)
{var node=this._validateNode();if(!node)
return;this._setPseudoClassCallback(node.id,event.target.state,event.target.checked);}
function createCheckbox(state)
{var td=document.createElement("td");var label=document.createElement("label");var input=document.createElement("input");input.type="checkbox";input.state=state;input.addEventListener("click",clickListener.bind(this),false);inputs.push(input);label.appendChild(input);label.appendChild(document.createTextNode(":"+state));td.appendChild(label);return td;}
var tr=document.createElement("tr");tr.appendChild(createCheckbox.call(this,"active"));tr.appendChild(createCheckbox.call(this,"hover"));table.appendChild(tr);tr=document.createElement("tr");tr.appendChild(createCheckbox.call(this,"focus"));tr.appendChild(createCheckbox.call(this,"visited"));table.appendChild(tr);this._elementStatePane.appendChild(table);},_showUserAgentStylesSettingChanged:function(event)
{var showStyles=(event.data);this.element.enableStyleClass("show-user-styles",showStyles);},willHide:function()
{this._spectrumHelper.hide();this._discardElementUnderMouse();},_discardElementUnderMouse:function()
{if(this._elementUnderMouse)
this._elementUnderMouse.classList.remove("styles-panel-hovered");delete this._elementUnderMouse;},_mouseMovedOverElement:function(e)
{if(this._elementUnderMouse&&e.target!==this._elementUnderMouse)
this._discardElementUnderMouse();this._elementUnderMouse=e.target;if(WebInspector.KeyboardShortcut.eventHasCtrlOrMeta(e))
this._elementUnderMouse.classList.add("styles-panel-hovered");},_keyDown:function(e)
{if((!WebInspector.isMac()&&e.keyCode===WebInspector.KeyboardShortcut.Keys.Ctrl.code)||(WebInspector.isMac()&&e.keyCode===WebInspector.KeyboardShortcut.Keys.Meta.code)){if(this._elementUnderMouse)
this._elementUnderMouse.classList.add("styles-panel-hovered");}},_keyUp:function(e)
{if((!WebInspector.isMac()&&e.keyCode===WebInspector.KeyboardShortcut.Keys.Ctrl.code)||(WebInspector.isMac()&&e.keyCode===WebInspector.KeyboardShortcut.Keys.Meta.code)){this._discardElementUnderMouse();}},__proto__:WebInspector.SidebarPane.prototype}
WebInspector.ComputedStyleSidebarPane=function()
{WebInspector.SidebarPane.call(this,WebInspector.UIString("Computed Style"));var showInheritedCheckbox=new WebInspector.Checkbox(WebInspector.UIString("Show inherited"),"sidebar-pane-subtitle");this.titleElement.appendChild(showInheritedCheckbox.element);this._hasFreshContent=false;if(WebInspector.settings.showInheritedComputedStyleProperties.get()){this.bodyElement.classList.add("show-inherited");showInheritedCheckbox.checked=true;}
function showInheritedToggleFunction()
{WebInspector.settings.showInheritedComputedStyleProperties.set(showInheritedCheckbox.checked);if(WebInspector.settings.showInheritedComputedStyleProperties.get())
this.bodyElement.classList.add("show-inherited");else
this.bodyElement.classList.remove("show-inherited");}
showInheritedCheckbox.addEventListener(showInheritedToggleFunction.bind(this));}
WebInspector.ComputedStyleSidebarPane.prototype={wasShown:function()
{WebInspector.SidebarPane.prototype.wasShown.call(this);if(!this._hasFreshContent)
this.prepareContent();},prepareContent:function(callback)
{function wrappedCallback(){this._hasFreshContent=true;if(callback)
callback();delete this._hasFreshContent;}
this._stylesSidebarPane._refreshUpdate(null,true,wrappedCallback.bind(this));},__proto__:WebInspector.SidebarPane.prototype}
WebInspector.StylePropertiesSection=function(parentPane,styleRule,editable,isInherited)
{WebInspector.PropertiesSection.call(this,"");this._parentPane=parentPane;this.styleRule=styleRule;this.rule=this.styleRule.rule;this.editable=editable;this.isInherited=isInherited;var extraClasses=(this.rule&&(this.rule.isUser||this.rule.isUserAgent)?" user-rule":"");this.element.className="styles-section matched-styles monospace"+extraClasses;this.propertiesElement.classList.remove("properties-tree");if(styleRule.media){for(var i=styleRule.media.length-1;i>=0;--i){var media=styleRule.media[i];var mediaDataElement=this.titleElement.createChild("div","media");var mediaText;switch(media.source){case WebInspector.CSSMedia.Source.LINKED_SHEET:case WebInspector.CSSMedia.Source.INLINE_SHEET:mediaText="media=\""+media.text+"\"";break;case WebInspector.CSSMedia.Source.MEDIA_RULE:mediaText="@media "+media.text;break;case WebInspector.CSSMedia.Source.IMPORT_RULE:mediaText="@import "+media.text;break;}
if(media.sourceURL){var refElement=mediaDataElement.createChild("div","subtitle");var rawLocation;var mediaHeader;if(media.range){mediaHeader=media.header();if(mediaHeader){var lineNumber=media.lineNumberInSource();var columnNumber=media.columnNumberInSource();console.assert(typeof lineNumber!=="undefined"&&typeof columnNumber!=="undefined");rawLocation=new WebInspector.CSSLocation(media.sourceURL,lineNumber,columnNumber);}}
var anchor;if(rawLocation)
anchor=this._parentPane._linkifier.linkifyCSSLocation(mediaHeader.id,rawLocation);else{anchor=WebInspector.linkifyResourceAsNode(media.sourceURL,undefined,"subtitle",media.sourceURL);}
anchor.preferredPanel="sources";anchor.style.float="right";refElement.appendChild(anchor);}
var mediaTextElement=mediaDataElement.createChild("span");mediaTextElement.textContent=mediaText;mediaTextElement.title=media.text;}}
var selectorContainer=document.createElement("div");this._selectorElement=document.createElement("span");this._selectorElement.textContent=styleRule.selectorText;selectorContainer.appendChild(this._selectorElement);var openBrace=document.createElement("span");openBrace.textContent=" {";selectorContainer.appendChild(openBrace);selectorContainer.addEventListener("mousedown",this._handleEmptySpaceMouseDown.bind(this),false);selectorContainer.addEventListener("click",this._handleSelectorContainerClick.bind(this),false);var closeBrace=document.createElement("div");closeBrace.textContent="}";this.element.appendChild(closeBrace);this._selectorElement.addEventListener("click",this._handleSelectorClick.bind(this),false);this.element.addEventListener("mousedown",this._handleEmptySpaceMouseDown.bind(this),false);this.element.addEventListener("click",this._handleEmptySpaceClick.bind(this),false);if(this.rule){if(this.rule.isUserAgent||this.rule.isUser)
this.editable=false;else{if(this.rule.id)
this.navigable=!!this.rule.resourceURL();}
this.titleElement.classList.add("styles-selector");}
this._usedProperties=styleRule.usedProperties;this._selectorRefElement=document.createElement("div");this._selectorRefElement.className="subtitle";this._updateRuleOrigin();selectorContainer.insertBefore(this._selectorRefElement,selectorContainer.firstChild);this.titleElement.appendChild(selectorContainer);this._selectorContainer=selectorContainer;if(isInherited)
this.element.classList.add("show-inherited");if(this.navigable)
this.element.classList.add("navigable");if(!this.editable)
this.element.classList.add("read-only");}
WebInspector.StylePropertiesSection.prototype={get pane()
{return this._parentPane;},collapse:function()
{},isPropertyInherited:function(propertyName)
{if(this.isInherited){return!WebInspector.CSSMetadata.isPropertyInherited(propertyName);}
return false;},isPropertyOverloaded:function(propertyName,isShorthand)
{if(!this._usedProperties||this.noAffect)
return false;if(this.isInherited&&!WebInspector.CSSMetadata.isPropertyInherited(propertyName)){return false;}
var canonicalName=WebInspector.CSSMetadata.canonicalPropertyName(propertyName);var used=(canonicalName in this._usedProperties);if(used||!isShorthand)
return!used;var longhandProperties=this.styleRule.style.longhandProperties(propertyName);for(var j=0;j<longhandProperties.length;++j){var individualProperty=longhandProperties[j];if(WebInspector.CSSMetadata.canonicalPropertyName(individualProperty.name)in this._usedProperties)
return false;}
return true;},nextEditableSibling:function()
{var curSection=this;do{curSection=curSection.nextSibling;}while(curSection&&!curSection.editable);if(!curSection){curSection=this.firstSibling;while(curSection&&!curSection.editable)
curSection=curSection.nextSibling;}
return(curSection&&curSection.editable)?curSection:null;},previousEditableSibling:function()
{var curSection=this;do{curSection=curSection.previousSibling;}while(curSection&&!curSection.editable);if(!curSection){curSection=this.lastSibling;while(curSection&&!curSection.editable)
curSection=curSection.previousSibling;}
return(curSection&&curSection.editable)?curSection:null;},update:function(full)
{if(this.styleRule.selectorText)
this._selectorElement.textContent=this.styleRule.selectorText;this._markSelectorMatches();if(full){this.propertiesTreeOutline.removeChildren();this.populated=false;}else{var child=this.propertiesTreeOutline.children[0];while(child){child.overloaded=this.isPropertyOverloaded(child.name,child.isShorthand);child=child.traverseNextTreeElement(false,null,true);}}
this.afterUpdate();},afterUpdate:function()
{if(this._afterUpdate){this._afterUpdate(this);delete this._afterUpdate;}},onpopulate:function()
{var style=this.styleRule.style;var allProperties=style.allProperties;this.uniqueProperties=[];var styleHasEditableSource=this.editable&&!!style.range;if(styleHasEditableSource){for(var i=0;i<allProperties.length;++i){var property=allProperties[i];this.uniqueProperties.push(property);if(property.styleBased)
continue;var isShorthand=!!WebInspector.CSSMetadata.cssPropertiesMetainfo.longhands(property.name);var inherited=this.isPropertyInherited(property.name);var overloaded=property.inactive||this.isPropertyOverloaded(property.name);var item=new WebInspector.StylePropertyTreeElement(this._parentPane,this.styleRule,style,property,isShorthand,inherited,overloaded);this.propertiesTreeOutline.appendChild(item);}
return;}
var generatedShorthands={};for(var i=0;i<allProperties.length;++i){var property=allProperties[i];this.uniqueProperties.push(property);var isShorthand=!!WebInspector.CSSMetadata.cssPropertiesMetainfo.longhands(property.name);var shorthands=isShorthand?null:WebInspector.CSSMetadata.cssPropertiesMetainfo.shorthands(property.name);var shorthandPropertyAvailable=false;for(var j=0;shorthands&&!shorthandPropertyAvailable&&j<shorthands.length;++j){var shorthand=shorthands[j];if(shorthand in generatedShorthands){shorthandPropertyAvailable=true;continue;}
if(style.getLiveProperty(shorthand)){shorthandPropertyAvailable=true;continue;}
if(!style.shorthandValue(shorthand)){shorthandPropertyAvailable=false;continue;}
var shorthandProperty=new WebInspector.CSSProperty(style,style.allProperties.length,shorthand,style.shorthandValue(shorthand),"","style",true,true);var overloaded=property.inactive||this.isPropertyOverloaded(property.name,true);var item=new WebInspector.StylePropertyTreeElement(this._parentPane,this.styleRule,style,shorthandProperty,true,false,overloaded);this.propertiesTreeOutline.appendChild(item);generatedShorthands[shorthand]=shorthandProperty;shorthandPropertyAvailable=true;}
if(shorthandPropertyAvailable)
continue;var inherited=this.isPropertyInherited(property.name);var overloaded=property.inactive||this.isPropertyOverloaded(property.name,isShorthand);var item=new WebInspector.StylePropertyTreeElement(this._parentPane,this.styleRule,style,property,isShorthand,inherited,overloaded);this.propertiesTreeOutline.appendChild(item);}},_markSelectorMatches:function()
{var rule=this.styleRule.rule;if(!rule)
return;var matchingSelectors=rule.matchingSelectors;if(this.noAffect||matchingSelectors)
this._selectorElement.className="selector";if(!matchingSelectors)
return;var selectors=rule.selectors;var fragment=document.createDocumentFragment();var currentMatch=0;for(var i=0;i<selectors.length;++i){if(i)
fragment.appendChild(document.createTextNode(", "));var isSelectorMatching=matchingSelectors[currentMatch]===i;if(isSelectorMatching)
++currentMatch;var rawLocation=new WebInspector.CSSLocation(rule.sourceURL,rule.lineNumberInSource(i),rule.columnNumberInSource(i));var matchingSelectorClass=isSelectorMatching?" selector-matches":"";var selectorElement=document.createElement("span");selectorElement.className="simple-selector"+matchingSelectorClass;if(rule.id)
selectorElement._selectorIndex=i;selectorElement.textContent=selectors[i].value;fragment.appendChild(selectorElement);}
this._selectorElement.removeChildren();this._selectorElement.appendChild(fragment);},_checkWillCancelEditing:function()
{var willCauseCancelEditing=this._willCauseCancelEditing;delete this._willCauseCancelEditing;return willCauseCancelEditing;},_handleSelectorContainerClick:function(event)
{if(this._checkWillCancelEditing()||!this.editable)
return;if(event.target===this._selectorContainer)
this.addNewBlankProperty(0).startEditing();},addNewBlankProperty:function(index)
{var style=this.styleRule.style;var property=style.newBlankProperty(index);var item=new WebInspector.StylePropertyTreeElement(this._parentPane,this.styleRule,style,property,false,false,false);index=property.index;this.propertiesTreeOutline.insertChild(item,index);item.listItemElement.textContent="";item._newProperty=true;item.updateTitle();return item;},_createRuleOriginNode:function()
{function linkifyUncopyable(url,line)
{var link=WebInspector.linkifyResourceAsNode(url,line,"",url+":"+(line+1));link.preferredPanel="sources";link.classList.add("webkit-html-resource-link");link.setAttribute("data-uncopyable",link.textContent);link.textContent="";return link;}
if(this.styleRule.sourceURL){var firstMatchingIndex=this.styleRule.rule.matchingSelectors&&this.rule.matchingSelectors.length?this.rule.matchingSelectors[0]:0;var matchingSelectorLocation=new WebInspector.CSSLocation(this.styleRule.sourceURL,this.rule.lineNumberInSource(firstMatchingIndex),this.rule.columnNumberInSource(firstMatchingIndex));return this._parentPane._linkifier.linkifyCSSLocation(this.rule.id.styleSheetId,matchingSelectorLocation)||linkifyUncopyable(this.styleRule.sourceURL,this.rule.lineNumberInSource());}
if(!this.rule)
return document.createTextNode("");if(this.rule.isUserAgent)
return document.createTextNode(WebInspector.UIString("user agent stylesheet"));if(this.rule.isUser)
return document.createTextNode(WebInspector.UIString("user stylesheet"));if(this.rule.isViaInspector)
return document.createTextNode(WebInspector.UIString("via inspector"));return document.createTextNode("");},_handleEmptySpaceMouseDown:function()
{this._willCauseCancelEditing=this._parentPane._isEditingStyle;},_handleEmptySpaceClick:function(event)
{if(!this.editable)
return;if(!window.getSelection().isCollapsed)
return;if(this._checkWillCancelEditing())
return;if(event.target.classList.contains("header")||this.element.classList.contains("read-only")||event.target.enclosingNodeOrSelfWithClass("media")){event.consume();return;}
this.expand();this.addNewBlankProperty().startEditing();},_handleSelectorClick:function(event)
{if(WebInspector.KeyboardShortcut.eventHasCtrlOrMeta(event)&&this.navigable&&event.target.classList.contains("simple-selector")){var index=event.target._selectorIndex;var styleSheetHeader=WebInspector.cssModel.styleSheetHeaderForId(this.rule.id.styleSheetId);var uiLocation=styleSheetHeader.rawLocationToUILocation(this.rule.lineNumberInSource(index),this.rule.columnNumberInSource(index));if(uiLocation)
WebInspector.panel("sources").showUILocation(uiLocation);return;}
this._startEditingOnMouseEvent();event.consume(true);},_startEditingOnMouseEvent:function()
{if(!this.editable)
return;if(!this.rule&&this.propertiesTreeOutline.children.length===0){this.expand();this.addNewBlankProperty().startEditing();return;}
if(!this.rule)
return;this.startEditingSelector();},startEditingSelector:function()
{var element=this._selectorElement;if(WebInspector.isBeingEdited(element))
return;element.scrollIntoViewIfNeeded(false);element.textContent=element.textContent;var config=new WebInspector.EditingConfig(this.editingSelectorCommitted.bind(this),this.editingSelectorCancelled.bind(this));WebInspector.startEditing(this._selectorElement,config);window.getSelection().setBaseAndExtent(element,0,element,1);this._parentPane._isEditingStyle=true;},_moveEditorFromSelector:function(moveDirection)
{this._markSelectorMatches();if(!moveDirection)
return;if(moveDirection==="forward"){this.expand();var firstChild=this.propertiesTreeOutline.children[0];while(firstChild&&firstChild.inherited)
firstChild=firstChild.nextSibling;if(!firstChild)
this.addNewBlankProperty().startEditing();else
firstChild.startEditing(firstChild.nameElement);}else{var previousSection=this.previousEditableSibling();if(!previousSection)
return;previousSection.expand();previousSection.addNewBlankProperty().startEditing();}},editingSelectorCommitted:function(element,newContent,oldContent,context,moveDirection)
{this._editingSelectorEnded();if(newContent)
newContent=newContent.trim();if(newContent===oldContent){this._selectorElement.textContent=newContent;return this._moveEditorFromSelector(moveDirection);}
var selectedNode=this._parentPane.node;function successCallback(newRule)
{var doesAffectSelectedNode=newRule.matchingSelectors.length>0;if(!doesAffectSelectedNode){this.noAffect=true;this.element.classList.add("no-affect");}else{delete this.noAffect;this.element.classList.remove("no-affect");}
this.rule=newRule;this.styleRule={section:this,style:newRule.style,selectorText:newRule.selectorText,media:newRule.media,sourceURL:newRule.resourceURL(),rule:newRule};this._parentPane.update(selectedNode);this._updateRuleOrigin();finishOperationAndMoveEditor.call(this,moveDirection);}
function finishOperationAndMoveEditor(direction)
{delete this._parentPane._userOperation;this._moveEditorFromSelector(direction);}
this._parentPane._userOperation=true;WebInspector.cssModel.setRuleSelector(this.rule.id,selectedNode?selectedNode.id:0,newContent,successCallback.bind(this),finishOperationAndMoveEditor.bind(this,moveDirection));},_updateRuleOrigin:function()
{this._selectorRefElement.removeChildren();this._selectorRefElement.appendChild(this._createRuleOriginNode());},_editingSelectorEnded:function()
{delete this._parentPane._isEditingStyle;},editingSelectorCancelled:function()
{this._editingSelectorEnded();this._markSelectorMatches();},__proto__:WebInspector.PropertiesSection.prototype}
WebInspector.ComputedStylePropertiesSection=function(stylesPane,styleRule,usedProperties)
{WebInspector.PropertiesSection.call(this,"");this.headerElement.classList.add("hidden");this.element.className="styles-section monospace read-only computed-style";this._stylesPane=stylesPane;this.styleRule=styleRule;this._usedProperties=usedProperties;this._alwaysShowComputedProperties={"display":true,"height":true,"width":true};this.computedStyle=true;this._propertyTreeElements={};this._expandedPropertyNames={};}
WebInspector.ComputedStylePropertiesSection.prototype={collapse:function(dontRememberState)
{},_isPropertyInherited:function(propertyName)
{var canonicalName=WebInspector.CSSMetadata.canonicalPropertyName(propertyName);return!(canonicalName in this._usedProperties)&&!(canonicalName in this._alwaysShowComputedProperties);},update:function()
{this._expandedPropertyNames={};for(var name in this._propertyTreeElements){if(this._propertyTreeElements[name].expanded)
this._expandedPropertyNames[name]=true;}
this._propertyTreeElements={};this.propertiesTreeOutline.removeChildren();this.populated=false;},onpopulate:function()
{function sorter(a,b)
{return a.name.compareTo(b.name);}
var style=this.styleRule.style;if(!style)
return;var uniqueProperties=[];var allProperties=style.allProperties;for(var i=0;i<allProperties.length;++i)
uniqueProperties.push(allProperties[i]);uniqueProperties.sort(sorter);this._propertyTreeElements={};for(var i=0;i<uniqueProperties.length;++i){var property=uniqueProperties[i];var inherited=this._isPropertyInherited(property.name);var item=new WebInspector.ComputedStylePropertyTreeElement(this._stylesPane,this.styleRule,style,property,inherited);this.propertiesTreeOutline.appendChild(item);this._propertyTreeElements[property.name]=item;}},rebuildComputedTrace:function(sections)
{for(var i=0;i<sections.length;++i){var section=sections[i];if(section.computedStyle||section.isBlank)
continue;for(var j=0;j<section.uniqueProperties.length;++j){var property=section.uniqueProperties[j];if(property.disabled)
continue;if(section.isInherited&&!WebInspector.CSSMetadata.isPropertyInherited(property.name))
continue;var treeElement=this._propertyTreeElements[property.name.toLowerCase()];if(treeElement){var fragment=document.createDocumentFragment();var selector=fragment.createChild("span");selector.style.color="gray";selector.textContent=section.styleRule.selectorText;fragment.appendChild(document.createTextNode(" - "+property.value+" "));var subtitle=fragment.createChild("span");subtitle.style.float="right";subtitle.appendChild(section._createRuleOriginNode());var childElement=new TreeElement(fragment,null,false);treeElement.appendChild(childElement);if(property.inactive||section.isPropertyOverloaded(property.name))
childElement.listItemElement.classList.add("overloaded");if(!property.parsedOk){childElement.listItemElement.classList.add("not-parsed-ok");childElement.listItemElement.insertBefore(WebInspector.StylesSidebarPane.createExclamationMark(property),childElement.listItemElement.firstChild);if(WebInspector.StylesSidebarPane._ignoreErrorsForProperty(property))
childElement.listItemElement.classList.add("has-ignorable-error");}}}}
for(var name in this._expandedPropertyNames){if(name in this._propertyTreeElements)
this._propertyTreeElements[name].expand();}},__proto__:WebInspector.PropertiesSection.prototype}
WebInspector.BlankStylePropertiesSection=function(stylesPane,defaultSelectorText)
{WebInspector.StylePropertiesSection.call(this,stylesPane,{selectorText:defaultSelectorText,rule:{isViaInspector:true}},true,false);this.element.classList.add("blank-section");}
WebInspector.BlankStylePropertiesSection.prototype={get isBlank()
{return!this._normal;},expand:function()
{if(!this.isBlank)
WebInspector.StylePropertiesSection.prototype.expand.call(this);},editingSelectorCommitted:function(element,newContent,oldContent,context,moveDirection)
{if(!this.isBlank){WebInspector.StylePropertiesSection.prototype.editingSelectorCommitted.call(this,element,newContent,oldContent,context,moveDirection);return;}
function successCallback(newRule)
{var doesSelectorAffectSelectedNode=newRule.matchingSelectors.length>0;var styleRule={section:this,style:newRule.style,selectorText:newRule.selectorText,sourceURL:newRule.resourceURL(),rule:newRule};this.makeNormal(styleRule);if(!doesSelectorAffectSelectedNode){this.noAffect=true;this.element.classList.add("no-affect");}
this._updateRuleOrigin();this.expand();if(this.element.parentElement)
this._moveEditorFromSelector(moveDirection);delete this._parentPane._userOperation;this._editingSelectorEnded();this._markSelectorMatches();}
if(newContent)
newContent=newContent.trim();this._parentPane._userOperation=true;WebInspector.cssModel.addRule(this.pane.node.id,newContent,successCallback.bind(this),this.editingSelectorCancelled.bind(this));},editingSelectorCancelled:function()
{delete this._parentPane._userOperation;if(!this.isBlank){WebInspector.StylePropertiesSection.prototype.editingSelectorCancelled.call(this);return;}
this._editingSelectorEnded();this.pane.removeSection(this);},makeNormal:function(styleRule)
{this.element.classList.remove("blank-section");this.styleRule=styleRule;this.rule=styleRule.rule;this._normal=true;},__proto__:WebInspector.StylePropertiesSection.prototype}
WebInspector.StylePropertyTreeElementBase=function(styleRule,style,property,inherited,overloaded,hasChildren)
{this._styleRule=styleRule;this.style=style;this.property=property;this._inherited=inherited;this._overloaded=overloaded;TreeElement.call(this,"",null,hasChildren);this.selectable=false;}
WebInspector.StylePropertyTreeElementBase.prototype={node:function()
{return null;},editablePane:function()
{return null;},get inherited()
{return this._inherited;},hasIgnorableError:function()
{return!this.parsedOk&&WebInspector.StylesSidebarPane._ignoreErrorsForProperty(this.property);},set inherited(x)
{if(x===this._inherited)
return;this._inherited=x;this.updateState();},get overloaded()
{return this._overloaded;},set overloaded(x)
{if(x===this._overloaded)
return;this._overloaded=x;this.updateState();},get disabled()
{return this.property.disabled;},get name()
{if(!this.disabled||!this.property.text)
return this.property.name;var text=this.property.text;var index=text.indexOf(":");if(index<1)
return this.property.name;text=text.substring(0,index).trim();if(text.startsWith("/*"))
text=text.substring(2).trim();return text;},get priority()
{if(this.disabled)
return"";return this.property.priority;},get value()
{if(!this.disabled||!this.property.text)
return this.property.value;var match=this.property.text.match(/(.*);\s*/);if(!match||!match[1])
return this.property.value;var text=match[1];var index=text.indexOf(":");if(index<1)
return this.property.value;return text.substring(index+1).trim();},get parsedOk()
{return this.property.parsedOk;},onattach:function()
{this.updateTitle();},updateTitle:function()
{var value=this.value;this.updateState();var nameElement=document.createElement("span");nameElement.className="webkit-css-property";nameElement.textContent=this.name;nameElement.title=this.property.propertyText;this.nameElement=nameElement;this._expandElement=document.createElement("span");this._expandElement.className="expand-element";var valueElement=document.createElement("span");valueElement.className="value";this.valueElement=valueElement;function processValue(regex,processor,nextProcessor,valueText)
{var container=document.createDocumentFragment();var items=valueText.replace(regex,"\0$1\0").split("\0");for(var i=0;i<items.length;++i){if((i%2)===0){if(nextProcessor)
container.appendChild(nextProcessor(items[i]));else
container.appendChild(document.createTextNode(items[i]));}else{var processedNode=processor(items[i]);if(processedNode)
container.appendChild(processedNode);}}
return container;}
function linkifyURL(url)
{var hrefUrl=url;var match=hrefUrl.match(/['"]?([^'"]+)/);if(match)
hrefUrl=match[1];var container=document.createDocumentFragment();container.appendChild(document.createTextNode("url("));if(this._styleRule.sourceURL)
hrefUrl=WebInspector.ParsedURL.completeURL(this._styleRule.sourceURL,hrefUrl);else if(this.node())
hrefUrl=this.node().resolveURL(hrefUrl);var hasResource=hrefUrl&&!!WebInspector.resourceForURL(hrefUrl);container.appendChild(WebInspector.linkifyURLAsNode(hrefUrl||url,url,undefined,!hasResource));container.appendChild(document.createTextNode(")"));return container;}
if(value){var colorProcessor=processValue.bind(this,WebInspector.StylesSidebarPane._colorRegex,this._processColor.bind(this,nameElement,valueElement),null);valueElement.appendChild(processValue(/url\(\s*([^)]+)\s*\)/g,linkifyURL.bind(this),WebInspector.CSSMetadata.isColorAwareProperty(this.name)&&this.parsedOk?colorProcessor:null,value));}
this.listItemElement.removeChildren();nameElement.normalize();valueElement.normalize();if(!this.treeOutline)
return;if(this.disabled)
this.listItemElement.createChild("span","styles-clipboard-only").createTextChild("/* ");this.listItemElement.appendChild(nameElement);this.listItemElement.appendChild(document.createTextNode(": "));this.listItemElement.appendChild(this._expandElement);this.listItemElement.appendChild(valueElement);this.listItemElement.appendChild(document.createTextNode(";"));if(this.disabled)
this.listItemElement.createChild("span","styles-clipboard-only").createTextChild(" */");if(!this.parsedOk){this.hasChildren=false;this.listItemElement.classList.add("not-parsed-ok");this.listItemElement.insertBefore(WebInspector.StylesSidebarPane.createExclamationMark(this.property),this.listItemElement.firstChild);}
if(this.property.inactive)
this.listItemElement.classList.add("inactive");},_processColor:function(nameElement,valueElement,text)
{var color=WebInspector.Color.parse(text);if(!color)
return document.createTextNode(text);var format=WebInspector.StylesSidebarPane._colorFormat(color);var spectrumHelper=this.editablePane()&&this.editablePane()._spectrumHelper;var spectrum=spectrumHelper?spectrumHelper.spectrum():null;var colorSwatch=new WebInspector.ColorSwatch();colorSwatch.setColorString(text);colorSwatch.element.addEventListener("click",swatchClick.bind(this),false);var scrollerElement;var boundSpectrumChanged=spectrumChanged.bind(this);var boundSpectrumHidden=spectrumHidden.bind(this);function spectrumChanged(e)
{var colorString=(e.data);spectrum.displayText=colorString;colorValueElement.textContent=colorString;colorSwatch.setColorString(colorString);this.applyStyleText(nameElement.textContent+": "+valueElement.textContent,false,false,false);}
function spectrumHidden(event)
{if(scrollerElement)
scrollerElement.removeEventListener("scroll",repositionSpectrum,false);var commitEdit=event.data;var propertyText=!commitEdit&&this.originalPropertyText?this.originalPropertyText:(nameElement.textContent+": "+valueElement.textContent);this.applyStyleText(propertyText,true,true,false);spectrum.removeEventListener(WebInspector.Spectrum.Events.ColorChanged,boundSpectrumChanged);spectrumHelper.removeEventListener(WebInspector.SpectrumPopupHelper.Events.Hidden,boundSpectrumHidden);delete this.editablePane()._isEditingStyle;delete this.originalPropertyText;}
function repositionSpectrum()
{spectrumHelper.reposition(colorSwatch.element);}
function swatchClick(e)
{if(!spectrumHelper||e.shiftKey){changeColorDisplay();}else{var visible=spectrumHelper.toggle(colorSwatch.element,color,format);if(visible){spectrum.displayText=color.toString(format);this.originalPropertyText=this.property.propertyText;this.editablePane()._isEditingStyle=true;spectrum.addEventListener(WebInspector.Spectrum.Events.ColorChanged,boundSpectrumChanged);spectrumHelper.addEventListener(WebInspector.SpectrumPopupHelper.Events.Hidden,boundSpectrumHidden);scrollerElement=colorSwatch.element.enclosingNodeOrSelfWithClass("scroll-target");if(scrollerElement)
scrollerElement.addEventListener("scroll",repositionSpectrum,false);else
console.error("Unable to handle color picker scrolling");}}
e.consume(true);}
var colorValueElement=document.createElement("span");colorValueElement.textContent=color.toString(format);function nextFormat(curFormat)
{var cf=WebInspector.Color.Format;switch(curFormat){case cf.Original:return!color.hasAlpha()?cf.RGB:cf.RGBA;case cf.RGB:case cf.RGBA:return!color.hasAlpha()?cf.HSL:cf.HSLA;case cf.HSL:case cf.HSLA:if(color.nickname())
return cf.Nickname;if(!color.hasAlpha())
return color.canBeShortHex()?cf.ShortHEX:cf.HEX;else
return cf.Original;case cf.ShortHEX:return cf.HEX;case cf.HEX:return cf.Original;case cf.Nickname:if(!color.hasAlpha())
return color.canBeShortHex()?cf.ShortHEX:cf.HEX;else
return cf.Original;default:return cf.RGBA;}}
function changeColorDisplay()
{do{format=nextFormat(format);var currentValue=color.toString(format);}while(currentValue===colorValueElement.textContent);colorValueElement.textContent=currentValue;}
var container=document.createElement("nobr");container.appendChild(colorSwatch.element);container.appendChild(colorValueElement);return container;},updateState:function()
{if(!this.listItemElement)
return;if(this.style.isPropertyImplicit(this.name))
this.listItemElement.classList.add("implicit");else
this.listItemElement.classList.remove("implicit");if(this.hasIgnorableError())
this.listItemElement.classList.add("has-ignorable-error");else
this.listItemElement.classList.remove("has-ignorable-error");if(this.inherited)
this.listItemElement.classList.add("inherited");else
this.listItemElement.classList.remove("inherited");if(this.overloaded)
this.listItemElement.classList.add("overloaded");else
this.listItemElement.classList.remove("overloaded");if(this.disabled)
this.listItemElement.classList.add("disabled");else
this.listItemElement.classList.remove("disabled");},__proto__:TreeElement.prototype}
WebInspector.ComputedStylePropertyTreeElement=function(stylesPane,styleRule,style,property,inherited)
{WebInspector.StylePropertyTreeElementBase.call(this,styleRule,style,property,inherited,false,false);this._stylesPane=stylesPane;}
WebInspector.ComputedStylePropertyTreeElement.prototype={node:function()
{return this._stylesPane.node;},editablePane:function()
{return null;},__proto__:WebInspector.StylePropertyTreeElementBase.prototype}
WebInspector.StylePropertyTreeElement=function(stylesPane,styleRule,style,property,isShorthand,inherited,overloaded)
{WebInspector.StylePropertyTreeElementBase.call(this,styleRule,style,property,inherited,overloaded,isShorthand);this._parentPane=stylesPane;this.isShorthand=isShorthand;}
WebInspector.StylePropertyTreeElement.prototype={node:function()
{return this._parentPane.node;},editablePane:function()
{return this._parentPane;},section:function()
{return this.treeOutline&&this.treeOutline.section;},_updatePane:function(userCallback)
{var section=this.section();if(section&&section.pane)
section.pane._refreshUpdate(section,false,userCallback);else{if(userCallback)
userCallback();}},toggleEnabled:function(event)
{var disabled=!event.target.checked;function callback(newStyle)
{if(!newStyle)
return;newStyle.parentRule=this.style.parentRule;this.style=newStyle;this._styleRule.style=newStyle;var section=this.section();if(section&&section.pane)
section.pane.dispatchEventToListeners("style property toggled");this._updatePane();delete this._parentPane._userOperation;}
this._parentPane._userOperation=true;this.property.setDisabled(disabled,callback.bind(this));event.consume();},onpopulate:function()
{if(this.children.length||!this.isShorthand)
return;var longhandProperties=this.style.longhandProperties(this.name);for(var i=0;i<longhandProperties.length;++i){var name=longhandProperties[i].name;var section=this.section();if(section){var inherited=section.isPropertyInherited(name);var overloaded=section.isPropertyOverloaded(name);}
var liveProperty=this.style.getLiveProperty(name);if(!liveProperty)
continue;var item=new WebInspector.StylePropertyTreeElement(this._parentPane,this._styleRule,this.style,liveProperty,false,inherited,overloaded);this.appendChild(item);}},onattach:function()
{WebInspector.StylePropertyTreeElementBase.prototype.onattach.call(this);this.listItemElement.addEventListener("mousedown",this._mouseDown.bind(this));this.listItemElement.addEventListener("mouseup",this._resetMouseDownElement.bind(this));this.listItemElement.addEventListener("click",this._mouseClick.bind(this));},_mouseDown:function(event)
{if(this._parentPane){this._parentPane._mouseDownTreeElement=this;this._parentPane._mouseDownTreeElementIsName=this._isNameElement(event.target);this._parentPane._mouseDownTreeElementIsValue=this._isValueElement(event.target);}},_resetMouseDownElement:function()
{if(this._parentPane){delete this._parentPane._mouseDownTreeElement;delete this._parentPane._mouseDownTreeElementIsName;delete this._parentPane._mouseDownTreeElementIsValue;}},updateTitle:function()
{WebInspector.StylePropertyTreeElementBase.prototype.updateTitle.call(this);if(this.parsedOk&&this.section()&&this.parent.root){var enabledCheckboxElement=document.createElement("input");enabledCheckboxElement.className="enabled-button";enabledCheckboxElement.type="checkbox";enabledCheckboxElement.checked=!this.disabled;enabledCheckboxElement.addEventListener("click",this.toggleEnabled.bind(this),false);this.listItemElement.insertBefore(enabledCheckboxElement,this.listItemElement.firstChild);}},_mouseClick:function(event)
{if(!window.getSelection().isCollapsed)
return;event.consume(true);if(event.target===this.listItemElement){var section=this.section();if(!section||!section.editable)
return;if(section._checkWillCancelEditing())
return;section.addNewBlankProperty(this.property.index+1).startEditing();return;}
if(WebInspector.KeyboardShortcut.eventHasCtrlOrMeta(event)&&this.section().navigable){this._navigateToSource(event.target);return;}
this.startEditing(event.target);},_navigateToSource:function(element)
{console.assert(this.section().navigable);var propertyNameClicked=element===this.nameElement;var uiLocation=this.property.uiLocation(propertyNameClicked);if(!uiLocation)
return;WebInspector.panel("sources").showUILocation(uiLocation);},_isNameElement:function(element)
{return element.enclosingNodeOrSelfWithClass("webkit-css-property")===this.nameElement;},_isValueElement:function(element)
{return!!element.enclosingNodeOrSelfWithClass("value");},startEditing:function(selectElement)
{if(this.parent.isShorthand)
return;if(selectElement===this._expandElement)
return;var section=this.section();if(section&&!section.editable)
return;if(!selectElement)
selectElement=this.nameElement;else
selectElement=selectElement.enclosingNodeOrSelfWithClass("webkit-css-property")||selectElement.enclosingNodeOrSelfWithClass("value");if(WebInspector.isBeingEdited(selectElement))
return;var isEditingName=selectElement===this.nameElement;if(!isEditingName)
this.valueElement.textContent=restoreURLs(this.valueElement.textContent,this.value);function restoreURLs(fieldValue,modelValue)
{const urlRegex=/\b(url\([^)]*\))/g;var splitFieldValue=fieldValue.split(urlRegex);if(splitFieldValue.length===1)
return fieldValue;var modelUrlRegex=new RegExp(urlRegex);for(var i=1;i<splitFieldValue.length;i+=2){var match=modelUrlRegex.exec(modelValue);if(match)
splitFieldValue[i]=match[0];}
return splitFieldValue.join("");}
var context={expanded:this.expanded,hasChildren:this.hasChildren,isEditingName:isEditingName,previousContent:selectElement.textContent};this.hasChildren=false;if(selectElement.parentElement)
selectElement.parentElement.classList.add("child-editing");selectElement.textContent=selectElement.textContent;function pasteHandler(context,event)
{var data=event.clipboardData.getData("Text");if(!data)
return;var colonIdx=data.indexOf(":");if(colonIdx<0)
return;var name=data.substring(0,colonIdx).trim();var value=data.substring(colonIdx+1).trim();event.preventDefault();if(!("originalName"in context)){context.originalName=this.nameElement.textContent;context.originalValue=this.valueElement.textContent;}
this.property.name=name;this.property.value=value;this.nameElement.textContent=name;this.valueElement.textContent=value;this.nameElement.normalize();this.valueElement.normalize();this.editingCommitted(event.target.textContent,context,"forward");}
function blurListener(context,event)
{var treeElement=this._parentPane._mouseDownTreeElement;var moveDirection="";if(treeElement===this){if(isEditingName&&this._parentPane._mouseDownTreeElementIsValue)
moveDirection="forward";if(!isEditingName&&this._parentPane._mouseDownTreeElementIsName)
moveDirection="backward";}
this.editingCommitted(event.target.textContent,context,moveDirection);}
delete this.originalPropertyText;this._parentPane._isEditingStyle=true;if(selectElement.parentElement)
selectElement.parentElement.scrollIntoViewIfNeeded(false);var applyItemCallback=!isEditingName?this._applyFreeFlowStyleTextEdit.bind(this,true):undefined;this._prompt=new WebInspector.StylesSidebarPane.CSSPropertyPrompt(isEditingName?WebInspector.CSSMetadata.cssPropertiesMetainfo:WebInspector.CSSMetadata.keywordsForProperty(this.nameElement.textContent),this,isEditingName);if(applyItemCallback){this._prompt.addEventListener(WebInspector.TextPrompt.Events.ItemApplied,applyItemCallback,this);this._prompt.addEventListener(WebInspector.TextPrompt.Events.ItemAccepted,applyItemCallback,this);}
var proxyElement=this._prompt.attachAndStartEditing(selectElement,blurListener.bind(this,context));proxyElement.addEventListener("keydown",this.editingNameValueKeyDown.bind(this,context),false);if(isEditingName)
proxyElement.addEventListener("paste",pasteHandler.bind(this,context));window.getSelection().setBaseAndExtent(selectElement,0,selectElement,1);},editingNameValueKeyDown:function(context,event)
{if(event.handled)
return;var isEditingName=context.isEditingName;var result;function shouldCommitValueSemicolon(text,cursorPosition)
{var openQuote="";for(var i=0;i<cursorPosition;++i){var ch=text[i];if(ch==="\\"&&openQuote!=="")
++i;else if(!openQuote&&(ch==="\""||ch==="'"))
openQuote=ch;else if(openQuote===ch)
openQuote="";}
return!openQuote;}
var isFieldInputTerminated=(event.keyCode===WebInspector.KeyboardShortcut.Keys.Semicolon.code)&&(isEditingName?event.shiftKey:(!event.shiftKey&&shouldCommitValueSemicolon(event.target.textContent,event.target.selectionLeftOffset())));if(isEnterKey(event)||isFieldInputTerminated){event.preventDefault();result="forward";}else if(event.keyCode===WebInspector.KeyboardShortcut.Keys.Esc.code||event.keyIdentifier==="U+001B")
result="cancel";else if(!isEditingName&&this._newProperty&&event.keyCode===WebInspector.KeyboardShortcut.Keys.Backspace.code){var selection=window.getSelection();if(selection.isCollapsed&&!selection.focusOffset){event.preventDefault();result="backward";}}else if(event.keyIdentifier==="U+0009"){result=event.shiftKey?"backward":"forward";event.preventDefault();}
if(result){switch(result){case"cancel":this.editingCancelled(null,context);break;case"forward":case"backward":this.editingCommitted(event.target.textContent,context,result);break;}
event.consume();return;}
if(!isEditingName)
this._applyFreeFlowStyleTextEdit(false);},_applyFreeFlowStyleTextEdit:function(now)
{if(this._applyFreeFlowStyleTextEditTimer)
clearTimeout(this._applyFreeFlowStyleTextEditTimer);function apply()
{var valueText=this.valueElement.textContent;if(valueText.indexOf(";")===-1)
this.applyStyleText(this.nameElement.textContent+": "+valueText,false,false,false);}
if(now)
apply.call(this);else
this._applyFreeFlowStyleTextEditTimer=setTimeout(apply.bind(this),100);},kickFreeFlowStyleEditForTest:function()
{this._applyFreeFlowStyleTextEdit(true);},editingEnded:function(context)
{this._resetMouseDownElement();if(this._applyFreeFlowStyleTextEditTimer)
clearTimeout(this._applyFreeFlowStyleTextEditTimer);this.hasChildren=context.hasChildren;if(context.expanded)
this.expand();var editedElement=context.isEditingName?this.nameElement:this.valueElement;if(editedElement.parentElement)
editedElement.parentElement.classList.remove("child-editing");delete this._parentPane._isEditingStyle;},editingCancelled:function(element,context)
{this._removePrompt();this._revertStyleUponEditingCanceled(this.originalPropertyText);this.editingEnded(context);},_revertStyleUponEditingCanceled:function(originalPropertyText)
{if(typeof originalPropertyText==="string"){delete this.originalPropertyText;this.applyStyleText(originalPropertyText,true,false,true);}else{if(this._newProperty)
this.treeOutline.removeChild(this);else
this.updateTitle();}},_findSibling:function(moveDirection)
{var target=this;do{target=(moveDirection==="forward"?target.nextSibling:target.previousSibling);}while(target&&target.inherited);return target;},editingCommitted:function(userInput,context,moveDirection)
{this._removePrompt();this.editingEnded(context);var isEditingName=context.isEditingName;var createNewProperty,moveToPropertyName,moveToSelector;var isDataPasted="originalName"in context;var isDirtyViaPaste=isDataPasted&&(this.nameElement.textContent!==context.originalName||this.valueElement.textContent!==context.originalValue);var isPropertySplitPaste=isDataPasted&&isEditingName&&this.valueElement.textContent!==context.originalValue;var moveTo=this;var moveToOther=(isEditingName^(moveDirection==="forward"));var abandonNewProperty=this._newProperty&&!userInput&&(moveToOther||isEditingName);if(moveDirection==="forward"&&(!isEditingName||isPropertySplitPaste)||moveDirection==="backward"&&isEditingName){moveTo=moveTo._findSibling(moveDirection);if(moveTo)
moveToPropertyName=moveTo.name;else if(moveDirection==="forward"&&(!this._newProperty||userInput))
createNewProperty=true;else if(moveDirection==="backward")
moveToSelector=true;}
var moveToIndex=moveTo&&this.treeOutline?this.treeOutline.children.indexOf(moveTo):-1;var blankInput=/^\s*$/.test(userInput);var shouldCommitNewProperty=this._newProperty&&(isPropertySplitPaste||moveToOther||(!moveDirection&&!isEditingName)||(isEditingName&&blankInput));var section=this.section();if(((userInput!==context.previousContent||isDirtyViaPaste)&&!this._newProperty)||shouldCommitNewProperty){section._afterUpdate=moveToNextCallback.bind(this,this._newProperty,!blankInput,section);var propertyText;if(blankInput||(this._newProperty&&/^\s*$/.test(this.valueElement.textContent)))
propertyText="";else{if(isEditingName)
propertyText=userInput+": "+this.property.value;else
propertyText=this.property.name+": "+userInput;}
this.applyStyleText(propertyText,true,true,false);}else{if(isEditingName)
this.property.name=userInput;else
this.property.value=userInput;if(!isDataPasted&&!this._newProperty)
this.updateTitle();moveToNextCallback.call(this,this._newProperty,false,section);}
function moveToNextCallback(alreadyNew,valueChanged,section)
{if(!moveDirection)
return;if(moveTo&&moveTo.parent){moveTo.startEditing(!isEditingName?moveTo.nameElement:moveTo.valueElement);return;}
if(moveTo&&!moveTo.parent){var propertyElements=section.propertiesTreeOutline.children;if(moveDirection==="forward"&&blankInput&&!isEditingName)
--moveToIndex;if(moveToIndex>=propertyElements.length&&!this._newProperty)
createNewProperty=true;else{var treeElement=moveToIndex>=0?propertyElements[moveToIndex]:null;if(treeElement){var elementToEdit=!isEditingName||isPropertySplitPaste?treeElement.nameElement:treeElement.valueElement;if(alreadyNew&&blankInput)
elementToEdit=moveDirection==="forward"?treeElement.nameElement:treeElement.valueElement;treeElement.startEditing(elementToEdit);return;}else if(!alreadyNew)
moveToSelector=true;}}
if(createNewProperty){if(alreadyNew&&!valueChanged&&(isEditingName^(moveDirection==="backward")))
return;section.addNewBlankProperty().startEditing();return;}
if(abandonNewProperty){moveTo=this._findSibling(moveDirection);var sectionToEdit=(moveTo||moveDirection==="backward")?section:section.nextEditableSibling();if(sectionToEdit){if(sectionToEdit.rule)
sectionToEdit.startEditingSelector();else
sectionToEdit._moveEditorFromSelector(moveDirection);}
return;}
if(moveToSelector){if(section.rule)
section.startEditingSelector();else
section._moveEditorFromSelector(moveDirection);}}},_removePrompt:function()
{if(this._prompt){this._prompt.detach();delete this._prompt;}},_hasBeenModifiedIncrementally:function()
{return typeof this.originalPropertyText==="string"||(!!this.property.propertyText&&this._newProperty);},applyStyleText:function(styleText,updateInterface,majorChange,isRevert)
{function userOperationFinishedCallback(parentPane,updateInterface)
{if(updateInterface)
delete parentPane._userOperation;}
if(!isRevert&&!updateInterface&&!this._hasBeenModifiedIncrementally()){this.originalPropertyText=this.property.propertyText;}
if(!this.treeOutline)
return;var section=this.section();styleText=styleText.replace(/\s/g," ").trim();var styleTextLength=styleText.length;if(!styleTextLength&&updateInterface&&!isRevert&&this._newProperty&&!this._hasBeenModifiedIncrementally()){this.parent.removeChild(this);section.afterUpdate();return;}
var currentNode=this._parentPane.node;if(updateInterface)
this._parentPane._userOperation=true;function callback(userCallback,originalPropertyText,newStyle)
{if(!newStyle){if(updateInterface){this._revertStyleUponEditingCanceled(originalPropertyText);}
userCallback();return;}
if(this._newProperty)
this._newPropertyInStyle=true;newStyle.parentRule=this.style.parentRule;this.style=newStyle;this.property=newStyle.propertyAt(this.property.index);this._styleRule.style=this.style;if(section&&section.pane)
section.pane.dispatchEventToListeners("style edited");if(updateInterface&&currentNode===this.node()){this._updatePane(userCallback);return;}
userCallback();}
if(styleText.length&&!/;\s*$/.test(styleText))
styleText+=";";var overwriteProperty=!!(!this._newProperty||this._newPropertyInStyle);this.property.setText(styleText,majorChange,overwriteProperty,callback.bind(this,userOperationFinishedCallback.bind(null,this._parentPane,updateInterface),this.originalPropertyText));},ondblclick:function()
{return true;},isEventWithinDisclosureTriangle:function(event)
{return event.target===this._expandElement;},__proto__:WebInspector.StylePropertyTreeElementBase.prototype}
WebInspector.StylesSidebarPane.CSSPropertyPrompt=function(cssCompletions,sidebarPane,isEditingName)
{WebInspector.TextPrompt.call(this,this._buildPropertyCompletions.bind(this),WebInspector.StyleValueDelimiters);this.setSuggestBoxEnabled("generic-suggest");this._cssCompletions=cssCompletions;this._sidebarPane=sidebarPane;this._isEditingName=isEditingName;if(!isEditingName)
this.disableDefaultSuggestionForEmptyInput();}
WebInspector.StylesSidebarPane.CSSPropertyPrompt.prototype={onKeyDown:function(event)
{switch(event.keyIdentifier){case"Up":case"Down":case"PageUp":case"PageDown":if(this._handleNameOrValueUpDown(event)){event.preventDefault();return;}
break;case"Enter":if(this.autoCompleteElement&&!this.autoCompleteElement.textContent.length){this.tabKeyPressed();return;}
break;}
WebInspector.TextPrompt.prototype.onKeyDown.call(this,event);},onMouseWheel:function(event)
{if(this._handleNameOrValueUpDown(event)){event.consume(true);return;}
WebInspector.TextPrompt.prototype.onMouseWheel.call(this,event);},tabKeyPressed:function()
{this.acceptAutoComplete();return false;},_handleNameOrValueUpDown:function(event)
{function finishHandler(originalValue,replacementString)
{this._sidebarPane.applyStyleText(this._sidebarPane.nameElement.textContent+": "+this._sidebarPane.valueElement.textContent,false,false,false);}
if(!this._isEditingName&&WebInspector.handleElementValueModifications(event,this._sidebarPane.valueElement,finishHandler.bind(this),this._isValueSuggestion.bind(this)))
return true;return false;},_isValueSuggestion:function(word)
{if(!word)
return false;word=word.toLowerCase();return this._cssCompletions.keySet().hasOwnProperty(word);},_buildPropertyCompletions:function(proxyElement,wordRange,force,completionsReadyCallback)
{var prefix=wordRange.toString().toLowerCase();if(!prefix&&!force&&(this._isEditingName||proxyElement.textContent.length)){completionsReadyCallback([]);return;}
var results=this._cssCompletions.startsWith(prefix);var selectedIndex=this._cssCompletions.mostUsedOf(results);completionsReadyCallback(results,selectedIndex);},__proto__:WebInspector.TextPrompt.prototype};WebInspector.ElementsPanel=function()
{WebInspector.Panel.call(this,"elements");this.registerRequiredCSS("breadcrumbList.css");this.registerRequiredCSS("elementsPanel.css");this.registerRequiredCSS("textPrompt.css");this.setHideOnDetach();const initialSidebarWidth=325;const minimumContentWidthPercent=0.34;const initialSidebarHeight=325;const minimumContentHeightPercent=0.34;this.createSidebarView(this.element,WebInspector.SidebarView.SidebarPosition.End,initialSidebarWidth,initialSidebarHeight);this.splitView.sidebarElement.classList.add("vbox");this.splitView.setSidebarElementConstraints(Preferences.minElementsSidebarWidth,Preferences.minElementsSidebarHeight);this.splitView.setMainElementConstraints(minimumContentWidthPercent,minimumContentHeightPercent);this.splitView.addEventListener(WebInspector.SidebarView.EventTypes.Resized,this._updateTreeOutlineVisibleWidth.bind(this));this._searchableView=new WebInspector.SearchableView(this);this.splitView.mainElement.classList.add("vbox");this._searchableView.show(this.splitView.mainElement);var stackElement=this._searchableView.element;this.contentElement=stackElement.createChild("div");this.contentElement.id="elements-content";this.contentElement.classList.add("outline-disclosure");this.contentElement.classList.add("source-code");if(!WebInspector.settings.domWordWrap.get())
this.contentElement.classList.add("nowrap");WebInspector.settings.domWordWrap.addChangeListener(this._domWordWrapSettingChanged.bind(this));this.contentElement.addEventListener("contextmenu",this._contextMenuEventFired.bind(this),true);this.splitView.sidebarElement.addEventListener("contextmenu",this._sidebarContextMenuEventFired.bind(this),false);this.treeOutline=new WebInspector.ElementsTreeOutline(true,true,this._populateContextMenu.bind(this),this._setPseudoClassForNodeId.bind(this));this.treeOutline.wireToDomAgent();this.treeOutline.addEventListener(WebInspector.ElementsTreeOutline.Events.SelectedNodeChanged,this._selectedNodeChanged,this);this.treeOutline.addEventListener(WebInspector.ElementsTreeOutline.Events.ElementsTreeUpdated,this._updateBreadcrumbIfNeeded,this);var crumbsContainer=stackElement.createChild("div");crumbsContainer.id="elements-crumbs";this.crumbsElement=crumbsContainer.createChild("div","crumbs");this.crumbsElement.addEventListener("mousemove",this._mouseMovedInCrumbs.bind(this),false);this.crumbsElement.addEventListener("mouseout",this._mouseMovedOutOfCrumbs.bind(this),false);this.sidebarPanes={};this.sidebarPanes.platformFonts=new WebInspector.PlatformFontsSidebarPane();this.sidebarPanes.computedStyle=new WebInspector.ComputedStyleSidebarPane();this.sidebarPanes.styles=new WebInspector.StylesSidebarPane(this.sidebarPanes.computedStyle,this._setPseudoClassForNodeId.bind(this));this.sidebarPanes.metrics=new WebInspector.MetricsSidebarPane();this.sidebarPanes.properties=new WebInspector.PropertiesSidebarPane();this.sidebarPanes.domBreakpoints=WebInspector.domBreakpointsSidebarPane.createProxy(this);this.sidebarPanes.eventListeners=new WebInspector.EventListenersSidebarPane();this.sidebarPanes.styles.addEventListener(WebInspector.SidebarPane.EventTypes.wasShown,this.updateStyles.bind(this,false));this.sidebarPanes.metrics.addEventListener(WebInspector.SidebarPane.EventTypes.wasShown,this.updateMetrics.bind(this));this.sidebarPanes.platformFonts.addEventListener(WebInspector.SidebarPane.EventTypes.wasShown,this.updatePlatformFonts.bind(this));this.sidebarPanes.properties.addEventListener(WebInspector.SidebarPane.EventTypes.wasShown,this.updateProperties.bind(this));this.sidebarPanes.eventListeners.addEventListener(WebInspector.SidebarPane.EventTypes.wasShown,this.updateEventListeners.bind(this));this.sidebarPanes.styles.addEventListener("style edited",this._stylesPaneEdited,this);this.sidebarPanes.styles.addEventListener("style property toggled",this._stylesPaneEdited,this);this.sidebarPanes.metrics.addEventListener("metrics edited",this._metricsPaneEdited,this);this._extensionSidebarPanes=[];WebInspector.dockController.addEventListener(WebInspector.DockController.Events.DockSideChanged,this._dockSideChanged.bind(this));WebInspector.settings.splitVerticallyWhenDockedToRight.addChangeListener(this._dockSideChanged.bind(this));this._dockSideChanged();this._popoverHelper=new WebInspector.PopoverHelper(this.element,this._getPopoverAnchor.bind(this),this._showPopover.bind(this));this._popoverHelper.setTimeout(0);WebInspector.domAgent.addEventListener(WebInspector.DOMAgent.Events.DocumentUpdated,this._documentUpdatedEvent,this);WebInspector.settings.showShadowDOM.addChangeListener(this._showShadowDOMChanged.bind(this));if(WebInspector.domAgent.existingDocument())
this._documentUpdated(WebInspector.domAgent.existingDocument());WebInspector.cssModel.addEventListener(WebInspector.CSSStyleModel.Events.ModelWasEnabled,this._updateSidebars,this);}
WebInspector.ElementsPanel.prototype={_updateTreeOutlineVisibleWidth:function()
{if(!this.treeOutline)
return;var width=this.splitView.element.offsetWidth;if(this.splitView.isVertical())
width-=this.splitView.sidebarWidth();this.treeOutline.setVisibleWidth(width);this.updateBreadcrumbSizes();},defaultFocusedElement:function()
{return this.treeOutline.element;},searchableView:function()
{return this._searchableView;},statusBarResized:function()
{this.updateBreadcrumbSizes();},wasShown:function()
{if(this.treeOutline.element.parentElement!==this.contentElement)
this.contentElement.appendChild(this.treeOutline.element);WebInspector.Panel.prototype.wasShown.call(this);this.updateBreadcrumb();this.treeOutline.updateSelection();this.treeOutline.setVisible(true);if(!this.treeOutline.rootDOMNode)
WebInspector.domAgent.requestDocument();},willHide:function()
{WebInspector.domAgent.hideDOMNodeHighlight();this.treeOutline.setVisible(false);this._popoverHelper.hidePopover();this.contentElement.removeChild(this.treeOutline.element);WebInspector.Panel.prototype.willHide.call(this);},onResize:function()
{this.treeOutline.updateSelection();this.updateBreadcrumbSizes();},createView:function(id)
{if(id==="emulation"){if(!this._overridesView)
this._overridesView=new WebInspector.OverridesView();return this._overridesView;}
if(id==="rendering"){if(!this._renderingView)
this._renderingView=new WebInspector.RenderingOptionsView();return this._renderingView;}
return null;},_setPseudoClassForNodeId:function(nodeId,pseudoClass,enable)
{var node=WebInspector.domAgent.nodeForId(nodeId);if(!node)
return;var pseudoClasses=node.getUserProperty(WebInspector.ElementsTreeOutline.PseudoStateDecorator.PropertyName);if(enable){pseudoClasses=pseudoClasses||[];if(pseudoClasses.indexOf(pseudoClass)>=0)
return;pseudoClasses.push(pseudoClass);node.setUserProperty(WebInspector.ElementsTreeOutline.PseudoStateDecorator.PropertyName,pseudoClasses);}else{if(!pseudoClasses||pseudoClasses.indexOf(pseudoClass)<0)
return;pseudoClasses.remove(pseudoClass);if(!pseudoClasses.length)
node.removeUserProperty(WebInspector.ElementsTreeOutline.PseudoStateDecorator.PropertyName);}
this.treeOutline.updateOpenCloseTags(node);WebInspector.cssModel.forcePseudoState(node.id,node.getUserProperty(WebInspector.ElementsTreeOutline.PseudoStateDecorator.PropertyName));this._metricsPaneEdited();this._stylesPaneEdited();WebInspector.notifications.dispatchEventToListeners(WebInspector.UserMetrics.UserAction,{action:WebInspector.UserMetrics.UserActionNames.ForcedElementState,selector:WebInspector.DOMPresentationUtils.appropriateSelectorFor(node,false),enabled:enable,state:pseudoClass});},_selectedNodeChanged:function()
{var selectedNode=this.selectedDOMNode();if(!selectedNode&&this._lastValidSelectedNode)
this._selectedPathOnReset=this._lastValidSelectedNode.path();this.updateBreadcrumb(false);this._updateSidebars();if(selectedNode){ConsoleAgent.addInspectedNode(selectedNode.id);this._lastValidSelectedNode=selectedNode;}
WebInspector.notifications.dispatchEventToListeners(WebInspector.ElementsTreeOutline.Events.SelectedNodeChanged);},_updateSidebars:function()
{for(var pane in this.sidebarPanes)
this.sidebarPanes[pane].needsUpdate=true;this.updateStyles(true);this.updateMetrics();this.updatePlatformFonts();this.updateProperties();this.updateEventListeners();},_reset:function()
{delete this.currentQuery;},_documentUpdatedEvent:function(event)
{this._documentUpdated(event.data);},_documentUpdated:function(inspectedRootDocument)
{this._reset();this.searchCanceled();this.treeOutline.rootDOMNode=inspectedRootDocument;if(!inspectedRootDocument){if(this.isShowing())
WebInspector.domAgent.requestDocument();return;}
WebInspector.domBreakpointsSidebarPane.restoreBreakpoints();function selectNode(candidateFocusNode)
{if(!candidateFocusNode)
candidateFocusNode=inspectedRootDocument.body||inspectedRootDocument.documentElement;if(!candidateFocusNode)
return;this.selectDOMNode(candidateFocusNode);if(this.treeOutline.selectedTreeElement)
this.treeOutline.selectedTreeElement.expand();}
function selectLastSelectedNode(nodeId)
{if(this.selectedDOMNode()){return;}
var node=nodeId?WebInspector.domAgent.nodeForId(nodeId):null;selectNode.call(this,node);}
if(this._selectedPathOnReset)
WebInspector.domAgent.pushNodeByPathToFrontend(this._selectedPathOnReset,selectLastSelectedNode.bind(this));else
selectNode.call(this,null);delete this._selectedPathOnReset;},searchCanceled:function()
{delete this._searchQuery;this._hideSearchHighlights();this._searchableView.updateSearchMatchesCount(0);delete this._currentSearchResultIndex;delete this._searchResults;WebInspector.domAgent.cancelSearch();},performSearch:function(query,shouldJump)
{this.searchCanceled();const whitespaceTrimmedQuery=query.trim();if(!whitespaceTrimmedQuery.length)
return;this._searchQuery=query;function resultCountCallback(resultCount)
{this._searchableView.updateSearchMatchesCount(resultCount);if(!resultCount)
return;this._searchResults=new Array(resultCount);this._currentSearchResultIndex=-1;if(shouldJump)
this.jumpToNextSearchResult();}
WebInspector.domAgent.performSearch(whitespaceTrimmedQuery,resultCountCallback.bind(this));},_contextMenuEventFired:function(event)
{function toggleWordWrap()
{WebInspector.settings.domWordWrap.set(!WebInspector.settings.domWordWrap.get());}
var contextMenu=new WebInspector.ContextMenu(event);this.treeOutline.populateContextMenu(contextMenu,event);if(WebInspector.experimentsSettings.cssRegions.isEnabled()){contextMenu.appendSeparator();contextMenu.appendItem(WebInspector.UIString(WebInspector.useLowerCaseMenuTitles()?"CSS named flows\u2026":"CSS Named Flows\u2026"),this._showNamedFlowCollections.bind(this));}
contextMenu.appendSeparator();contextMenu.appendCheckboxItem(WebInspector.UIString(WebInspector.useLowerCaseMenuTitles()?"Word wrap":"Word Wrap"),toggleWordWrap.bind(this),WebInspector.settings.domWordWrap.get());contextMenu.show();},_showNamedFlowCollections:function()
{if(!WebInspector.cssNamedFlowCollectionsView)
WebInspector.cssNamedFlowCollectionsView=new WebInspector.CSSNamedFlowCollectionsView();WebInspector.cssNamedFlowCollectionsView.showInDrawer();},_domWordWrapSettingChanged:function(event)
{if(event.data)
this.contentElement.classList.remove("nowrap");else
this.contentElement.classList.add("nowrap");var selectedNode=this.selectedDOMNode();if(!selectedNode)
return;var treeElement=this.treeOutline.findTreeElement(selectedNode);if(treeElement)
treeElement.updateSelection();},switchToAndFocus:function(node)
{this._searchableView.cancelSearch();WebInspector.inspectorView.setCurrentPanel(this);this.selectDOMNode(node,true);},_populateContextMenu:function(contextMenu,node)
{contextMenu.appendSeparator();var pane=WebInspector.domBreakpointsSidebarPane;pane.populateNodeContextMenu(node,contextMenu);},_getPopoverAnchor:function(element)
{var anchor=element.enclosingNodeOrSelfWithClass("webkit-html-resource-link");if(anchor){if(!anchor.href)
return null;var resource=WebInspector.resourceTreeModel.resourceForURL(anchor.href);if(!resource||resource.type!==WebInspector.resourceTypes.Image)
return null;anchor.removeAttribute("title");}
return anchor;},_loadDimensionsForNode:function(treeElement,callback)
{if(treeElement.treeOutline!==this.treeOutline){callback();return;}
var node=(treeElement.representedObject);if(!node.nodeName()||node.nodeName().toLowerCase()!=="img"){callback();return;}
WebInspector.RemoteObject.resolveNode(node,"",resolvedNode);function resolvedNode(object)
{if(!object){callback();return;}
object.callFunctionJSON(dimensions,undefined,callback);object.release();function dimensions()
{return{offsetWidth:this.offsetWidth,offsetHeight:this.offsetHeight,naturalWidth:this.naturalWidth,naturalHeight:this.naturalHeight};}}},_showPopover:function(anchor,popover)
{var listItem=anchor.enclosingNodeOrSelfWithNodeName("li");if(listItem&&listItem.treeElement)
this._loadDimensionsForNode(listItem.treeElement,WebInspector.DOMPresentationUtils.buildImagePreviewContents.bind(WebInspector.DOMPresentationUtils,anchor.href,true,showPopover));else
WebInspector.DOMPresentationUtils.buildImagePreviewContents(anchor.href,true,showPopover);function showPopover(contents)
{if(!contents)
return;popover.setCanShrink(false);popover.show(contents,anchor);}},jumpToNextSearchResult:function()
{if(!this._searchResults)
return;this._hideSearchHighlights();if(++this._currentSearchResultIndex>=this._searchResults.length)
this._currentSearchResultIndex=0;this._highlightCurrentSearchResult();},jumpToPreviousSearchResult:function()
{if(!this._searchResults)
return;this._hideSearchHighlights();if(--this._currentSearchResultIndex<0)
this._currentSearchResultIndex=(this._searchResults.length-1);this._highlightCurrentSearchResult();},_highlightCurrentSearchResult:function()
{var index=this._currentSearchResultIndex;var searchResults=this._searchResults;var searchResult=searchResults[index];if(searchResult===null){this._searchableView.updateCurrentMatchIndex(index);return;}
function searchCallback(node)
{searchResults[index]=node;this._highlightCurrentSearchResult();}
if(typeof searchResult==="undefined"){WebInspector.domAgent.searchResult(index,searchCallback.bind(this));return;}
this._searchableView.updateCurrentMatchIndex(index);var treeElement=this.treeOutline.findTreeElement(searchResult);if(treeElement){treeElement.highlightSearchResults(this._searchQuery);treeElement.reveal();var matches=treeElement.listItemElement.getElementsByClassName("highlighted-search-result");if(matches.length)
matches[0].scrollIntoViewIfNeeded();}},_hideSearchHighlights:function()
{if(!this._searchResults)
return;var searchResult=this._searchResults[this._currentSearchResultIndex];if(!searchResult)
return;var treeElement=this.treeOutline.findTreeElement(searchResult);if(treeElement)
treeElement.hideSearchHighlights();},selectedDOMNode:function()
{return this.treeOutline.selectedDOMNode();},selectDOMNode:function(node,focus)
{this.treeOutline.selectDOMNode(node,focus);},_updateBreadcrumbIfNeeded:function(event)
{var nodes=(event.data||[]);if(!nodes.length)
return;var crumbs=this.crumbsElement;for(var crumb=crumbs.firstChild;crumb;crumb=crumb.nextSibling){if(nodes.indexOf(crumb.representedObject)!==-1){this.updateBreadcrumb(true);return;}}},_stylesPaneEdited:function()
{this.sidebarPanes.metrics.needsUpdate=true;this.updateMetrics();this.sidebarPanes.platformFonts.needsUpdate=true;this.updatePlatformFonts();},_metricsPaneEdited:function()
{this.sidebarPanes.styles.needsUpdate=true;this.updateStyles(true);},_mouseMovedInCrumbs:function(event)
{var nodeUnderMouse=document.elementFromPoint(event.pageX,event.pageY);var crumbElement=nodeUnderMouse.enclosingNodeOrSelfWithClass("crumb");WebInspector.domAgent.highlightDOMNode(crumbElement?crumbElement.representedObject.id:0);if("_mouseOutOfCrumbsTimeout"in this){clearTimeout(this._mouseOutOfCrumbsTimeout);delete this._mouseOutOfCrumbsTimeout;}},_mouseMovedOutOfCrumbs:function(event)
{var nodeUnderMouse=document.elementFromPoint(event.pageX,event.pageY);if(nodeUnderMouse&&nodeUnderMouse.isDescendant(this.crumbsElement))
return;WebInspector.domAgent.hideDOMNodeHighlight();this._mouseOutOfCrumbsTimeout=setTimeout(this.updateBreadcrumbSizes.bind(this),1000);},updateBreadcrumb:function(forceUpdate)
{if(!this.isShowing())
return;var crumbs=this.crumbsElement;var handled=false;var crumb=crumbs.firstChild;while(crumb){if(crumb.representedObject===this.selectedDOMNode()){crumb.classList.add("selected");handled=true;}else{crumb.classList.remove("selected");}
crumb=crumb.nextSibling;}
if(handled&&!forceUpdate){this.updateBreadcrumbSizes();return;}
crumbs.removeChildren();var panel=this;function selectCrumbFunction(event)
{var crumb=event.currentTarget;if(crumb.classList.contains("collapsed")){if(crumb===panel.crumbsElement.firstChild){var currentCrumb=crumb;while(currentCrumb){var hidden=currentCrumb.classList.contains("hidden");var collapsed=currentCrumb.classList.contains("collapsed");if(!hidden&&!collapsed)
break;crumb=currentCrumb;currentCrumb=currentCrumb.nextSibling;}}
panel.updateBreadcrumbSizes(crumb);}else
panel.selectDOMNode(crumb.representedObject,true);event.preventDefault();}
for(var current=this.selectedDOMNode();current;current=current.parentNode){if(current.nodeType()===Node.DOCUMENT_NODE)
continue;crumb=document.createElement("span");crumb.className="crumb";crumb.representedObject=current;crumb.addEventListener("mousedown",selectCrumbFunction,false);var crumbTitle="";switch(current.nodeType()){case Node.ELEMENT_NODE:if(current.pseudoType())
crumbTitle="::"+current.pseudoType();else
WebInspector.DOMPresentationUtils.decorateNodeLabel(current,crumb);break;case Node.TEXT_NODE:crumbTitle=WebInspector.UIString("(text)");break;case Node.COMMENT_NODE:crumbTitle="<!-->";break;case Node.DOCUMENT_TYPE_NODE:crumbTitle="<!DOCTYPE>";break;case Node.DOCUMENT_FRAGMENT_NODE:crumbTitle=current.shadowRootType()?"#shadow-root":current.nodeNameInCorrectCase();break;default:crumbTitle=current.nodeNameInCorrectCase();}
if(!crumb.childNodes.length){var nameElement=document.createElement("span");nameElement.textContent=crumbTitle;crumb.appendChild(nameElement);crumb.title=crumbTitle;}
if(current===this.selectedDOMNode())
crumb.classList.add("selected");if(!crumbs.childNodes.length)
crumb.classList.add("end");crumbs.insertBefore(crumb,crumbs.firstChild);}
if(crumbs.hasChildNodes())
crumbs.lastChild.classList.add("start");this.updateBreadcrumbSizes();},updateBreadcrumbSizes:function(focusedCrumb)
{if(!this.isShowing())
return;if(document.body.offsetWidth<=0){return;}
var crumbs=this.crumbsElement;if(!crumbs.childNodes.length||crumbs.offsetWidth<=0)
return;var selectedIndex=0;var focusedIndex=0;var selectedCrumb;var i=0;var crumb=crumbs.firstChild;while(crumb){if(!selectedCrumb&&crumb.classList.contains("selected")){selectedCrumb=crumb;selectedIndex=i;}
if(crumb===focusedCrumb)
focusedIndex=i;if(crumb!==crumbs.lastChild)
crumb.classList.remove("start");if(crumb!==crumbs.firstChild)
crumb.classList.remove("end");crumb.classList.remove("compact");crumb.classList.remove("collapsed");crumb.classList.remove("hidden");crumb=crumb.nextSibling;++i;}
crumbs.firstChild.classList.add("end");crumbs.lastChild.classList.add("start");var contentElement=this.contentElement;function crumbsAreSmallerThanContainer()
{const rightPadding=10;return crumbs.offsetWidth+rightPadding<contentElement.offsetWidth;}
if(crumbsAreSmallerThanContainer())
return;var BothSides=0;var AncestorSide=-1;var ChildSide=1;function makeCrumbsSmaller(shrinkingFunction,direction,significantCrumb)
{if(!significantCrumb)
significantCrumb=(focusedCrumb||selectedCrumb);if(significantCrumb===selectedCrumb)
var significantIndex=selectedIndex;else if(significantCrumb===focusedCrumb)
var significantIndex=focusedIndex;else{var significantIndex=0;for(var i=0;i<crumbs.childNodes.length;++i){if(crumbs.childNodes[i]===significantCrumb){significantIndex=i;break;}}}
function shrinkCrumbAtIndex(index)
{var shrinkCrumb=crumbs.childNodes[index];if(shrinkCrumb&&shrinkCrumb!==significantCrumb)
shrinkingFunction(shrinkCrumb);if(crumbsAreSmallerThanContainer())
return true;return false;}
if(direction){var index=(direction>0?0:crumbs.childNodes.length-1);while(index!==significantIndex){if(shrinkCrumbAtIndex(index))
return true;index+=(direction>0?1:-1);}}else{var startIndex=0;var endIndex=crumbs.childNodes.length-1;while(startIndex!=significantIndex||endIndex!=significantIndex){var startDistance=significantIndex-startIndex;var endDistance=endIndex-significantIndex;if(startDistance>=endDistance)
var index=startIndex++;else
var index=endIndex--;if(shrinkCrumbAtIndex(index))
return true;}}
return false;}
function coalesceCollapsedCrumbs()
{var crumb=crumbs.firstChild;var collapsedRun=false;var newStartNeeded=false;var newEndNeeded=false;while(crumb){var hidden=crumb.classList.contains("hidden");if(!hidden){var collapsed=crumb.classList.contains("collapsed");if(collapsedRun&&collapsed){crumb.classList.add("hidden");crumb.classList.remove("compact");crumb.classList.remove("collapsed");if(crumb.classList.contains("start")){crumb.classList.remove("start");newStartNeeded=true;}
if(crumb.classList.contains("end")){crumb.classList.remove("end");newEndNeeded=true;}
continue;}
collapsedRun=collapsed;if(newEndNeeded){newEndNeeded=false;crumb.classList.add("end");}}else
collapsedRun=true;crumb=crumb.nextSibling;}
if(newStartNeeded){crumb=crumbs.lastChild;while(crumb){if(!crumb.classList.contains("hidden")){crumb.classList.add("start");break;}
crumb=crumb.previousSibling;}}}
function compact(crumb)
{if(crumb.classList.contains("hidden"))
return;crumb.classList.add("compact");}
function collapse(crumb,dontCoalesce)
{if(crumb.classList.contains("hidden"))
return;crumb.classList.add("collapsed");crumb.classList.remove("compact");if(!dontCoalesce)
coalesceCollapsedCrumbs();}
if(!focusedCrumb){if(makeCrumbsSmaller(compact,ChildSide))
return;if(makeCrumbsSmaller(collapse,ChildSide))
return;}
if(makeCrumbsSmaller(compact,(focusedCrumb?BothSides:AncestorSide)))
return;if(makeCrumbsSmaller(collapse,(focusedCrumb?BothSides:AncestorSide)))
return;if(!selectedCrumb)
return;compact(selectedCrumb);if(crumbsAreSmallerThanContainer())
return;collapse(selectedCrumb,true);},updateStyles:function(forceUpdate)
{if(!WebInspector.cssModel.isEnabled())
return;var stylesSidebarPane=this.sidebarPanes.styles;var computedStylePane=this.sidebarPanes.computedStyle;if((!stylesSidebarPane.isShowing()&&!computedStylePane.isShowing())||!stylesSidebarPane.needsUpdate)
return;stylesSidebarPane.update(this.selectedDOMNode(),forceUpdate);stylesSidebarPane.needsUpdate=false;},updateMetrics:function()
{if(!WebInspector.cssModel.isEnabled())
return;var metricsSidebarPane=this.sidebarPanes.metrics;if(!metricsSidebarPane.isShowing()||!metricsSidebarPane.needsUpdate)
return;metricsSidebarPane.update(this.selectedDOMNode());metricsSidebarPane.needsUpdate=false;},updatePlatformFonts:function()
{if(!WebInspector.cssModel.isEnabled())
return;var platformFontsSidebar=this.sidebarPanes.platformFonts;if(!platformFontsSidebar.isShowing()||!platformFontsSidebar.needsUpdate)
return;platformFontsSidebar.update(this.selectedDOMNode());platformFontsSidebar.needsUpdate=false;},updateProperties:function()
{var propertiesSidebarPane=this.sidebarPanes.properties;if(!propertiesSidebarPane.isShowing()||!propertiesSidebarPane.needsUpdate)
return;propertiesSidebarPane.update(this.selectedDOMNode());propertiesSidebarPane.needsUpdate=false;},updateEventListeners:function()
{var eventListenersSidebarPane=this.sidebarPanes.eventListeners;if(!eventListenersSidebarPane.isShowing()||!eventListenersSidebarPane.needsUpdate)
return;eventListenersSidebarPane.update(this.selectedDOMNode());eventListenersSidebarPane.needsUpdate=false;},handleShortcut:function(event)
{function handleUndoRedo()
{if(WebInspector.KeyboardShortcut.eventHasCtrlOrMeta(event)&&!event.shiftKey&&event.keyIdentifier==="U+005A"){WebInspector.domAgent.undo(this._updateSidebars.bind(this));event.handled=true;return;}
var isRedoKey=WebInspector.isMac()?event.metaKey&&event.shiftKey&&event.keyIdentifier==="U+005A":event.ctrlKey&&event.keyIdentifier==="U+0059";if(isRedoKey){DOMAgent.redo(this._updateSidebars.bind(this));event.handled=true;}}
if(!this.treeOutline.editing()){handleUndoRedo.call(this);if(event.handled)
return;}
this.treeOutline.handleShortcut(event);},handleCopyEvent:function(event)
{var currentFocusElement=WebInspector.currentFocusElement();if(currentFocusElement&&WebInspector.isBeingEdited(currentFocusElement))
return;if(!window.getSelection().isCollapsed)
return;event.clipboardData.clearData();event.preventDefault();this.selectedDOMNode().copyNode();},sidebarResized:function(event)
{this.treeOutline.updateSelection();},revealAndSelectNode:function(nodeId)
{WebInspector.inspectorView.setCurrentPanel(this);var node=WebInspector.domAgent.nodeForId(nodeId);if(!node)
return;while(!WebInspector.ElementsTreeOutline.showShadowDOM()&&node&&node.isInShadowTree())
node=node.parentNode;WebInspector.domAgent.highlightDOMNodeForTwoSeconds(nodeId);this.selectDOMNode(node,true);},appendApplicableItems:function(event,contextMenu,target)
{function selectNode(nodeId)
{if(nodeId)
WebInspector.domAgent.inspectElement(nodeId);}
function revealElement(remoteObject)
{remoteObject.pushNodeToFrontend(selectNode);}
var commandCallback;if(target instanceof WebInspector.RemoteObject){var remoteObject=(target);if(remoteObject.subtype==="node")
commandCallback=revealElement.bind(this,remoteObject);}else if(target instanceof WebInspector.DOMNode){var domNode=(target);if(domNode.id)
commandCallback=WebInspector.domAgent.inspectElement.bind(WebInspector.domAgent,domNode.id);}
if(!commandCallback)
return;if(this.treeOutline.element.isAncestor(event.target))
return;contextMenu.appendItem(WebInspector.useLowerCaseMenuTitles()?"Reveal in Elements panel":"Reveal in Elements Panel",commandCallback);},_sidebarContextMenuEventFired:function(event)
{var contextMenu=new WebInspector.ContextMenu(event);contextMenu.show();},_dockSideChanged:function()
{var dockSide=WebInspector.dockController.dockSide();var vertically=dockSide===WebInspector.DockController.State.DockedToRight&&WebInspector.settings.splitVerticallyWhenDockedToRight.get();this._splitVertically(vertically);},_showShadowDOMChanged:function()
{this.treeOutline.update();},_splitVertically:function(vertically)
{if(this.sidebarPaneView&&vertically===!this.splitView.isVertical())
return;if(this.sidebarPaneView){this.sidebarPaneView.detach();this.splitView.uninstallResizer(this.sidebarPaneView.headerElement());}
this.splitView.setVertical(!vertically);var computedPane=new WebInspector.SidebarPane(WebInspector.UIString("Computed"));computedPane.element.classList.add("composite");computedPane.element.classList.add("fill");var expandComputed=computedPane.expand.bind(computedPane);computedPane.bodyElement.appendChild(this.sidebarPanes.computedStyle.titleElement);computedPane.bodyElement.classList.add("metrics-and-computed");this.sidebarPanes.computedStyle.show(computedPane.bodyElement);this.sidebarPanes.computedStyle.setExpandCallback(expandComputed);this.sidebarPanes.platformFonts.show(computedPane.bodyElement);function showMetrics(pane,beforeElement)
{this.sidebarPanes.metrics.show(pane.bodyElement,beforeElement);}
function tabSelected(event)
{var tabId=(event.data.tabId);if(tabId===computedPane.title())
showMetrics.call(this,computedPane,this.sidebarPanes.computedStyle.element);if(tabId===stylesPane.title())
showMetrics.call(this,stylesPane);}
this.sidebarPaneView=new WebInspector.SidebarTabbedPane();if(vertically){this.splitView.installResizer(this.sidebarPaneView.headerElement());this.sidebarPanes.metrics.show(computedPane.bodyElement,this.sidebarPanes.computedStyle.element);this.sidebarPanes.metrics.setExpandCallback(expandComputed);var compositePane=new WebInspector.SidebarPane(this.sidebarPanes.styles.title());compositePane.element.classList.add("composite");compositePane.element.classList.add("fill");var expandComposite=compositePane.expand.bind(compositePane);var splitView=new WebInspector.SplitView(true,"StylesPaneSplitRatio",0.5);splitView.show(compositePane.bodyElement);this.sidebarPanes.styles.show(splitView.firstElement());splitView.firstElement().appendChild(this.sidebarPanes.styles.titleElement);this.sidebarPanes.styles.setExpandCallback(expandComposite);computedPane.show(splitView.secondElement());computedPane.setExpandCallback(expandComposite);this.sidebarPaneView.addPane(compositePane);}else{var stylesPane=new WebInspector.SidebarPane(this.sidebarPanes.styles.title());stylesPane.element.classList.add("composite");stylesPane.element.classList.add("fill");var expandStyles=stylesPane.expand.bind(stylesPane);stylesPane.bodyElement.classList.add("metrics-and-styles");this.sidebarPanes.styles.show(stylesPane.bodyElement);this.sidebarPanes.styles.setExpandCallback(expandStyles);this.sidebarPanes.metrics.setExpandCallback(expandStyles);stylesPane.bodyElement.appendChild(this.sidebarPanes.styles.titleElement);this.sidebarPaneView.addEventListener(WebInspector.TabbedPane.EventTypes.TabSelected,tabSelected,this);showMetrics.call(this,stylesPane);this.sidebarPaneView.addPane(stylesPane);this.sidebarPaneView.addPane(computedPane);}
this.sidebarPaneView.addPane(this.sidebarPanes.eventListeners);this.sidebarPaneView.addPane(this.sidebarPanes.domBreakpoints);this.sidebarPaneView.addPane(this.sidebarPanes.properties);this._extensionSidebarPanesContainer=this.sidebarPaneView;for(var i=0;i<this._extensionSidebarPanes.length;++i)
this._extensionSidebarPanesContainer.addPane(this._extensionSidebarPanes[i]);this.sidebarPaneView.show(this.splitView.sidebarElement);this.sidebarPanes.styles.expand();},addExtensionSidebarPane:function(id,pane)
{this._extensionSidebarPanes.push(pane);this._extensionSidebarPanesContainer.addPane(pane);},__proto__:WebInspector.Panel.prototype}