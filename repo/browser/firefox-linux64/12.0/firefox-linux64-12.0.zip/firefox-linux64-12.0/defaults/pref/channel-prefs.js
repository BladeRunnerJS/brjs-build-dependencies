//@line 2 "/builds/slave/rel-m-rel-lnx64-bld/build/browser/app/profile/channel-prefs.js"
pref("app.update.channel", "release");
