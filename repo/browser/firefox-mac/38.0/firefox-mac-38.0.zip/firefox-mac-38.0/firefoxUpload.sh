#!/bin/sh

##
##      ARGUMENTS
#############################
NOTIFICATION_LIST=${1-releng@caplin.com}
DRYRUN=${2-false}

##
##      CTES
#############################
REPO="thirdparty-repo"
ARTIFACTORY_URL="http://artifactory.caplin.com:80/artifactory"
RELEASE_URL="http://ftp.mozilla.org/pub/mozilla.org/firefox/nightly"
version="\.0-candidates"
temp_release_file=/tmp/$$.out
temp_inflating_file=/tmp/$$.zip
groupidpath="browser"
browser="firefox"
ARTIFACTORY_USERNAME="firefox_upload"
ARTIFACTORY_PASSWORD="c4pl1n"
FROM="releng@caplin.com"

##
##      FUNCTIONS
#############################
function cleanup()
{
  [ -e $temp_release_file ] && rm $temp_release_file
  [ -e $temp_inflating_file ] && rm $temp_inflating_file
}

function isAnArtefact()
{
  local repo=$1
  local group=$2
  local artefact=$3
  local version=$4
  local http_code=`curl -sL -w "%{http_code}" -X GET "${ARTIFACTORY_URL}/api/storage/${repo}/${group}/${artefact}/${version}" -o /dev/null`
  [ "${http_code}" = "200" ] && echo "true" || echo "false"
}

function emailNotification()
{
  local SUBJECT=$1
  local MESSAGE=$2

  #### EMAIL NOTIFICATION
  (
  echo "From: ${FROM} ";
  echo "To: ${NOTIFICATION_LIST} ";
  echo "MIME-Version: 1.0";
  echo "Content-Type: multipart/alternative; " ;
  echo ' boundary="some.unique.value.ABC123/server.xyz.com"' ;
  echo "Subject: ${SUBJECT}" ;
  echo "" ;
  echo "This is a MIME-encapsulated message" ;
  echo "" ;
  echo "--some.unique.value.ABC123/server.xyz.com" ;
  echo "Content-Type: text/html" ;
  echo "" ;
  echo "<html> <head><title>${SUBJECT}</title> </head><body><pre>";
  echo "${MESSAGE}";
  echo "</pre></body> </html>";
  echo "--some.unique.value.ABC123/server.xyz.com";
  ) | /usr/sbin/sendmail -t
}

function getArch()
{
  local os=$1
  if [ "$os" == "linux" ]; then
    echo "linux-i686"
  elif [ "$os" == "linux64" ]; then
    echo "linux-x86_64"
  else
    echo  "$os"
  fi

}

function getLastRelease()
{
  local url=$1
  local version=$2
  echo `curl -s ${url} | grep $version | sed -e 's/.*href=\"//g' -e 's/\/\".*//' | tail -n1 | sed "s/$version/\.0/g"`
}

function getLastBuild()
{
  local url=$1
  local lastbuild=`curl -s ${url}  | grep "build[0-9]" | sed -e 's/.*href=\"//g' -e 's/\/\".*//'g | sed 's/build//g' | sort -nr | head -n1`
  echo "build${lastbuild}"
}

function getArtifactName()
{
  local os=$1
  local browser=$2
  local version=$3

  local CapitalBrowser="$(tr '[:lower:]' '[:upper:]' <<< ${browser:0:1})${browser:1}"

  case $os in
    "win32") echo "${browser}-${version}.zip";;
    "mac")   echo "${CapitalBrowser} ${version}.dmg";;
    "linux"|"linux64") echo "${browser}-${version}.tar.bz2";;
  esac
}

function download()
{
  local folder=$1
  local latestversion=$2
  local artifact=$3
  local arch=$4

  ### cleanup previous execution
  echo "Looking for left over copies of ${artifact}"
  if [ -f "$artifact" ]
    then rm "$artifact"
  fi

  if [ -d $folder ]
    then rm -rf $folder
  fi

  local url="${RELEASE_URL}/${latestversion}-candidates"
  local lastbuild=`getLastBuild ${url}/`
  url="${url}/${lastbuild}/${arch}/en-GB/${artifact}"

  echo "Retrieving artifact ${artifact}"
  wget -q "${url}"
  [ $? -ne 0 ] && exit 1
}

function unzipWin()
{
  local artifact=$1
  echo "Unzipping artifact ${artifact}"
  unzip ${artifact} > ${temp_inflating_file}
  [ $? -ne 0 ] && exit 1
}

function unzipMac()
{
  ###TODO: MAC STILL WORK IN PROGRESS
  local artifact=$1
  echo "Unzipping artifact ${artifact}"
  device=$(hdiutil attach -nobrowse "${artifact}" | grep Firefox | awk '{print $1}')
  diskutil mountDisk $device > /dev/null
  cp -r /Volumes/Firefox/Firefox.app .
  mkdir ${browser}
  mv Firefox.app/ ${browser}/Firefox.app/
  diskutil unmountDisk $device > /dev/null
  hdiutil detach $device > /dev/null
  [ $? -ne 0 ] && exit 1
}

function unzipLin()
{
  local artifact=$1
  echo "Unzipping artifact ${artifact}"
  tar xjf ${artifact} > ${temp_inflating_file}
  [ $? -ne 0 ] && exit 1
}


function downloadZipUpload()
{
  local folder=$1
  local latestversion=$2
  local artifact=$3
  local arch=$4

  download "${folder}" "${latestversion}" "${artifact}" "${arch}"

  case $arch in
    "win32")  unzipWin "${artifact}";;
    "mac")    unzipMac "${artifact}";;
    *)        unzipLin "${artifact}";;
  esac

  rm "${artifact}"
  mv ${browser} ${folder}-${latestversion}
  echo "Zipping artifact ${artifact}"
  zip -9 -r "${folder}-${latestversion}.zip" "${folder}-${latestversion}" >> ${temp_inflating_file}
  [ $? -ne 0 ] && exit 1
  rm -rf ${folder}-${latestversion}
}

function writePOM {
  local os=$1
  local latestversion=$2
  pomfile="${browser}-${os}-${latestversion}.pom"

  echo '<?xml version="1.0" encoding="UTF-8"?>' > $pomfile
  echo '<project xsi:schemaLocation="http://maven.apache.org/POM/4.0.0 http://maven.apache.org/xsd/maven-4.0.0.xsd" xmlns="http://maven.apache.org/POM/4.0.0" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance">' >> $pomfile
  echo '  <modelVersion>4.0.0</modelVersion>' >> $pomfile
  echo "  <groupId>${groupidpath}</groupId>" >> $pomfile
  echo "  <artifactId>${browser}-${os}</artifactId>" >> $pomfile
  echo "  <version>${latestversion}</version>" >> $pomfile
  echo '  <packaging>zip</packaging>' >> $pomfile
  echo '  <description>Upload script generated POM</description>' >> $pomfile
  echo '</project>' >> $pomfile
}

##
##      MAIN SECTION
#########################

cleanup

## To Allow for downloads of previous versions
if [ $# -eq 1 ]; then
  latestversion="$1.0"
else
  latestversion=$( getLastRelease ${RELEASE_URL}/ $version )
fi

for os in "win32" "linux" "linux64" "mac"; do
  ### Get arch format
  arch=`getArch $os`
  URL="${ARTIFACTORY_URL}/${REPO}/${groupidpath}/${browser}-${os}/${latestversion}/${browser}-${os}-${latestversion}"

  ### Clever way of overlapping artefacts
  if [ "$(isAnArtefact ${REPO} ${groupidpath} ${browser}-${os} ${latestversion})" = "false" ] ; then
    if [ "${DRYRUN}" != "DRYRUN" ] ; then
      artifactName=$(getArtifactName ${os} ${browser} ${latestversion})
      downloadZipUpload "${browser}-${os}" "${latestversion}" "${artifactName}" "${arch}"
      echo "Writing POM for ${browser}-${os}-${latestversion}.zip"
      writePOM "${os}" "${latestversion}"
      echo "Uploading artifact ${browser}-${os}-${latestversion}.zip"
      curl -u ${ARTIFACTORY_USERNAME}:${ARTIFACTORY_PASSWORD} -s -X PUT --data-binary "@${browser}-${os}-${latestversion}.zip" "${URL}.zip" > /dev/null
      echo "Uploading artifact ${browser}-${os}-${latestversion}.pom"
      curl -u ${ARTIFACTORY_USERNAME}:${ARTIFACTORY_PASSWORD} -s -X PUT --data-binary "@${browser}-${os}-${latestversion}.pom" "${URL}.pom" > /dev/null
      rm ${browser}-${os}-${latestversion}.zip ${browser}-${os}-${latestversion}.pom
      emailNotification "New ${browser}-${os} version [${latestversion}]" "URL: ${URL}"
    else
      echo "Uploading artifact ${browser}-${os}-${latestversion}.zip [ DRYRUN ]"
    fi
  else
    echo "${browser}-${os}-${latestversion}.zip already exists [ ${URL} ]"
  fi
done
