//@line 2 "e:\builds\moz2_slave\rel-m-rel-w32-bld\build\browser\app\profile\channel-prefs.js"
pref("app.update.channel", "release");
pref("extensions.checkCompatibility", false);
pref("extensions.checkCompatibility.12.0", false);
pref("extensions.shownSelectionUI", true);
pref("extensions.autoDisableScopes", 0);